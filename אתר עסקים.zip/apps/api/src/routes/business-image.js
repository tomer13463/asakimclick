import { Router } from 'express';
import { ContentBlockType, stream } from '../api/integrated-ai.js';
import pocketbaseClient from '../utils/pocketbaseClient.js';
import logger from '../utils/logger.js';

const router = Router();

router.post('/generate-business-image', async (req, res) => {
  const { businessId, subcategory } = req.body;

  if (!businessId || !subcategory) {
    return res.status(400).json({ error: 'businessId and subcategory are required' });
  }

  // Generate image using integrated AI
  const userMessage = [
    {
      type: ContentBlockType.Text,
      text: `Generate a professional image for a ${subcategory} business. The image should clearly represent the profession and be suitable for a business listing.`,
    },
  ];

  const sseStream = await stream({
    userId: null,
    systemPrompt: 'You are an expert at generating professional business images. Use the generate_image tool to create high-quality, professional images that represent the specified business category.',
    userMessage,
  });

  // Parse SSE stream to extract image URL from tool results
  let imageUrl = null;
  let buffer = '';

  for await (const chunk of sseStream) {
    buffer += chunk.toString();
    const lines = buffer.split('\n');
    buffer = lines.pop() || '';

    for (const line of lines) {
      if (!line.startsWith('data: ')) {
        continue;
      }

      const jsonStr = line.slice(6);

      if (jsonStr === '[DONE]') {
        break;
      }

      try {
        const event = JSON.parse(jsonStr);

        // Extract image URL from tool_result events
        if (event.type === 'tool_result' && event.data?.content) {
          const content = event.data.content;
          // Look for image URL in the tool result content
          const urlMatch = content.match(/https?:\/\/[^\s]+/);
          if (urlMatch) {
            imageUrl = urlMatch[0];
          }
        }
      } catch (parseError) {
        logger.debug('Failed to parse SSE event:', parseError.message);
      }
    }
  }

  if (!imageUrl) {
    throw new Error('Failed to generate image: no image URL found in AI response');
  }

  // Update business record with the generated image URL
  const business = await pocketbaseClient.collection('businesses').getOne(businessId);

  const images = Array.isArray(business.images) ? business.images : [];
  images.push(imageUrl);

  await pocketbaseClient.collection('businesses').update(businessId, {
    images,
  });

  res.json({ imageUrl });
});

export default router;