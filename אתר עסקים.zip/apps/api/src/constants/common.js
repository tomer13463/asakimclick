const NodeEnv = {
	Development: 'development',
	Production: 'production',
};

const BodyLimit = 1024 * 1024 * 20;

const VALID_CITIES = [
	'תל אביב יפו',
	'ירושלים',
	'חיפה',
	'ראשון לציון',
	'פתח תקווה',
	'אשדוד',
	'נתניה',
	'בני ברק',
	'הרצליה',
	'קרית שמונה',
	'אשקלון',
	'רמת גן',
	'גבעתיים',
	'כפר סבא',
	'חולון',
	'בת ים',
	'לוד',
	'רמלה',
	'מודיעין',
	'קרית מלאכי',
	'בית שמש',
];

export { NodeEnv, BodyLimit, VALID_CITIES };