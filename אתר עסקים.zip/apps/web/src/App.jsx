import React, { Suspense, lazy, useEffect } from 'react';
import { Route, Routes, BrowserRouter as Router, Link, useLocation } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';
import { AuthProvider } from '@/contexts/AuthContext.jsx';
import { AdminAuthProvider } from '@/contexts/AdminAuthContext.jsx';
import { BusinessOwnerAuthProvider } from '@/contexts/BusinessOwnerAuthContext.jsx';
import { Toaster } from '@/components/ui/sonner';
import ScrollToTop from '@/components/ScrollToTop.jsx';
import ProtectedRoute from '@/components/ProtectedRoute.jsx';
import AdminProtectedRoute from '@/components/AdminProtectedRoute.jsx';
import BusinessOwnerProtectedRoute from '@/components/BusinessOwnerProtectedRoute.jsx';
import PageTransition from '@/components/PageTransition.jsx';
import LoadingSpinner from '@/components/LoadingSpinner.jsx';

import HomePage from '@/pages/HomePage.jsx';
import SearchResultsPage from '@/pages/SearchResultsPage.jsx';
import CategoriesPage from '@/pages/CategoriesPage.jsx';
import BusinessDetailPage from '@/pages/BusinessDetailPage.jsx';
import SignupPage from '@/pages/SignupPage.jsx';
import LoginPage from '@/pages/LoginPage.jsx';
import UserSettingsPage from '@/pages/UserSettingsPage.jsx';

import AboutPage from '@/pages/AboutPage.jsx';
import FAQPage from '@/pages/FAQPage.jsx';
import BlogPage from '@/pages/BlogPage.jsx';
import BlogDetailPage from '@/pages/BlogDetailPage.jsx';
import SitemapGenerator from '@/components/SitemapGenerator.jsx';

import BusinessOwnerLoginPage from '@/pages/BusinessOwnerLoginPage.jsx';
import BusinessOwnerSignupPage from '@/pages/BusinessOwnerSignupPage.jsx';

const DashboardPage = lazy(() => import('@/pages/DashboardPage.jsx'));
const AdminLoginPage = lazy(() => import('@/pages/AdminLoginPage.jsx'));
const AdminPanel = lazy(() => import('@/pages/AdminPanel.jsx'));
const AdminPage = lazy(() => import('@/pages/AdminPage.jsx'));
const BusinessOwnerDashboard = lazy(() => import('@/pages/BusinessOwnerDashboard.jsx'));
const BusinessOwnerAddPage = lazy(() => import('@/pages/BusinessOwnerAddPage.jsx'));
const BusinessOwnerEditPage = lazy(() => import('@/pages/BusinessOwnerEditPage.jsx'));
const BusinessOwnerReviewsPage = lazy(() => import('@/pages/BusinessOwnerReviewsPage.jsx'));
const MapPage = lazy(() => import('@/pages/MapPage.jsx'));

const SuspenseFallback = () => (
  <div className="min-h-screen flex items-center justify-center bg-background">
    <LoadingSpinner />
  </div>
);

const AnimatedRoutes = () => {
  const location = useLocation();
  
  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={<PageTransition><HomePage /></PageTransition>} />
        <Route path="/search" element={<PageTransition><SearchResultsPage /></PageTransition>} />
        <Route path="/categories" element={<PageTransition><CategoriesPage /></PageTransition>} />
        <Route path="/business/:id" element={<PageTransition><BusinessDetailPage /></PageTransition>} />
        <Route path="/map" element={
          <Suspense fallback={<SuspenseFallback />}>
            <PageTransition><MapPage /></PageTransition>
          </Suspense>
        } />
        
        <Route path="/about" element={<PageTransition><AboutPage /></PageTransition>} />
        <Route path="/faq" element={<PageTransition><FAQPage /></PageTransition>} />
        <Route path="/blog" element={<PageTransition><BlogPage /></PageTransition>} />
        <Route path="/blog/:slug" element={<PageTransition><BlogDetailPage /></PageTransition>} />
        <Route path="/sitemap.xml" element={<SitemapGenerator />} />

        <Route path="/signup" element={<PageTransition><SignupPage /></PageTransition>} />
        <Route path="/login" element={<PageTransition><LoginPage /></PageTransition>} />
        <Route path="/settings" element={
          <ProtectedRoute>
            <PageTransition><UserSettingsPage /></PageTransition>
          </ProtectedRoute>
        } />
        <Route path="/dashboard" element={
          <ProtectedRoute>
            <Suspense fallback={<SuspenseFallback />}>
              <PageTransition><DashboardPage /></PageTransition>
            </Suspense>
          </ProtectedRoute>
        } />
        
        <Route path="/admin-login" element={
          <Suspense fallback={<SuspenseFallback />}>
            <PageTransition><AdminLoginPage /></PageTransition>
          </Suspense>
        } />
        <Route path="/admin-panel" element={
          <AdminProtectedRoute>
            <Suspense fallback={<SuspenseFallback />}>
              <PageTransition><AdminPanel /></PageTransition>
            </Suspense>
          </AdminProtectedRoute>
        } />
        
        <Route path="/admin" element={
          <AdminProtectedRoute>
            <Suspense fallback={<SuspenseFallback />}>
              <PageTransition><AdminPage /></PageTransition>
            </Suspense>
          </AdminProtectedRoute>
        } />

        <Route path="/owner/login" element={<PageTransition><BusinessOwnerLoginPage /></PageTransition>} />
        <Route path="/owner/signup" element={<PageTransition><BusinessOwnerSignupPage /></PageTransition>} />
        <Route path="/owner/dashboard" element={
          <BusinessOwnerProtectedRoute>
            <Suspense fallback={<SuspenseFallback />}>
              <PageTransition><BusinessOwnerDashboard /></PageTransition>
            </Suspense>
          </BusinessOwnerProtectedRoute>
        } />
        
        <Route path="/add-business" element={
          <BusinessOwnerProtectedRoute>
            <Suspense fallback={<SuspenseFallback />}>
              <PageTransition><BusinessOwnerAddPage /></PageTransition>
            </Suspense>
          </BusinessOwnerProtectedRoute>
        } />
        <Route path="/business-owner/add-business" element={
          <BusinessOwnerProtectedRoute>
            <Suspense fallback={<SuspenseFallback />}>
              <PageTransition><BusinessOwnerAddPage /></PageTransition>
            </Suspense>
          </BusinessOwnerProtectedRoute>
        } />
        <Route path="/owner/add-business" element={
          <BusinessOwnerProtectedRoute>
            <Suspense fallback={<SuspenseFallback />}>
              <PageTransition><BusinessOwnerAddPage /></PageTransition>
            </Suspense>
          </BusinessOwnerProtectedRoute>
        } />

        <Route path="/owner/edit/:id" element={
          <BusinessOwnerProtectedRoute>
            <Suspense fallback={<SuspenseFallback />}>
              <PageTransition><BusinessOwnerEditPage /></PageTransition>
            </Suspense>
          </BusinessOwnerProtectedRoute>
        } />
        <Route path="/owner/reviews/:businessId" element={
          <BusinessOwnerProtectedRoute>
            <Suspense fallback={<SuspenseFallback />}>
              <PageTransition><BusinessOwnerReviewsPage /></PageTransition>
            </Suspense>
          </BusinessOwnerProtectedRoute>
        } />

        <Route path="*" element={
          <PageTransition>
            <div className="min-h-screen flex flex-col items-center justify-center bg-background text-center p-4">
              <h1 className="text-6xl md:text-8xl font-extrabold text-foreground mb-4">404</h1>
              <h2 className="text-2xl md:text-3xl font-bold text-muted-foreground mb-8">העמוד לא נמצא</h2>
              <Link to="/" className="bg-primary text-primary-foreground px-6 py-3 rounded-xl font-medium hover:bg-primary/90 transition-colors shadow-md">
                חזרה לעמוד הבית
              </Link>
            </div>
          </PageTransition>
        } />
      </Routes>
    </AnimatePresence>
  );
};

function App() {
  useEffect(() => {
    // Redirect non-www to www domain
    if (window.location.hostname === 'asakimclick.com' && !window.location.hostname.startsWith('www')) {
      window.location.href = 'https://www.asakimclick.com' + window.location.pathname + window.location.search;
    }
  }, []);

  return (
    <Router>
      <AuthProvider>
        <AdminAuthProvider>
          <BusinessOwnerAuthProvider>
            <ScrollToTop />
            <AnimatedRoutes />
            <Toaster />
          </BusinessOwnerAuthProvider>
        </AdminAuthProvider>
      </AuthProvider>
    </Router>
  );
}

export default App;