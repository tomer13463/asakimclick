import React, { useState, useEffect, useRef } from 'react';
import { MapPin, Search, Loader2, Navigation, AlertCircle } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

const AddressAutocomplete = ({ initialAddress = '', onAddressSelect, onRawChange, disabled = false }) => {
  const [query, setQuery] = useState(initialAddress);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [error, setError] = useState('');
  const wrapperRef = useRef(null);
  const abortControllerRef = useRef(null);

  useEffect(() => {
    if (initialAddress && initialAddress !== query) {
      setQuery(initialAddress);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialAddress]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, []);

  const searchAddress = async (searchQuery) => {
    if (!searchQuery || searchQuery.length < 3) {
      setResults([]);
      setError('');
      return;
    }

    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    setLoading(true);
    setError('');
    
    abortControllerRef.current = new AbortController();
    const timeoutId = setTimeout(() => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    }, 5000);
    
    try {
      const params = new URLSearchParams({
        format: 'json',
        q: searchQuery,
        countrycodes: 'il',
        addressdetails: '1',
        limit: '5',
        'accept-language': 'he,en'
      });

      const response = await fetch(`https://nominatim.openstreetmap.org/search?${params.toString()}`, {
        signal: abortControllerRef.current.signal
      });
      
      clearTimeout(timeoutId);

      if (!response.ok) throw new Error('שגיאה בתקשורת עם שרת הכתובות');

      const data = await response.json();
      
      if (data.length === 0) {
        setError('לא נמצאו כתובות תואמות. נסה לחפש שוב או להזין את הכתובת ידנית.');
      } else {
        setResults(data);
        setIsOpen(true);
      }
    } catch (err) {
      clearTimeout(timeoutId);
      if (err.name === 'AbortError') {
        console.log('Geocoding request aborted or timed out');
        setError('זמן הבקשה עבר. אנא נסה שוב או הזן כתובת ידנית.');
      } else {
        console.error('Geocoding error:', err);
        setError('שגיאה בחיבור לשירות הכתובות. אנא הזן את הכתובת ידנית.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSelect = (place) => {
    const address = place.display_name;
    const city = place.address?.city || place.address?.town || place.address?.village || place.address?.municipality || '';
    const street = place.address?.road || place.address?.pedestrian || '';
    const buildingNumber = place.address?.house_number || '';
    const postalCode = place.address?.postcode || '';
    
    setQuery(address);
    setIsOpen(false);
    setError('');
    
    if (onAddressSelect) {
      onAddressSelect({
        address,
        city,
        street,
        buildingNumber,
        postalCode,
        latitude: parseFloat(place.lat),
        longitude: parseFloat(place.lon)
      });
    }
  };

  return (
    <div className="relative w-full" ref={wrapperRef}>
      <Label className="text-sm font-semibold mb-2 flex items-center gap-2">
        <Navigation className="h-4 w-4 text-primary" />
        כתובת העסק
      </Label>
      <div className="relative group">
        <Search className="absolute right-3.5 top-3.5 h-5 w-5 text-muted-foreground group-focus-within:text-primary transition-colors" />
        <Input
          value={query}
          onChange={(e) => {
            const val = e.target.value;
            setQuery(val);
            setError('');
            if (onRawChange) onRawChange(val);
            
            if (val.length >= 3) {
              const timeoutId = setTimeout(() => searchAddress(val), 600);
              return () => clearTimeout(timeoutId);
            } else {
              setResults([]);
              setIsOpen(false);
              setError('');
            }
          }}
          onFocus={() => results.length > 0 && setIsOpen(true)}
          placeholder="התחל להקליד כתובת (למשל: הרצל 10, תל אביב)..."
          disabled={disabled}
          className="h-12 pr-11 bg-background border-input rounded-xl focus-visible:ring-2 focus-visible:ring-primary/20 focus-visible:border-primary text-foreground shadow-sm transition-all text-base"
        />
        {loading && (
          <div className="absolute left-3 top-3.5 flex items-center justify-center">
            <Loader2 className="h-5 w-5 animate-spin text-primary" />
          </div>
        )}
      </div>

      {error && (
        <div className="flex items-center gap-1.5 mt-2 text-destructive">
          <AlertCircle className="h-3.5 w-3.5" />
          <p className="text-xs font-medium">{error}</p>
        </div>
      )}

      {isOpen && results.length > 0 && (
        <div className="absolute z-[100] w-full mt-2 bg-card border border-border rounded-xl shadow-xl overflow-hidden max-h-[300px] overflow-y-auto animate-in fade-in zoom-in-95 duration-200">
          <div className="p-1">
            {results.map((result, index) => (
              <button
                key={result.place_id || index}
                type="button"
                onClick={() => handleSelect(result)}
                className="w-full text-right px-3 py-3 hover:bg-muted rounded-lg transition-colors flex items-start gap-3 group"
              >
                <div className="bg-primary/10 p-2 rounded-lg group-hover:bg-primary/20 transition-colors shrink-0">
                  <MapPin className="h-4 w-4 text-primary" />
                </div>
                <div className="flex flex-col flex-1 overflow-hidden">
                  <span className="text-sm font-semibold text-foreground truncate">
                    {result.address?.road || result.display_name.split(',')[0]} {result.address?.house_number}
                  </span>
                  <span className="text-xs text-muted-foreground truncate opacity-80 mt-0.5">
                    {result.address?.city || result.address?.town}, {result.address?.country}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default AddressAutocomplete;