import React, { useEffect, useState, useCallback, useRef } from 'react';
import { MapContainer, TileLayer, Marker, useMapEvents, useMap } from 'react-leaflet';
import L from 'leaflet';
import { LocateFixed, MapPin, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

const createCustomIcon = () => {
  return L.divIcon({
    className: 'custom-map-marker',
    html: `<div style="display: flex; justify-content: center; align-items: center; width: 40px; height: 40px; background-color: hsl(var(--map-pin)); border-radius: 50% 50% 50% 0; transform: rotate(-45deg); box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.2); border: 3px solid white;">
            <div style="width: 14px; height: 14px; background: white; border-radius: 50%;"></div>
           </div>`,
    iconSize: [40, 40],
    iconAnchor: [20, 40],
    popupAnchor: [0, -40],
  });
};

const ISRAEL_CENTER = [31.7683, 35.2137];

const LocationMarker = ({ position, setPosition, onLocationChange }) => {
  const map = useMap();

  useMapEvents({
    click(e) {
      const { lat, lng } = e.latlng;
      setPosition({ lat, lng });
      map.flyTo([lat, lng], Math.max(map.getZoom(), 15), { duration: 0.8 });
      onLocationChange(lat, lng);
    },
  });

  useEffect(() => {
    if (position) {
      map.flyTo(position, Math.max(map.getZoom(), 14), { duration: 0.8 });
    }
  }, [position, map]);

  return position === null ? null : (
    <Marker position={position} icon={createCustomIcon()} />
  );
};

const CurrentLocationControl = ({ onLocationFound }) => {
  const map = useMap();
  const [locating, setLocating] = useState(false);

  const locateUser = useCallback(() => {
    setLocating(true);
    map.locate({ setView: true, maxZoom: 16 });
  }, [map]);

  useEffect(() => {
    const onLocation = (e) => {
      setLocating(false);
      onLocationFound(e.latlng.lat, e.latlng.lng);
    };
    
    const onError = (e) => {
      setLocating(false);
      toast.error('לא ניתן לקבל את המיקום הנוכחי. אנא ודא שאישרת גישה למיקום בהגדרות הדפדפן.');
    };

    map.on('locationfound', onLocation);
    map.on('locationerror', onError);

    return () => {
      map.off('locationfound', onLocation);
      map.off('locationerror', onError);
    };
  }, [map, onLocationFound]);

  return (
    <div className="absolute bottom-6 right-6 z-[400]">
      <Button
        variant="secondary"
        size="icon"
        onClick={(e) => { e.preventDefault(); locateUser(); }}
        className="h-12 w-12 rounded-full shadow-lg border border-border bg-background text-foreground hover:bg-muted transition-all hover:scale-105"
        title="המיקום שלי"
      >
        {locating ? <Loader2 className="h-5 w-5 animate-spin text-primary" /> : <LocateFixed className="h-5 w-5 text-primary" />}
      </Button>
    </div>
  );
};

const MapLocationPicker = ({ latitude, longitude, onLocationSelect }) => {
  const [position, setPosition] = useState(null);
  const [isGeocoding, setIsGeocoding] = useState(false);
  const abortControllerRef = useRef(null);

  useEffect(() => {
    if (latitude && longitude) {
      const lat = parseFloat(latitude);
      const lng = parseFloat(longitude);
      if (!isNaN(lat) && !isNaN(lng)) {
        setPosition({ lat, lng });
      }
    }
    
    return () => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, [latitude, longitude]);

  const performReverseGeocode = useCallback(async (lat, lng) => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    setIsGeocoding(true);
    abortControllerRef.current = new AbortController();
    
    const timeoutId = setTimeout(() => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    }, 5000);

    try {
      const params = new URLSearchParams({
        format: 'json',
        lat,
        lon: lng,
        addressdetails: '1',
        'accept-language': 'he,en'
      });
      
      const response = await fetch(`https://nominatim.openstreetmap.org/reverse?${params.toString()}`, {
        signal: abortControllerRef.current.signal
      });
      
      clearTimeout(timeoutId);
      
      if (!response.ok) throw new Error('Geocoding failed');
      const data = await response.json();
      
      const address = data.display_name || '';
      const city = data.address?.city || data.address?.town || data.address?.village || '';
      const street = data.address?.road || '';
      const buildingNumber = data.address?.house_number || '';

      onLocationSelect({ 
        latitude: lat, 
        longitude: lng,
        address,
        city,
        street,
        buildingNumber
      });
    } catch (err) {
      clearTimeout(timeoutId);
      if (err.name === 'AbortError') {
        console.log('Reverse geocoding request aborted or timed out');
        toast.error('זמן הבקשה עבר. שגיאה בקבלת כתובת מהמפה.');
      } else {
        console.error('Reverse geocoding error:', err);
        toast.error('שגיאה בקבלת כתובת מהמפה. המיקום נשמר ללא כתובת.');
      }
      onLocationSelect({ latitude: lat, longitude: lng });
    } finally {
      setIsGeocoding(false);
    }
  }, [onLocationSelect]);

  const handleMapClick = useCallback((lat, lng) => {
    performReverseGeocode(lat, lng);
  }, [performReverseGeocode]);

  return (
    <div className="relative h-full min-h-[400px] w-full rounded-2xl overflow-hidden border border-border shadow-sm group">
      {isGeocoding && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-[500] bg-background/95 backdrop-blur-sm px-4 py-2 rounded-full shadow-md border border-border flex items-center gap-2">
          <Loader2 className="h-4 w-4 animate-spin text-primary" />
          <span className="text-sm font-medium">מאתר כתובת...</span>
        </div>
      )}

      <MapContainer 
        center={position || ISRAEL_CENTER} 
        zoom={position ? 15 : 8} 
        scrollWheelZoom={true}
        style={{ height: '100%', width: '100%', zIndex: 0 }}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          className="map-tiles"
        />
        <LocationMarker 
          position={position} 
          setPosition={setPosition}
          onLocationChange={handleMapClick}
        />
        <CurrentLocationControl onLocationFound={handleMapClick} />
      </MapContainer>

      {!position && (
        <div className="absolute inset-0 z-[400] pointer-events-none flex items-center justify-center bg-background/10 backdrop-blur-[1px] transition-opacity duration-300 group-hover:opacity-0">
          <div className="bg-background/90 px-6 py-3 rounded-xl shadow-lg border border-border flex items-center gap-3">
            <MapPin className="h-5 w-5 text-primary animate-bounce" />
            <span className="font-medium">לחץ על המפה לבחירת מיקום</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default MapLocationPicker;