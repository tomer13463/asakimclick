import React, { useState, useRef, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Menu, X, Store, Search, MapPin, Star, Settings, ShieldAlert } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import pb from '@/lib/pocketbaseClient';
import { useAuth } from '@/contexts/AuthContext.jsx';
import { useAdminAuth } from '@/contexts/AdminAuthContext.jsx';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useSearch } from '@/hooks/useSearch.js';
import { cn } from '@/lib/utils';

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showDropdown, setShowDropdown] = useState(false);
  const [isVisible, setIsVisible] = useState(true);
  const [isMobile, setIsMobile] = useState(false);
  const dropdownRef = useRef(null);
  
  const location = useLocation();
  const navigate = useNavigate();
  const { isAuthenticated: userAuth, logout: userLogout } = useAuth();
  const { isAuthenticated: adminAuth, logout: adminLogout } = useAdminAuth();
  
  const currentUser = pb.authStore.model;
  const isSuperAdmin = adminAuth || currentUser?.collectionName === 'admin_users';

  const { results, loading } = useSearch(searchQuery);

  const isActive = (path) => location.pathname === path;

  const handleLogout = () => {
    if (userAuth) userLogout();
    if (adminAuth) adminLogout();
    pb.authStore.clear();
    navigate('/');
  };

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth <= 768);
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    let lastScrollY = window.scrollY;

    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      
      if (currentScrollY > lastScrollY && currentScrollY > 80) {
        setIsVisible(false);
        setShowDropdown(false);
      } else {
        setIsVisible(true);
      }
      
      lastScrollY = currentScrollY;
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Prevent body scroll when mobile menu is open
  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [mobileMenuOpen]);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setShowDropdown(false);
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const closeMenu = () => setMobileMenuOpen(false);

  return (
    <>
      <motion.header 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: isVisible ? 0 : -100 }}
        transition={{ duration: 0.3, ease: 'easeInOut' }}
        className="fixed top-0 w-full z-50 glass-panel bg-background/95 backdrop-blur-md border-b border-border/50"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20 gap-4">
            <Link to="/" className="flex items-center gap-2 font-bold text-2xl text-primary shrink-0 transition-transform duration-300 hover:scale-105">
              <Store className="h-8 w-8" />
              <span className="hidden sm:inline-block">עסקים בקליק</span>
            </Link>

            <div className="flex-1 max-w-xl relative" ref={dropdownRef}>
              <form onSubmit={handleSearchSubmit} className="relative group">
                <Input
                  type="text"
                  dir="rtl"
                  placeholder="חפש עסק..."
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setShowDropdown(true);
                  }}
                  onFocus={() => setShowDropdown(true)}
                  className="w-full pl-10 pr-4 h-11 rounded-full bg-secondary/50 border-transparent focus:bg-background focus:border-primary transition-all duration-300 group-hover:shadow-md text-right overflow-hidden text-ellipsis whitespace-nowrap"
                />
                <Button 
                  type="submit" 
                  variant="ghost" 
                  size="icon" 
                  className="absolute left-1 top-1/2 -translate-y-1/2 h-9 w-9 rounded-full text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors duration-300"
                >
                  <Search className="h-5 w-5" />
                </Button>
              </form>

              <AnimatePresence>
                {showDropdown && searchQuery.trim().length >= 2 && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute top-full left-0 right-0 mt-2 bg-card border rounded-2xl shadow-xl overflow-hidden z-50 max-h-[60vh] overflow-y-auto"
                  >
                    {loading ? (
                      <div className="p-4 text-center text-muted-foreground text-sm">מחפש...</div>
                    ) : results?.length > 0 ? (
                      <div className="py-2">
                        {results.map((biz) => (
                          <Link
                            key={biz.id}
                            to={`/business/${biz.id}`}
                            onClick={() => setShowDropdown(false)}
                            className="flex items-center gap-3 px-4 py-3 hover:bg-muted transition-colors duration-200"
                          >
                            <div className="w-10 h-10 rounded-lg bg-secondary flex items-center justify-center shrink-0">
                              <Store className="h-5 w-5 text-primary" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="font-medium truncate">{biz.name}</div>
                              <div className="text-xs text-muted-foreground flex items-center gap-2 truncate">
                                <span>{biz.primary_category || biz.category}</span>
                                <span>•</span>
                                <span className="flex items-center"><MapPin className="h-3 w-3 ml-0.5"/>{biz.city}</span>
                              </div>
                            </div>
                            <div className="flex items-center gap-1 text-sm font-medium text-amber-500 shrink-0">
                              <Star className="h-3 w-3 fill-current" />
                              {biz.rating?.toFixed(1) || '5.0'}
                            </div>
                          </Link>
                        ))}
                        <div className="border-t p-2">
                          <Button 
                            variant="ghost" 
                            className="w-full text-primary justify-center transition-colors hover:bg-primary/10"
                            onClick={handleSearchSubmit}
                          >
                            הצג את כל התוצאות
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="p-4 text-center text-muted-foreground text-sm">לא נמצאו תוצאות ל"{searchQuery}"</div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <nav className="hidden lg:flex items-center gap-2 shrink-0">
              <Link to="/categories">
                <Button variant={isActive('/categories') ? 'secondary' : 'ghost'} className="rounded-full transition-all hover:-translate-y-0.5">
                  כל הקטגוריות
                </Button>
              </Link>
              <Link to="/add-business">
                <Button variant={isActive('/add-business') ? 'secondary' : 'ghost'} className="rounded-full transition-all hover:-translate-y-0.5">
                  הוסף עסק
                </Button>
              </Link>
              
              {isSuperAdmin && (
                <Link to="/admin">
                  <Button variant="destructive" className="rounded-full gap-2 shadow-sm transition-all hover:-translate-y-0.5">
                    <ShieldAlert className="w-4 h-4" />
                    Admin Panel
                  </Button>
                </Link>
              )}

              {!userAuth && !adminAuth && !currentUser && (
                <Link to="/login">
                  <Button className="rounded-full ml-2 transition-all hover:-translate-y-0.5 hover:shadow-md">התחברות</Button>
                </Link>
              )}
              
              {(userAuth || currentUser) && !isSuperAdmin && (
                <>
                  <Link to="/settings">
                    <Button variant="ghost" size="icon" className="rounded-full text-muted-foreground hover:text-foreground transition-transform hover:rotate-45" title="הגדרות">
                      <Settings className="h-5 w-5" />
                    </Button>
                  </Link>
                  <Link to="/dashboard">
                    <Button variant="outline" className="rounded-full transition-all hover:-translate-y-0.5">הדשבורד שלי</Button>
                  </Link>
                  <Button variant="ghost" className="rounded-full hover:bg-destructive/10 hover:text-destructive transition-colors" onClick={handleLogout}>התנתק</Button>
                </>
              )}
              
              {isSuperAdmin && (
                <Button variant="ghost" className="rounded-full hover:bg-destructive/10 hover:text-destructive transition-colors" onClick={handleLogout}>התנתק</Button>
              )}
            </nav>

            <button
              className="lg:hidden p-2 text-foreground transition-transform active:scale-95"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="תפריט"
            >
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>
      </motion.header>

      {/* Mobile Drawer Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 z-[999] lg:hidden"
              onClick={closeMenu}
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 right-0 w-[85vw] max-w-sm h-[100dvh] bg-background z-[1000] shadow-2xl overflow-y-auto flex flex-col lg:hidden"
            >
              <div className="flex items-center justify-between p-4 border-b border-border/50">
                <div className="flex items-center gap-2 font-bold text-xl text-primary">
                  <Store className="h-6 w-6" />
                  <span>עסקים בקליק</span>
                </div>
                <Button variant="ghost" size="icon" onClick={closeMenu} className="rounded-full">
                  <X className="h-6 w-6" />
                </Button>
              </div>

              <nav className="flex flex-col gap-2 p-4 flex-1">
                <Link to="/" onClick={closeMenu}>
                  <Button variant={isActive('/') ? 'secondary' : 'ghost'} className="w-full justify-start transition-colors h-12 text-base">בית</Button>
                </Link>
                <Link to="/categories" onClick={closeMenu}>
                  <Button variant={isActive('/categories') ? 'secondary' : 'ghost'} className="w-full justify-start transition-colors h-12 text-base">כל הקטגוריות</Button>
                </Link>
                <Link to="/add-business" onClick={closeMenu}>
                  <Button variant={isActive('/add-business') ? 'secondary' : 'ghost'} className="w-full justify-start transition-colors h-12 text-base">הוסף עסק</Button>
                </Link>
                
                {isSuperAdmin && (
                  <Link to="/admin" onClick={closeMenu}>
                    <Button variant="destructive" className="w-full justify-start transition-colors gap-2 h-12 text-base mt-2">
                      <ShieldAlert className="w-5 h-5" />
                      Admin Panel
                    </Button>
                  </Link>
                )}

                <div className="h-px bg-border my-4" />
                
                {!userAuth && !adminAuth && !currentUser && (
                  <Link to="/login" onClick={closeMenu}>
                    <Button className="w-full transition-transform active:scale-[0.98] h-12 text-base">התחברות</Button>
                  </Link>
                )}
                
                {(userAuth || currentUser) && !isSuperAdmin && (
                  <>
                    <Link to="/settings" onClick={closeMenu}>
                      <Button variant={isActive('/settings') ? 'secondary' : 'ghost'} className="w-full justify-start transition-colors h-12 text-base">
                        <Settings className="ml-2 h-5 w-5" />
                        הגדרות חשבון
                      </Button>
                    </Link>
                    <Link to="/dashboard" onClick={closeMenu}>
                      <Button variant="outline" className="w-full transition-transform active:scale-[0.98] h-12 text-base mt-2">הדשבורד שלי</Button>
                    </Link>
                    <Button variant="ghost" className="w-full justify-start text-destructive hover:bg-destructive/10 transition-colors h-12 text-base mt-2" onClick={() => { handleLogout(); closeMenu(); }}>
                      התנתק
                    </Button>
                  </>
                )}

                {isSuperAdmin && (
                  <Button variant="ghost" className="w-full justify-start text-destructive hover:bg-destructive/10 transition-colors h-12 text-base mt-2" onClick={() => { handleLogout(); closeMenu(); }}>
                    התנתק
                  </Button>
                )}
              </nav>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
};

export default Header;