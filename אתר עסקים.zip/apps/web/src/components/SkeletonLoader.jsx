import React from 'react';
import { cn } from '@/lib/utils';

export default function SkeletonLoader({ type = 'card', count = 1, className }) {
  const items = Array.from({ length: count });

  const ShimmerBase = ({ className }) => (
    <div className={cn("relative overflow-hidden bg-muted", className)}>
      <div className="absolute inset-0 -translate-x-full animate-[shimmer_1.5s_infinite] bg-gradient-to-r from-transparent via-white/10 to-transparent" />
    </div>
  );

  if (type === 'card') {
    return (
      <>
        {items.map((_, i) => (
          <div key={i} className={cn("overflow-hidden rounded-3xl border-0 shadow-md bg-card", className)}>
            <ShimmerBase className="h-48 w-full" />
            <div className="p-6 space-y-4">
              <ShimmerBase className="h-6 w-3/4 rounded-md" />
              <div className="space-y-2">
                <ShimmerBase className="h-4 w-full rounded-md" />
                <ShimmerBase className="h-4 w-5/6 rounded-md" />
              </div>
              <ShimmerBase className="h-10 w-full rounded-xl mt-4" />
            </div>
          </div>
        ))}
      </>
    );
  }

  if (type === 'category') {
    return (
      <>
        {items.map((_, i) => (
          <div key={i} className={cn("h-40 rounded-3xl border border-border bg-card p-6 flex flex-col items-center justify-center gap-4", className)}>
            <ShimmerBase className="h-16 w-16 rounded-2xl" />
            <ShimmerBase className="h-5 w-24 rounded-md" />
          </div>
        ))}
      </>
    );
  }

  if (type === 'detail') {
    return (
      <div className={cn("w-full space-y-8 animate-fade-in", className)}>
        <ShimmerBase className="w-full h-[50vh] min-h-[400px] rounded-b-3xl" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-20 relative z-10 space-y-10">
          <div className="bg-card p-8 rounded-3xl shadow-lg border border-border space-y-4">
            <ShimmerBase className="h-10 w-1/3 rounded-lg" />
            <ShimmerBase className="h-6 w-1/4 rounded-md" />
            <div className="flex gap-4 mt-6">
              <ShimmerBase className="h-12 w-32 rounded-xl" />
              <ShimmerBase className="h-12 w-32 rounded-xl" />
            </div>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            <div className="lg:col-span-2 space-y-8">
              <ShimmerBase className="h-64 w-full rounded-3xl" />
              <ShimmerBase className="h-48 w-full rounded-3xl" />
            </div>
            <div className="space-y-8">
              <ShimmerBase className="h-80 w-full rounded-3xl" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (type === 'review') {
    return (
      <>
        {items.map((_, i) => (
          <div key={i} className={cn("p-6 rounded-2xl border-0 shadow-md bg-card flex gap-4", className)}>
            <ShimmerBase className="w-10 h-10 rounded-full shrink-0" />
            <div className="space-y-3 flex-1">
              <ShimmerBase className="h-5 w-32 rounded-md" />
              <ShimmerBase className="h-4 w-24 rounded-md" />
              <ShimmerBase className="h-16 w-full rounded-md mt-2" />
            </div>
          </div>
        ))}
      </>
    );
  }

  return (
    <div className={cn("space-y-2", className)}>
      <ShimmerBase className="h-4 w-full rounded-md" />
      <ShimmerBase className="h-4 w-5/6 rounded-md" />
    </div>
  );
}