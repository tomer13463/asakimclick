import React, { useState } from 'react';
import { Star, X, Upload, Loader2 } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import pb from '@/lib/pocketbaseClient';
import { useAuth } from '@/contexts/AuthContext.jsx';

const ReviewModal = ({ isOpen, onClose, businessId, onSuccess }) => {
  const { currentUser } = useAuth();
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [comment, setComment] = useState('');
  const [image, setImage] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  const handleImageChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setImage(e.target.files[0]);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (rating === 0) {
      toast.error('נא לבחור דירוג');
      return;
    }

    if (!currentUser) {
      toast.error('עליך להתחבר כדי להשאיר ביקורת');
      return;
    }

    setSubmitting(true);
    try {
      const formData = new FormData();
      formData.append('business_id', businessId);
      formData.append('user_id', currentUser.id);
      formData.append('user_name', currentUser.name || currentUser.email.split('@')[0]);
      formData.append('rating', rating);
      formData.append('comment', comment);
      formData.append('is_approved', false);
      formData.append('status', 'pending');
      
      if (image) {
        formData.append('image', image);
      }

      await pb.collection('reviews').create(formData, { $autoCancel: false });
      
      toast.success('הביקורת נשלחה בהצלחה ותפורסם לאחר אישור');
      
      // Reset form
      setRating(0);
      setComment('');
      setImage(null);
      
      if (onSuccess) onSuccess();
      onClose();
    } catch (error) {
      console.error('Error submitting review:', error);
      toast.error('שגיאה בשליחת הביקורת. נסה שוב.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[500px] bg-card p-0 overflow-hidden rounded-3xl border-border">
        <div className="p-6 border-b border-border flex justify-between items-center bg-muted/30">
          <DialogTitle className="text-2xl font-bold text-foreground">כתיבת ביקורת</DialogTitle>
          <Button variant="ghost" size="icon" onClick={onClose} className="rounded-full hover:bg-muted">
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="flex flex-col items-center justify-center space-y-3">
            <span className="text-sm font-medium text-muted-foreground">איך הייתה החוויה שלך?</span>
            <div className="flex gap-2" dir="ltr">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  className="focus:outline-none transition-transform hover:scale-110"
                  onMouseEnter={() => setHoveredRating(star)}
                  onMouseLeave={() => setHoveredRating(0)}
                  onClick={() => setRating(star)}
                >
                  <Star
                    className={`h-10 w-10 transition-colors ${
                      star <= (hoveredRating || rating)
                        ? 'fill-yellow-400 text-yellow-400'
                        : 'text-muted-foreground/30'
                    }`}
                  />
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">ספר לנו עוד (אופציונלי)</label>
            <Textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="מה אהבת? מה אפשר לשפר?"
              className="min-h-[120px] resize-none rounded-xl bg-background border-input"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">הוסף תמונה (אופציונלי)</label>
            <div className="flex items-center gap-4">
              <label className="flex items-center justify-center w-full h-24 border-2 border-dashed border-border rounded-xl cursor-pointer hover:bg-muted/50 transition-colors bg-background">
                <div className="flex flex-col items-center justify-center pt-5 pb-6">
                  <Upload className="h-6 w-6 text-muted-foreground mb-2" />
                  <p className="text-sm text-muted-foreground">לחץ להעלאת תמונה</p>
                </div>
                <input type="file" className="hidden" accept="image/*" onChange={handleImageChange} />
              </label>
              {image && (
                <div className="relative w-24 h-24 rounded-xl overflow-hidden shrink-0 border border-border">
                  <img src={URL.createObjectURL(image)} alt="Preview" className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => setImage(null)}
                    className="absolute top-1 right-1 bg-destructive text-destructive-foreground rounded-full p-1 shadow-sm"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              )}
            </div>
          </div>

          <div className="pt-4">
            <Button 
              type="submit" 
              className="w-full h-12 rounded-xl text-lg font-medium shadow-md" 
              disabled={submitting || rating === 0}
            >
              {submitting ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  שולח...
                </>
              ) : (
                'שלח ביקורת'
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default ReviewModal;