import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Layers, UtensilsCrossed, PawPrint as Paw, Shirt, Smartphone, Wine, Heart, Sparkles, Stethoscope, Droplet, LayoutGrid } from 'lucide-react';
import { motion } from 'framer-motion';
import pb from '@/lib/pocketbaseClient';
import { Card, CardContent } from '@/components/ui/card';

const getCategoryIcon = (name) => {
  if (!name) return <LayoutGrid className="h-6 w-6" />;
  if (name.includes('אוכל') || name.includes('מסעד') || name.includes('קפה')) return <UtensilsCrossed className="h-6 w-6" />;
  if (name.includes('חיים') || name.includes('בעלי')) return <Paw className="h-6 w-6" />;
  if (name.includes('ביגוד') || name.includes('נעליים')) return <Shirt className="h-6 w-6" />;
  if (name.includes('אלקטרוניקה') || name.includes('טכנולוגיה')) return <Smartphone className="h-6 w-6" />;
  if (name.includes('בר') || name.includes('אלכוהול') || name.includes('יין')) return <Wine className="h-6 w-6" />;
  if (name.includes('בריאות') || name.includes('כושר')) return <Heart className="h-6 w-6" />;
  if (name.includes('יופי') || name.includes('קוסמטיקה')) return <Sparkles className="h-6 w-6" />;
  if (name.includes('רפואי') || name.includes('רופא')) return <Stethoscope className="h-6 w-6" />;
  if (name.includes('בשמים')) return <Droplet className="h-6 w-6" />;
  return <LayoutGrid className="h-6 w-6" />;
};

const PopularCategoriesSection = () => {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCategoriesStats = async () => {
      try {
        setLoading(true);
        const cats = await pb.collection('categories').getFullList({ $autoCancel: false });
        
        const statsPromises = cats.map(async (cat) => {
          const result = await pb.collection('businesses').getList(1, 1, {
            filter: `primary_category="${cat.name}" && status="approved" && is_approved=true`,
            $autoCancel: false
          });
          return {
            id: cat.id,
            name: cat.name,
            count: result.totalItems
          };
        });

        const stats = await Promise.all(statsPromises);
        
        const topCategories = stats
          .filter(c => c.count > 0)
          .sort((a, b) => b.count - a.count)
          .slice(0, 8);

        setCategories(topCategories);
      } catch (err) {
        console.error('Error fetching categories stats:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchCategoriesStats();
  }, []);

  if (loading) {
    return (
      <section className="py-16 bg-secondary/30 section-padding">
        <div className="max-w-7xl mx-auto">
          <div className="h-8 bg-muted rounded w-64 mb-8 animate-pulse"></div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="h-24 bg-muted rounded-2xl animate-pulse"></div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  if (categories.length === 0) return null;

  return (
    <section className="py-16 bg-secondary/30 section-padding">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-3 mb-10">
          <div className="bg-primary/10 p-3 rounded-xl text-primary">
            <Layers className="h-6 w-6" />
          </div>
          <h2 className="text-2xl md:text-3xl font-bold text-foreground">קטגוריות פופולריות</h2>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {categories.map((cat, index) => (
            <motion.div
              key={cat.id}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.05 }}
            >
              <Link to={`/search?primary_category=${encodeURIComponent(cat.name)}`}>
                <Card className="h-full border-border/50 shadow-sm hover:border-primary/50 hover:shadow-md transition-all group rounded-2xl bg-card">
                  <CardContent className="p-5 md:p-6 flex flex-col items-center justify-center text-center gap-3">
                    <div className="w-12 h-12 md:w-14 md:h-14 rounded-xl bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                      {getCategoryIcon(cat.name)}
                    </div>
                    <h3 className="font-bold text-foreground group-hover:text-primary transition-colors text-base md:text-lg line-clamp-1">
                      {cat.name}
                    </h3>
                    <span className="text-xs md:text-sm font-medium text-muted-foreground bg-muted px-3 py-1 rounded-full">
                      {cat.count} עסקים
                    </span>
                  </CardContent>
                </Card>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PopularCategoriesSection;