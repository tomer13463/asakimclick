import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import pb from '@/lib/pocketbaseClient';
import { Loader2 } from 'lucide-react';

const SitemapGenerator = () => {
  const [sitemapXml, setSitemapXml] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const generateSitemap = async () => {
      try {
        const baseUrl = window.location.origin;
        const staticRoutes = [
          { url: '/', priority: '1.0' },
          { url: '/about', priority: '0.8' },
          { url: '/faq', priority: '0.8' },
          { url: '/blog', priority: '0.9' },
          { url: '/categories', priority: '0.8' },
          { url: '/search', priority: '0.9' }
        ];

        // Fetch dynamic content
        const businesses = await pb.collection('businesses').getFullList({
          filter: 'status="approved"',
          $autoCancel: false
        });

        const blogPosts = await pb.collection('blog_posts').getFullList({
          $autoCancel: false
        });

        const dynamicBusinessRoutes = businesses.map(b => ({
          url: `/business/${b.id}`,
          priority: '0.7',
          lastmod: b.updated.split(' ')[0]
        }));

        const dynamicBlogRoutes = blogPosts.map(p => ({
          url: `/blog/${p.slug}`,
          priority: '0.8',
          lastmod: p.updated.split(' ')[0]
        }));

        const allRoutes = [...staticRoutes, ...dynamicBusinessRoutes, ...dynamicBlogRoutes];
        const today = new Date().toISOString().split('T')[0];

        const xmlContent = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${allRoutes.map(route => `  <url>
    <loc>${baseUrl}${route.url}</loc>
    <lastmod>${route.lastmod || today}</lastmod>
    <priority>${route.priority}</priority>
  </url>`).join('\n')}
</urlset>`;

        setSitemapXml(xmlContent);
      } catch (error) {
        console.error('Error generating sitemap:', error);
        setSitemapXml('<!-- Error generating sitemap -->');
      } finally {
        setLoading(false);
      }
    };

    generateSitemap();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background text-foreground">
        <Loader2 className="w-8 h-8 animate-spin text-primary mr-2" />
        <span>מייצר מפת אתר...</span>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Sitemap.xml</title>
      </Helmet>
      <pre className="p-4 text-left font-mono text-sm bg-black text-green-400 min-h-screen whitespace-pre-wrap break-all" dir="ltr">
        {sitemapXml}
      </pre>
    </>
  );
};

export default SitemapGenerator;