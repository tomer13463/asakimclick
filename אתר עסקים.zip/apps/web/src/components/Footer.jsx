import React from 'react';
import { Link } from 'react-router-dom';
import { Store, Mail, Phone, Facebook, Instagram, Linkedin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-secondary text-secondary-foreground mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-10 md:gap-8">
          {/* Company Info */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <Store className="h-6 w-6 text-primary" />
              <span className="font-bold text-xl">עסקים בקליק</span>
            </div>
            <p className="text-base text-secondary-foreground/80 max-w-xs leading-relaxed">
              הפלטפורמה המובילה למציאת עסקים מומלצים בישראל. מחפשים עסק? מצאו אותו כאן.
            </p>
          </div>

          {/* Quick Links */}
          <div className="border-t border-border/50 md:border-0 pt-6 md:pt-0">
            <span className="font-bold text-lg mb-4 block">קישורים מהירים</span>
            <nav className="flex flex-col gap-1">
              <Link to="/" className="min-h-[44px] flex items-center text-base text-secondary-foreground/80 hover:text-primary transition-colors">
                בית
              </Link>
              <Link to="/categories" className="min-h-[44px] flex items-center text-base text-secondary-foreground/80 hover:text-primary transition-colors">
                קטגוריות
              </Link>
              <Link to="/add-business" className="min-h-[44px] flex items-center text-base text-secondary-foreground/80 hover:text-primary transition-colors">
                הוסף עסק
              </Link>
              <Link to="/login" className="min-h-[44px] flex items-center text-base text-secondary-foreground/80 hover:text-primary transition-colors">
                התחברות
              </Link>
            </nav>
          </div>

          {/* Pages */}
          <div className="border-t border-border/50 md:border-0 pt-6 md:pt-0">
            <span className="font-bold text-lg mb-4 block">עמודים</span>
            <nav className="flex flex-col gap-1">
              <Link to="/about" className="min-h-[44px] flex items-center text-base text-secondary-foreground/80 hover:text-primary transition-colors">
                אודות
              </Link>
              <Link to="/faq" className="min-h-[44px] flex items-center text-base text-secondary-foreground/80 hover:text-primary transition-colors">
                שאלות ותשובות
              </Link>
              <Link to="/blog" className="min-h-[44px] flex items-center text-base text-secondary-foreground/80 hover:text-primary transition-colors">
                בלוג
              </Link>
            </nav>
          </div>

          {/* Contact */}
          <div className="border-t border-border/50 md:border-0 pt-6 md:pt-0">
            <span className="font-bold text-lg mb-4 block">צור קשר</span>
            <div className="flex flex-col gap-1">
              <a href="mailto:tomer13463@gmail.com" className="min-h-[44px] flex items-center gap-3 text-base text-secondary-foreground/80 hover:text-primary transition-colors" dir="ltr">
                <Mail className="h-5 w-5 shrink-0" />
                <span className="truncate">tomer13463@gmail.com</span>
              </a>
              <a href="tel:+972502352985" className="min-h-[44px] flex items-center gap-3 text-base text-secondary-foreground/80 hover:text-primary transition-colors" dir="ltr">
                <Phone className="h-5 w-5 shrink-0" />
                <span>050-235-2985</span>
              </a>
            </div>
            
            <div className="flex gap-4 mt-6">
              <a href="#" className="w-11 h-11 rounded-full bg-background/50 flex items-center justify-center text-secondary-foreground/80 hover:text-primary hover:bg-background transition-colors shadow-sm" aria-label="פייסבוק">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="w-11 h-11 rounded-full bg-background/50 flex items-center justify-center text-secondary-foreground/80 hover:text-primary hover:bg-background transition-colors shadow-sm" aria-label="אינסטגרם">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="w-11 h-11 rounded-full bg-background/50 flex items-center justify-center text-secondary-foreground/80 hover:text-primary hover:bg-background transition-colors shadow-sm" aria-label="לינקדאין">
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-border/50 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-6 text-center md:text-right">
          <p className="text-sm text-secondary-foreground/70">
            © 2026 עסקים בקליק. כל הזכויות שמורות.
          </p>
          <div className="flex flex-wrap justify-center gap-6">
            <Link to="/privacy" className="text-sm text-secondary-foreground/70 hover:text-primary transition-colors">
              מדיניות פרטיות
            </Link>
            <Link to="/terms" className="text-sm text-secondary-foreground/70 hover:text-primary transition-colors">
              תנאי שימוש
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;