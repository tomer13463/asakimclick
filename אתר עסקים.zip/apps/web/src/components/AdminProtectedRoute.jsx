import React from 'react';
import { Link } from 'react-router-dom';
import pb from '@/lib/pocketbaseClient';

const AdminProtectedRoute = ({ children }) => {
  const isAdmin = pb.authStore.isValid && pb.authStore.model?.collectionName === 'admin_users';

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background text-center p-4">
        <h1 className="text-6xl md:text-8xl font-extrabold text-destructive mb-4">404</h1>
        <h2 className="text-2xl md:text-3xl font-bold text-muted-foreground mb-8">Access Denied - Admin Only</h2>
        <Link to="/" className="bg-primary text-primary-foreground px-6 py-3 rounded-xl font-medium hover:bg-primary/90 transition-colors shadow-md">
          חזרה לעמוד הבית
        </Link>
      </div>
    );
  }

  return children;
};

export default AdminProtectedRoute;