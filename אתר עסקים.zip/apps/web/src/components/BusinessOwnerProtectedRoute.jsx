import React from 'react';
import { Navigate } from 'react-router-dom';
import { useBusinessOwnerAuth } from '@/contexts/BusinessOwnerAuthContext.jsx';

const BusinessOwnerProtectedRoute = ({ children }) => {
  const { isAuthenticated, initialLoading } = useBusinessOwnerAuth();

  if (initialLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/owner/login" replace />;
  }

  return children;
};

export default BusinessOwnerProtectedRoute;