import React, { useMemo } from 'react';
import { Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

// Helper to get current time in HH:MM format
const getCurrentTimeStr = () => {
  const now = new Date();
  return `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
};

const BusinessHoursStatus = ({ openingHoursJSON, className }) => {
  const status = useMemo(() => {
    if (!openingHoursJSON) return null;

    try {
      const hours = typeof openingHoursJSON === 'string' 
        ? JSON.parse(openingHoursJSON) 
        : openingHoursJSON;

      if (!Array.isArray(hours) || hours.length === 0) return null;

      const now = new Date();
      // JS getDay() returns 0 for Sunday. Our default array has index 0 as Sunday.
      const currentDayIndex = now.getDay();
      const todayHours = hours[currentDayIndex];

      if (!todayHours || todayHours.isClosed) {
        // Find next open day
        let nextOpen = null;
        for (let i = 1; i <= 7; i++) {
          const checkIndex = (currentDayIndex + i) % 7;
          const checkDay = hours[checkIndex];
          if (checkDay && !checkDay.isClosed && checkDay.open) {
            nextOpen = `${checkDay.day} ב-${checkDay.open}`;
            break;
          }
        }
        return { 
          isOpen: false, 
          message: 'סגור כעת', 
          subMessage: nextOpen ? `נפתח ב-${nextOpen}` : '' 
        };
      }

      const currentTimeStr = getCurrentTimeStr();
      
      if (currentTimeStr >= todayHours.open && currentTimeStr <= todayHours.close) {
        return { 
          isOpen: true, 
          message: 'פתוח עכשיו', 
          subMessage: `נסגר ב-${todayHours.close}` 
        };
      }

      if (currentTimeStr < todayHours.open) {
        return { 
          isOpen: false, 
          message: 'סגור כעת', 
          subMessage: `נפתח היום ב-${todayHours.open}` 
        };
      }

      // Past closing time today
      let nextOpen = null;
      for (let i = 1; i <= 7; i++) {
        const checkIndex = (currentDayIndex + i) % 7;
        const checkDay = hours[checkIndex];
        if (checkDay && !checkDay.isClosed && checkDay.open) {
          nextOpen = `${checkDay.day} ב-${checkDay.open}`;
          break;
        }
      }

      return { 
        isOpen: false, 
        message: 'סגור כעת', 
        subMessage: nextOpen ? `נפתח ב-${nextOpen}` : '' 
      };

    } catch (e) {
      console.error('Error parsing business hours:', e);
      return null;
    }
  }, [openingHoursJSON]);

  if (!status) return null;

  return (
    <div className={cn("flex flex-col gap-1", className)}>
      <div className="flex items-center gap-2">
        <div className={cn(
          "px-2.5 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 shadow-sm border",
          status.isOpen 
            ? "bg-green-100/50 text-green-700 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-800" 
            : "bg-red-100/50 text-red-700 border-red-200 dark:bg-red-900/20 dark:text-red-400 dark:border-red-800"
        )}>
          <Clock className="h-3.5 w-3.5" />
          {status.message}
        </div>
      </div>
      {status.subMessage && (
        <span className="text-xs font-medium text-muted-foreground ml-1">
          {status.subMessage}
        </span>
      )}
    </div>
  );
};

export default BusinessHoursStatus;