import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Star, MessageCircle, User } from 'lucide-react';
import { motion } from 'framer-motion';
import pb from '@/lib/pocketbaseClient';
import { Card, CardContent } from '@/components/ui/card';

const RecentReviewsSection = () => {
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchReviews = async () => {
      try {
        setLoading(true);
        const reviewsData = await pb.collection('reviews').getList(1, 5, {
          sort: '-created',
          filter: 'status="approved" && is_approved=true',
          $autoCancel: false
        });

        const businessIds = [...new Set(reviewsData.items.map(r => r.business_id).filter(Boolean))];
        
        let businesses = {};
        if (businessIds.length > 0) {
          const filterStr = businessIds.map(id => `id="${id}"`).join(' || ');
          const businessesData = await pb.collection('businesses').getFullList({
            filter: filterStr,
            $autoCancel: false
          });
          businessesData.forEach(b => {
            businesses[b.id] = b.name;
          });
        }

        const enrichedReviews = reviewsData.items.map(review => ({
          ...review,
          business_name: businesses[review.business_id] || 'עסק לא ידוע'
        }));

        setReviews(enrichedReviews);
      } catch (err) {
        console.error('Error fetching recent reviews:', err);
        setError('שגיאה בטעינת ביקורות אחרונות');
      } finally {
        setLoading(false);
      }
    };

    fetchReviews();
  }, []);

  if (loading) {
    return (
      <div className="py-16 bg-muted/30 section-padding">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">ביקורות אחרונות</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(3)].map((_, i) => (
              <Card key={`skeleton-review-${i}`} className="animate-pulse border-0 shadow-md">
                <CardContent className="p-6">
                  <div className="h-4 bg-muted rounded w-1/3 mb-4"></div>
                  <div className="h-16 bg-muted rounded w-full mb-4"></div>
                  <div className="flex justify-between items-center">
                    <div className="h-4 bg-muted rounded w-1/4"></div>
                    <div className="h-4 bg-muted rounded w-1/4"></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error || reviews.length === 0) {
    return (
      <section className="py-16 bg-muted/30 section-padding">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-3 mb-8 md:mb-10">
            <div className="bg-primary/10 p-3 rounded-xl text-primary">
              <MessageCircle className="h-6 w-6" />
            </div>
            <h2 className="text-2xl md:text-3xl font-bold text-foreground">ביקורות אחרונות</h2>
          </div>
          <div className="bg-card border border-dashed border-border rounded-3xl p-12 text-center flex flex-col items-center justify-center">
            <MessageCircle className="h-12 w-12 text-muted-foreground/50 mb-4" />
            <h3 className="text-xl font-bold text-foreground mb-2">עדיין אין ביקורות להצגה</h3>
            <p className="text-muted-foreground">היה הראשון לכתוב ביקורת על עסק שביקרת בו!</p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 bg-muted/30 section-padding">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-3 mb-8 md:mb-10">
          <div className="bg-primary/10 p-3 rounded-xl text-primary">
            <MessageCircle className="h-6 w-6" />
          </div>
          <h2 className="text-2xl md:text-3xl font-bold text-foreground">ביקורות אחרונות</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reviews.map((review, index) => (
            <motion.div
              key={review.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Link to={`/business/${review.business_id}`}>
                <Card className="h-full border-0 shadow-md hover:shadow-lg transition-all hover:-translate-y-1 bg-card rounded-2xl">
                  <CardContent className="p-5 md:p-6 flex flex-col h-full">
                    <div className="flex justify-between items-start mb-4">
                      <h3 className="font-bold text-base md:text-lg text-foreground hover:text-primary transition-colors line-clamp-1">
                        {review.business_name}
                      </h3>
                      <div className="flex shrink-0">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            className={`h-3 w-3 md:h-4 md:w-4 ${i < review.rating ? 'fill-yellow-400 text-yellow-400' : 'text-muted-foreground/30'}`} 
                          />
                        ))}
                      </div>
                    </div>
                    
                    <p className="text-muted-foreground line-clamp-3 mb-6 flex-1 text-sm leading-relaxed">
                      "{review.comment}"
                    </p>
                    
                    <div className="flex justify-between items-center pt-4 border-t border-border mt-auto">
                      <div className="flex items-center gap-2 text-sm text-foreground font-medium">
                        <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center text-muted-foreground">
                          <User className="h-4 w-4" />
                        </div>
                        {review.user_name || 'משתמש אנונימי'}
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {new Date(review.created).toLocaleDateString('he-IL')}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default RecentReviewsSection;