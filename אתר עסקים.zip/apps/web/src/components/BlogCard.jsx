import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, ArrowLeft } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import { Card, CardContent } from '@/components/ui/card';

const BlogCard = ({ post }) => {
  const imageUrl = post.featured_image 
    ? pb.files.getUrl(post, post.featured_image) 
    : 'https://images.unsplash.com/photo-1432888498266-38ffec3eaf0a?q=80&w=800&auto=format&fit=crop';
    
  const date = new Date(post.created).toLocaleDateString('he-IL', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return (
    <Card className="h-full flex flex-col overflow-hidden rounded-2xl border-border hover:shadow-lg transition-all duration-300 group bg-card">
      <div className="relative h-48 overflow-hidden">
        <img 
          src={imageUrl} 
          alt={post.title} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        {post.category && (
          <div className="absolute top-4 right-4 bg-background/90 backdrop-blur-sm text-foreground text-xs font-bold px-3 py-1.5 rounded-full">
            {post.category}
          </div>
        )}
      </div>
      
      <CardContent className="flex flex-col flex-grow p-6">
        <div className="flex items-center text-muted-foreground text-xs mb-3">
          <Calendar className="w-3.5 h-3.5 ml-1.5" />
          <span>{date}</span>
        </div>
        
        <h3 className="text-xl font-bold text-foreground mb-3 leading-snug group-hover:text-primary transition-colors">
          {post.title}
        </h3>
        
        <p className="text-muted-foreground text-sm line-clamp-3 mb-6 flex-grow">
          {post.excerpt}
        </p>
        
        <Link 
          to={`/blog/${post.slug}`}
          className="inline-flex items-center text-sm font-semibold text-primary mt-auto hover:text-primary/80 transition-colors"
        >
          קרא עוד
          <ArrowLeft className="w-4 h-4 mr-1.5 transition-transform group-hover:-translate-x-1" />
        </Link>
      </CardContent>
    </Card>
  );
};

export default BlogCard;