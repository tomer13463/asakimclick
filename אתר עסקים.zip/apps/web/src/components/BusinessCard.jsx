import React from 'react';
import { Link } from 'react-router-dom';
import { Star, MapPin, Phone, MessageCircle, Store, Navigation } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const BusinessCard = ({ business }) => {
  const hasImages = business.images && business.images.length > 0;
  
  // Handle both standard PocketBase file uploads and auto-generated image URLs
  const imageUrl = hasImages 
    ? (business.images[0].startsWith('http') ? business.images[0] : pb.files.getUrl(business, business.images[0], { thumb: '400x300' }))
    : null;

  return (
    <Link to={`/business/${business.id}`} className="block h-full">
      <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1 h-full flex flex-col rounded-3xl border-0 bg-card shadow-md group">
        <div className="relative h-48 overflow-hidden bg-muted">
          {imageUrl ? (
            <img 
              src={imageUrl} 
              alt={business.name} 
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" 
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center p-4 text-center bg-secondary/20">
              <Store className="h-12 w-12 text-primary/30 mb-2 transition-transform duration-500 group-hover:scale-110 group-hover:text-primary/50" />
              <span className="text-sm font-bold text-primary/40">
                {business.subcategory || business.primary_category || 'תמונה לא זמינה'}
              </span>
            </div>
          )}
          
          {business.distance !== undefined && business.distance !== null && (
            <div className="absolute top-3 left-3 bg-background/95 backdrop-blur-md px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm">
              <Navigation className="h-3.5 w-3.5 text-primary" />
              <span className="text-foreground">
                {business.distance < 1 ? `${(business.distance * 1000).toFixed(0)} מ'` : `${business.distance.toFixed(1)} ק"מ`}
              </span>
            </div>
          )}
          
          <div className="absolute top-3 right-3 bg-background/95 backdrop-blur-md px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm">
            <Star className="h-3.5 w-3.5 fill-yellow-400 text-yellow-400" />
            <span className="text-foreground">{business.rating?.toFixed(1) || '5.0'}</span>
          </div>
        </div>
        
        <CardContent className="p-5 flex-1 flex flex-col">
          <div className="flex flex-wrap gap-2 mb-3">
            <span className="bg-primary/10 text-primary text-xs px-2.5 py-1 rounded-lg font-bold">
              {business.primary_category}
            </span>
            {business.subcategory && (
              <span className="bg-secondary/70 text-secondary-foreground text-xs px-2.5 py-1 rounded-lg font-medium">
                {business.subcategory}
              </span>
            )}
          </div>
          
          <h3 className="text-xl font-bold mb-2 text-foreground line-clamp-1 group-hover:text-primary transition-colors">
            {business.name}
          </h3>
          
          <div className="flex items-center gap-2 mb-4 text-muted-foreground">
            <MapPin className="h-4 w-4 shrink-0" />
            <span className="text-sm truncate">{business.city}</span>
            {business.reviews_count > 0 && (
              <>
                <span className="text-xs opacity-50">•</span>
                <span className="text-sm">{business.reviews_count} ביקורות</span>
              </>
            )}
          </div>
          
          {business.description && (
            <p className="text-sm text-muted-foreground mb-6 line-clamp-2 leading-relaxed">
              {business.description}
            </p>
          )}
          
          <div className="flex gap-2 mt-auto pt-2">
            {business.phone && (
              <Button 
                variant="outline" 
                size="sm" 
                className="flex-1 rounded-xl bg-background hover:bg-secondary border-border" 
                onClick={(e) => { e.preventDefault(); window.location.href = `tel:${business.phone}`; }}
              >
                <Phone className="ml-2 h-4 w-4 text-primary" />
                התקשר
              </Button>
            )}
            {business.whatsapp && (
              <Button 
                size="sm" 
                className="flex-1 rounded-xl bg-[#25D366] hover:bg-[#20BA5A] text-white border-none shadow-sm" 
                onClick={(e) => { e.preventDefault(); window.open(`https://wa.me/${business.whatsapp.replace(/[^0-9]/g, '')}`, '_blank'); }}
              >
                <MessageCircle className="ml-2 h-4 w-4" />
                וואטסאפ
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </Link>
  );
};

export default BusinessCard;