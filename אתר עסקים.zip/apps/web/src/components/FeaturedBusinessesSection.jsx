import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Star, MapPin, Store, ChevronLeft } from 'lucide-react';
import { motion } from 'framer-motion';
import pb from '@/lib/pocketbaseClient';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const FeaturedBusinessesSection = () => {
  const [businesses, setBusinesses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchFeatured = async () => {
      try {
        setLoading(true);
        const result = await pb.collection('businesses').getList(1, 6, {
          filter: 'rating >= 4 && status = "approved" && is_approved = true',
          sort: '-rating',
          $autoCancel: false
        });
        setBusinesses(result.items);
      } catch (err) {
        console.error('Error fetching featured businesses:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchFeatured();
  }, []);

  if (loading) {
    return (
      <section className="py-16 md:py-20 relative z-20 bg-background section-padding">
        <div className="max-w-7xl mx-auto">
          <div className="h-10 bg-muted rounded w-48 mb-12 animate-pulse"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {[...Array(3)].map((_, i) => (
              <Card key={`skeleton-${i}`} className="overflow-hidden rounded-3xl border-border/50 shadow-sm animate-pulse">
                <div className="h-56 bg-muted"></div>
                <CardContent className="p-6">
                  <div className="h-6 bg-muted rounded w-3/4 mb-4"></div>
                  <div className="h-4 bg-muted rounded w-1/2"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    );
  }

  if (businesses.length === 0) {
    return (
      <section className="py-16 md:py-20 relative z-20 bg-background section-padding">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-end mb-8 md:mb-12">
            <div>
              <h2 className="text-2xl md:text-4xl font-bold text-foreground mb-2">עסקים מומלצים</h2>
              <p className="text-muted-foreground text-base md:text-lg">בתי העסק עם הדירוג הגבוה ביותר</p>
            </div>
          </div>
          <div className="bg-muted/30 border border-dashed border-border rounded-3xl p-12 text-center flex flex-col items-center justify-center">
            <Store className="h-12 w-12 text-muted-foreground/50 mb-4" />
            <h3 className="text-xl font-bold text-foreground mb-2">עדיין אין עסקים מומלצים להצגה</h3>
            <p className="text-muted-foreground">העסקים המדורגים ביותר יופיעו כאן בקרוב.</p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 md:py-20 relative z-20 bg-background rounded-t-[2rem] md:rounded-t-[3rem] -mt-6 md:-mt-8 section-padding">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-end mb-8 md:mb-12">
          <div>
            <h2 className="text-2xl md:text-4xl font-bold text-foreground mb-2">עסקים מומלצים</h2>
            <p className="text-muted-foreground text-base md:text-lg">בתי העסק עם הדירוג הגבוה ביותר</p>
          </div>
          <Link to="/search">
            <Button variant="ghost" className="rounded-full hidden sm:flex">
              צפה בכל העסקים
              <ChevronLeft className="mr-2 h-4 w-4" />
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {businesses.map((business, index) => (
            <motion.div
              key={`featured-${business.id}`}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Link to={`/business/${business.id}`} className="block h-full">
                <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-2 h-full flex flex-col rounded-3xl border-0 bg-card shadow-md group">
                  <div className="relative h-48 md:h-56 bg-muted overflow-hidden">
                    {business.images && business.images.length > 0 ? (
                      <img
                        src={business.images[0].startsWith('http') ? business.images[0] : pb.files.getUrl(business, business.images[0], { thumb: '600x400' })}
                        alt={business.name}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-secondary/50">
                        <Store className="h-16 w-16 text-muted-foreground/30" />
                      </div>
                    )}
                    <div className="absolute top-4 right-4 bg-background/90 backdrop-blur-sm px-3 py-1.5 rounded-full text-sm font-bold flex items-center gap-1.5 shadow-sm">
                      <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
                      <span className="text-foreground">{business.rating?.toFixed(1) || '5.0'}</span>
                    </div>
                  </div>
                  
                  <CardContent className="p-5 md:p-6 flex-1 flex flex-col">
                    <div className="flex flex-wrap gap-2 mb-3">
                      <span className="bg-primary/10 text-primary text-xs px-2.5 py-1 rounded-lg font-bold">
                        {business.primary_category}
                      </span>
                    </div>
                    
                    <h3 className="text-xl md:text-2xl font-bold mb-2 text-foreground group-hover:text-primary transition-colors line-clamp-1">
                      {business.name}
                    </h3>
                    
                    <div className="flex items-center gap-2 text-muted-foreground mt-auto pt-4 border-t border-border/50">
                      <MapPin className="h-4 w-4" />
                      <span className="text-sm font-medium">{business.city}</span>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            </motion.div>
          ))}
        </div>
        
        <div className="mt-8 text-center sm:hidden">
          <Link to="/search">
            <Button variant="outline" className="rounded-full w-full h-12">
              צפה בכל העסקים
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default FeaturedBusinessesSection;