import React from 'react';
import { Copy, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';

const DAYS_OF_WEEK = ['ראשון', 'שני', 'שלישי', 'רביעי', 'חמישי', 'שישי', 'שבת'];

export const defaultHours = DAYS_OF_WEEK.map(day => ({
  day,
  open: '09:00',
  close: '18:00',
  isClosed: day === 'שבת'
}));

const OpeningHoursTable = ({ hours = defaultHours, onChange }) => {
  const handleRowChange = (index, field, value) => {
    const newHours = [...hours];
    newHours[index] = { ...newHours[index], [field]: value };
    onChange(newHours);
  };

  const copyFirstDay = () => {
    if (!hours || hours.length === 0) return;
    const firstDay = hours[0];
    const newHours = hours.map((h, i) => 
      i === 0 ? h : { ...h, open: firstDay.open, close: firstDay.close, isClosed: firstDay.isClosed }
    );
    onChange(newHours);
  };

  return (
    <div className="space-y-4 bg-card border border-border rounded-xl p-4 md:p-6 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Clock className="h-5 w-5 text-primary" />
          <h3 className="text-lg font-bold text-foreground">שעות פעילות</h3>
        </div>
        <Button 
          type="button" 
          variant="outline" 
          size="sm" 
          onClick={copyFirstDay}
          className="text-xs rounded-lg"
        >
          <Copy className="h-3.5 w-3.5 ml-1.5" />
          העתק מיום ראשון
        </Button>
      </div>

      <div className="space-y-3">
        {hours.map((schedule, index) => (
          <div key={schedule.day} className="flex flex-col md:flex-row md:items-center gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors border border-transparent hover:border-border/50">
            <div className="w-24 font-medium text-foreground">
              יום {schedule.day}
            </div>
            
            <div className="flex items-center gap-3 flex-1">
              <div className="flex items-center gap-2">
                <Checkbox 
                  id={`closed-${index}`} 
                  checked={schedule.isClosed}
                  onCheckedChange={(checked) => handleRowChange(index, 'isClosed', checked)}
                />
                <Label htmlFor={`closed-${index}`} className="text-sm cursor-pointer">סגור</Label>
              </div>

              <div className="flex items-center gap-2 flex-1 md:mr-6">
                <Input
                  type="time"
                  value={schedule.open}
                  onChange={(e) => handleRowChange(index, 'open', e.target.value)}
                  disabled={schedule.isClosed}
                  className="h-9 text-sm"
                />
                <span className="text-muted-foreground">-</span>
                <Input
                  type="time"
                  value={schedule.close}
                  onChange={(e) => handleRowChange(index, 'close', e.target.value)}
                  disabled={schedule.isClosed}
                  className="h-9 text-sm"
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default OpeningHoursTable;