import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import { ArrowRight, Star, Store, MapPin } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

const iconUrl = 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png';
const iconRetinaUrl = 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png';
const shadowUrl = 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png';

const customIcon = new L.Icon({
  iconUrl,
  iconRetinaUrl,
  shadowUrl,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const MapPage = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [businesses, setBusinesses] = useState([]);
  const [loading, setLoading] = useState(true);
  
  const [center, setCenter] = useState([31.7683, 35.2137]);
  const [zoom, setZoom] = useState(8);

  const fetchMapData = useCallback(async () => {
    setLoading(true);
    try {
      const filterParts = ['status="approved"', 'is_approved=true'];
      
      const city = searchParams.get('city');
      const category = searchParams.get('category');
      
      if (city && city !== 'all') {
        filterParts.push(`city="${city}"`);
      }
      if (category && category !== 'all') {
        filterParts.push(`category="${category}"`);
      }

      const results = await pb.collection('businesses').getFullList({
        filter: filterParts.join(' && '),
        $autoCancel: false
      });

      const mappedResults = results.filter(b => b.latitude && b.longitude);
      setBusinesses(mappedResults);

      if (mappedResults.length > 0) {
        const sumLat = mappedResults.reduce((sum, b) => sum + parseFloat(b.latitude), 0);
        const sumLon = mappedResults.reduce((sum, b) => sum + parseFloat(b.longitude), 0);
        setCenter([sumLat / mappedResults.length, sumLon / mappedResults.length]);
        setZoom(city !== 'all' ? 12 : 9);
      }
    } catch (error) {
      console.error('Error fetching map data:', error);
      toast.error('שגיאה בטעינת המפה');
    } finally {
      setLoading(false);
    }
  }, [searchParams]);

  useEffect(() => {
    fetchMapData();
  }, [fetchMapData]);

  return (
    <>
      <Helmet>
        <title>מפת עסקים - עסקים בקליק</title>
      </Helmet>

      <div className="h-screen w-full flex flex-col bg-background relative">
        <div className="absolute top-4 left-4 right-4 z-[400] flex justify-between items-start pointer-events-none">
          <Button 
            variant="default" 
            className="rounded-full shadow-lg pointer-events-auto gap-2 bg-background text-foreground hover:bg-muted"
            onClick={() => navigate(-1)}
          >
            <ArrowRight className="h-4 w-4" />
            חזרה לרשימה
          </Button>

          <div className="bg-background/95 backdrop-blur-md px-4 py-2 rounded-xl shadow-lg border border-border pointer-events-auto">
            <h1 className="font-bold flex items-center gap-2">
              <MapPin className="h-4 w-4 text-primary" />
              מפת עסקים
            </h1>
            <p className="text-xs text-muted-foreground mt-0.5">
              מציג {businesses.length} עסקים באזור
            </p>
          </div>
        </div>

        {loading ? (
          <div className="flex-1 flex items-center justify-center bg-muted/50">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          </div>
        ) : (
          <div className="flex-1 w-full relative z-0">
            <MapContainer 
              center={center} 
              zoom={zoom} 
              className="h-full w-full"
              zoomControl={false}
            >
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
              {businesses.map((biz) => (
                <Marker 
                  key={biz.id} 
                  position={[parseFloat(biz.latitude), parseFloat(biz.longitude)]}
                  icon={customIcon}
                >
                  <Popup className="custom-popup" dir="rtl">
                    <div className="text-right min-w-[200px]">
                      {biz.images && biz.images.length > 0 ? (
                        <div className="h-24 w-full rounded-md overflow-hidden mb-2">
                          <img src={pb.files.getUrl(biz, biz.images[0], { thumb: '200x100' })} className="w-full h-full object-cover" />
                        </div>
                      ) : (
                        <div className="h-24 w-full bg-muted rounded-md flex items-center justify-center mb-2">
                          <Store className="h-8 w-8 text-muted-foreground/50" />
                        </div>
                      )}
                      
                      <span className="text-[10px] bg-primary/10 text-primary px-1.5 py-0.5 rounded-sm font-semibold mb-1 inline-block">
                        {biz.category}
                      </span>
                      <h3 className="font-bold text-sm m-0 leading-tight">{biz.name}</h3>
                      
                      <div className="flex items-center gap-1 my-1.5">
                        <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                        <span className="text-xs font-medium">{biz.rating?.toFixed(1) || '5.0'}</span>
                      </div>
                      
                      <p className="text-xs text-muted-foreground truncate mb-3">{biz.address}, {biz.city}</p>
                      
                      <Button 
                        size="sm" 
                        className="w-full h-8 text-xs" 
                        onClick={() => navigate(`/business/${biz.id}`)}
                      >
                        לצפייה בעמוד העסק
                      </Button>
                    </div>
                  </Popup>
                </Marker>
              ))}
            </MapContainer>
          </div>
        )}
      </div>
    </>
  );
};

export default MapPage;