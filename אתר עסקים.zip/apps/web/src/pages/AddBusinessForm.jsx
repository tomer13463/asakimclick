import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Upload, Store, Loader2 } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

const MASTER_CATEGORIES = [
  'שירותי תחזוקה ובית', 
  'מקצועות', 
  'חנויות', 
  'מסעדות וקפה'
];

// EXACT cities from database schema - character-for-character match
const CITIES = [
  'תל אביב',
  'ירושלים',
  'חיפה',
  'באר שבע',
  'ראשון לציון',
  'פתח תקווה',
  'אשדוד',
  'נתניה',
  'רמת גן',
  'גבעתיים',
  'כפר סבא',
  'הרצליה',
  'רעננה',
  'מודיעין',
  'לוד',
  'רמלה',
  'אשקלון',
  'קריית שמונה',
  'צפת',
  'טבריה'
];

const AddBusinessForm = () => {
  const navigate = useNavigate();
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    primary_category: '',
    city: '',
    address: '',
    phone: '',
    whatsapp: '',
    website: '',
    description: '',
    opening_hours: '',
    services: ''
  });
  const [images, setImages] = useState([]);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleImageChange = (e) => {
    const files = Array.from(e.target.files);
    if (files.length + images.length > 10) {
      toast.error('ניתן להעלות עד 10 תמונות');
      return;
    }
    setImages(prev => [...prev, ...files]);
  };

  const removeImage = (index) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.name || !formData.primary_category || !formData.city) {
      toast.error('נא למלא את כל השדות החובה');
      return;
    }

    setSubmitting(true);
    try {
      const formDataToSend = new FormData();
      Object.keys(formData).forEach(key => {
        if (formData[key]) {
          formDataToSend.append(key, formData[key]);
        }
      });
      
      formDataToSend.append('status', 'pending');
      formDataToSend.append('is_approved', false);
      formDataToSend.append('rating', 5);
      formDataToSend.append('reviews_count', 0);
      formDataToSend.append('is_featured', false);
      
      if (pb.authStore.isValid) {
        formDataToSend.append('owner_id', pb.authStore.model.id);
      }

      images.forEach((image) => {
        formDataToSend.append('images', image);
      });

      await pb.collection('businesses').create(formDataToSend, { $autoCancel: false });

      toast.success('העסק נשלח לבדיקה ויעלה לאתר בקרוב');
      navigate('/dashboard');
    } catch (error) {
      console.error('Error creating business:', error);
      toast.error('שגיאה בשליחת העסק. נסה שוב.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>הוסף עסק - עסקים בקליק</title>
        <meta name="description" content="הוסף את העסק שלך לפלטפורמה והגדל את החשיפה שלך" />
      </Helmet>

      <div className="min-h-screen bg-background flex flex-col">
        <Header />

        <div className="flex-1 max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28 w-full">
          <div className="text-center mb-10">
            <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <Store className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-4xl font-extrabold mb-4 text-foreground">הוסף עסק חדש</h1>
            <p className="text-xl text-muted-foreground">
              מלא את הפרטים והעסק שלך יעלה לאתר לאחר אישור
            </p>
          </div>

          <Card className="rounded-3xl border border-border shadow-lg bg-card">
            <CardContent className="p-6 md:p-10">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <Label htmlFor="name" className="font-semibold mb-2 block">שם העסק *</Label>
                  <Input
                    id="name"
                    type="text"
                    value={formData.name}
                    onChange={(e) => handleChange('name', e.target.value)}
                    placeholder="הזן שם עסק"
                    className="h-12 bg-background border-input rounded-xl text-foreground placeholder:text-muted-foreground"
                    required
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label className="font-semibold mb-2 block">קטגוריה ראשית *</Label>
                    <Select key="category-select" value={formData.primary_category || undefined} onValueChange={(value) => handleChange('primary_category', value)} required>
                      <SelectTrigger className="h-12 bg-background border-input rounded-xl text-right text-foreground">
                        <SelectValue placeholder="בחר קטגוריה" />
                      </SelectTrigger>
                      <SelectContent>
                        {MASTER_CATEGORIES.map((cat, index) => (
                          <SelectItem key={`cat-${index}-${cat}`} value={cat}>{cat}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="font-semibold mb-2 block">עיר *</Label>
                    <Select key="city-select" value={formData.city || undefined} onValueChange={(value) => handleChange('city', value)} required>
                      <SelectTrigger className="h-12 bg-background border-input rounded-xl text-right text-foreground">
                        <SelectValue placeholder="בחר עיר" />
                      </SelectTrigger>
                      <SelectContent>
                        {CITIES.map((city, index) => (
                          <SelectItem key={`city-${index}-${city}`} value={city}>{city}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="address" className="font-semibold mb-2 block">כתובת</Label>
                  <Input
                    id="address"
                    type="text"
                    value={formData.address}
                    onChange={(e) => handleChange('address', e.target.value)}
                    placeholder="רחוב ומספר בית"
                    className="h-12 bg-background border-input rounded-xl text-foreground placeholder:text-muted-foreground"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="phone" className="font-semibold mb-2 block">טלפון</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => handleChange('phone', e.target.value)}
                      placeholder="050-1234567"
                      className="h-12 bg-background border-input rounded-xl text-foreground placeholder:text-muted-foreground"
                      dir="ltr"
                    />
                  </div>

                  <div>
                    <Label htmlFor="whatsapp" className="font-semibold mb-2 block">וואטסאפ</Label>
                    <Input
                      id="whatsapp"
                      type="tel"
                      value={formData.whatsapp}
                      onChange={(e) => handleChange('whatsapp', e.target.value)}
                      placeholder="972501234567"
                      className="h-12 bg-background border-input rounded-xl text-foreground placeholder:text-muted-foreground"
                      dir="ltr"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="website" className="font-semibold mb-2 block">אתר אינטרנט</Label>
                  <Input
                    id="website"
                    type="url"
                    value={formData.website}
                    onChange={(e) => handleChange('website', e.target.value)}
                    placeholder="https://example.com"
                    className="h-12 bg-background border-input rounded-xl text-foreground placeholder:text-muted-foreground"
                    dir="ltr"
                  />
                </div>

                <div>
                  <Label htmlFor="description" className="font-semibold mb-2 block">תיאור העסק</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => handleChange('description', e.target.value)}
                    placeholder="ספר על העסק שלך..."
                    rows={4}
                    className="bg-background border-input rounded-xl resize-none text-foreground placeholder:text-muted-foreground"
                  />
                </div>

                <div>
                  <Label htmlFor="opening_hours" className="font-semibold mb-2 block">שעות פתיחה</Label>
                  <Textarea
                    id="opening_hours"
                    value={formData.opening_hours}
                    onChange={(e) => handleChange('opening_hours', e.target.value)}
                    placeholder="ראשון-חמישי: 09:00-18:00&#10;שישי: 09:00-14:00"
                    rows={3}
                    className="bg-background border-input rounded-xl resize-none text-foreground placeholder:text-muted-foreground"
                  />
                </div>

                <div>
                  <Label htmlFor="services" className="font-semibold mb-2 block">שירותים</Label>
                  <Textarea
                    id="services"
                    value={formData.services}
                    onChange={(e) => handleChange('services', e.target.value)}
                    placeholder="פרט את השירותים שהעסק מציע..."
                    rows={3}
                    className="bg-background border-input rounded-xl resize-none text-foreground placeholder:text-muted-foreground"
                  />
                </div>

                <div>
                  <Label className="font-semibold mb-2 block">תמונות (עד 10)</Label>
                  <div className="mt-2">
                    <label className="flex flex-col items-center justify-center w-full aspect-video md:aspect-[3/1] border-2 border-dashed border-border rounded-xl cursor-pointer hover:bg-muted/50 transition-colors bg-background">
                      <Upload className="h-10 w-10 text-muted-foreground/60 mb-3" />
                      <span className="text-base font-medium text-foreground">לחץ להעלאת תמונות</span>
                      <span className="text-sm text-muted-foreground mt-1">JPEG, PNG, WEBP</span>
                      <input
                        type="file"
                        multiple
                        accept="image/*"
                        onChange={handleImageChange}
                        className="hidden"
                      />
                    </label>
                  </div>
                  {images.length > 0 && (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                      {images.map((image, index) => (
                        <div key={`img-${index}`} className="relative group rounded-xl overflow-hidden aspect-video border border-border">
                          <img
                            src={URL.createObjectURL(image)}
                            alt={`תמונה ${index + 1}`}
                            className="w-full h-full object-cover"
                          />
                          <button
                            type="button"
                            onClick={() => removeImage(index)}
                            className="absolute top-2 right-2 bg-destructive text-destructive-foreground rounded-full w-8 h-8 flex items-center justify-center text-lg opacity-0 group-hover:opacity-100 transition-opacity shadow-md"
                          >
                            ×
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <Button type="submit" className="w-full h-14 text-lg rounded-xl shadow-lg mt-8" disabled={submitting}>
                  {submitting ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      שולח...
                    </>
                  ) : (
                    'שלח בקשה לאישור'
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        <Footer />
      </div>
    </>
  );
};

export default AddBusinessForm;