import React, { useState, useMemo, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Search, Navigation, LayoutGrid, Star, ArrowLeft } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import pb from '@/lib/pocketbaseClient';
import { useGeolocation } from '@/hooks/useGeolocation.js';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import BusinessCard from '@/components/BusinessCard.jsx';
import SkeletonLoader from '@/components/SkeletonLoader.jsx';
import PopularCategoriesSection from '@/components/PopularCategoriesSection.jsx';
import FeaturedBusinessesSection from '@/components/FeaturedBusinessesSection.jsx';
import RecentReviewsSection from '@/components/RecentReviewsSection.jsx';

const cities = ['תל אביב', 'ירושלים', 'חיפה', 'באר שבע', 'ראשון לציון', 'פתח תקווה', 'אשדוד', 'נתניה', 'רמת גן', 'גבעתיים'];

const HomePage = () => {
  const navigate = useNavigate();
  const { getLocation, loading: locationLoading } = useGeolocation();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCity, setSelectedCity] = useState('');

  const memoizedCityItems = useMemo(() => {
    return cities
      .filter((c, i, a) => a.indexOf(c) === i)
      .map((city, index) => (
        <SelectItem key={`city-${index}-${city}`} value={city}>{city}</SelectItem>
      ));
  }, []);

  const handleSearch = () => {
    const params = new URLSearchParams();
    if (searchQuery) params.set('q', searchQuery);
    if (selectedCity && selectedCity !== 'all') params.set('city', selectedCity);
    navigate(`/search?${params.toString()}`);
  };

  const handleNearMeClick = async () => {
    try {
      const coords = await getLocation();
      navigate(`/search?nearMe=true&lat=${coords.latitude}&lon=${coords.longitude}`);
    } catch (error) {
      toast.error(error);
    }
  };

  return (
    <>
      <Helmet>
        <title>עסקים בקליק - עמוד הבית</title>
        <meta name="description" content="הפלטפורמה המובילה למציאת עסקים מומלצים בישראל. חפש לפי קטגוריה, עיר או שם עסק." />
      </Helmet>

      <div className="min-h-screen bg-background flex flex-col">
        <Header />

        {/* Hero Section */}
        <section className="relative min-h-[80vh] flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 z-0">
            <img
              src="https://images.unsplash.com/photo-1556761175-5973dc0f32d7?q=80&w=2000&auto=format&fit=crop"
              alt="רקע עסקים"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-background/90 via-background/60 to-background"></div>
          </div>

          <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center w-full pt-24 pb-20 md:pt-32 md:pb-32">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            >
              <span className="inline-block py-1 px-3 rounded-full bg-primary/10 text-primary font-medium text-sm mb-6 border border-primary/20">
                הפלטפורמה המובילה לעסקים בישראל
              </span>
              <h1 className="text-clamp-hero font-extrabold text-foreground mb-4 md:mb-6 tracking-tight" style={{ textBalance: 'balance' }}>
                מצא את העסק <span className="text-primary">המושלם</span> בשבילך
              </h1>
              <p className="text-lg md:text-2xl text-muted-foreground mb-10 md:mb-12 max-w-2xl mx-auto leading-relaxed">
                חיפוש חכם ומהיר מתוך אלפי עסקים מומלצים, מדורגים ומאומתים.
              </p>
            </motion.div>

            {/* Search Bar */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="bg-card/80 backdrop-blur-xl rounded-3xl shadow-2xl p-4 md:p-6 mx-auto border border-border/50"
            >
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="md:col-span-2">
                  <Input
                    type="text"
                    placeholder="מה מחפשים? (למשל: מסעדה איטלקית, מוסך...)"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="h-14 text-lg bg-background/50 transition-shadow focus:shadow-md"
                    onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                  />
                </div>
                
                <Select 
                  key="home-city-select"
                  value={selectedCity || undefined} 
                  onValueChange={setSelectedCity}
                >
                  <SelectTrigger className="h-14 text-lg bg-background/50">
                    <SelectValue placeholder="באיזו עיר?" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem key="city-all-option" value="all">כל הערים</SelectItem>
                    {memoizedCityItems}
                  </SelectContent>
                </Select>

                <div className="flex gap-2">
                  <Button onClick={handleSearch} className="flex-1 h-14 text-lg rounded-xl transition-transform active:scale-95">
                    <Search className="ml-2 h-5 w-5" />
                    חפש
                  </Button>
                  <Button 
                    onClick={handleNearMeClick} 
                    disabled={locationLoading}
                    variant="secondary"
                    className="h-14 px-4 rounded-xl bg-accent text-accent-foreground hover:bg-accent/90 transition-transform active:scale-95"
                    title="קרוב אליי"
                  >
                    <Navigation className="h-5 w-5" />
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        <FeaturedBusinessesSection />
        <PopularCategoriesSection />
        <RecentReviewsSection />

        <div className="mt-auto">
          <Footer />
        </div>
      </div>
    </>
  );
};

export default HomePage;