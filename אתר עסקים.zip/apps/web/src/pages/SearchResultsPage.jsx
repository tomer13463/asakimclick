import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Filter, X, Store, Navigation, Map, AlertCircle, RefreshCcw } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import pb from '@/lib/pocketbaseClient';
import { calculateDistance } from '@/hooks/useDistance.js';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import BusinessCard from '@/components/BusinessCard.jsx';
import SkeletonLoader from '@/components/SkeletonLoader.jsx';
import { cn } from '@/lib/utils';

const RAW_CITIES = ['תל אביב', 'ירושלים', 'חיפה', 'באר שבע', 'ראשון לציון', 'פתח תקווה', 'אשדוד', 'נתניה', 'רמת גן', 'גבעתיים', 'כפר סבא', 'הרצליה', 'רעננה', 'מודיעין', 'לוד', 'רמלה', 'אשקלון', 'קריית שמונה', 'צפת', 'טבריה'];

const MASTER_CATEGORIES = [
  'שירותי תחזוקה ובית', 
  'מקצועות', 
  'חנויות', 
  'מסעדות וקפה'
];

const CATEGORY_MAPPING = {
  'שירותי תחזוקה ובית': [
    'מוסכניק', 'חשמלאי', 'אינסטלטור', 'נגר', 'צבע', 'בנאי', 'גינון', 'ניקוי', 
    'כביסה וגיהוץ', 'תיקון מכשירים', 'תיקון רהיטים', 'הסעות', 'משלוחים', 
    'ניקוי שטיחים', 'ניקוי מזגנים', 'תיקון דלתות וחלונות', 'בדיקת בתים', 'ניקוי בריכות'
  ],
  'מקצועות': [
    'טיפול בעלים', 'הדרכה', 'תרגום', 'עיצוב גרפי', 'בניית אתרים', 'שירותי חשבונות', 
    'ייעוץ עסקי', 'ביטוח', 'משכנתא', 'עורך דין', 'רופא שיניים', 'רופא', 
    'פיזיותרפיה', 'קוסמטיקה', 'ספר', "מסאז'", 'כושר גופני', 'יוגה'
  ],
  'חנויות': [
    'ביגוד', 'נעליים', 'תכשיטים', 'ספרים', 'צעצועים', 'חיות מחמד', 'אלקטרוניקה', 
    'ריהוט', 'כלים', 'ספורט', 'גיטרות', 'מצלמות', 'משקפיים', 'שעונים', 'בשמים', 
    'תרופות', 'מזון בריא', 'קפה', 'תה', 'יין', 'בירה', 'סיגרים', 'טבק', 'מתנות', 
    'פרחים', 'צמחים'
  ],
  'מסעדות וקפה': [
    'מטבח', 'צילום', 'וידאו', 'מוזיקה', 'אירוח', 'מלון', 'מסעדה', 'בר', 'קפה', 'בר קוקטיילים'
  ]
};

const SearchResultsPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const [businesses, setBusinesses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [totalPages, setTotalPages] = useState(1);
  const [currentPage, setCurrentPage] = useState(1);
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);

  const isNearMe = searchParams.get('nearMe') === 'true';
  const userLat = parseFloat(searchParams.get('lat'));
  const userLon = parseFloat(searchParams.get('lon'));

  const cities = useMemo(() => {
    return RAW_CITIES
      .filter((c) => c && c.trim() !== '')
      .filter((c, i, a) => a.indexOf(c) === i);
  }, []);

  const [filters, setFilters] = useState({
    city: searchParams.get('city') || 'all',
    primary_category: searchParams.get('primary_category') || 'all',
    subcategory: searchParams.get('subcategory') || 'all',
    minRating: searchParams.get('minRating') || 'all',
    featured: searchParams.get('featured') === 'true'
  });
  
  const [sortBy, setSortBy] = useState(isNearMe ? 'distance' : (searchParams.get('sort') || 'rating'));

  const availableSubcategories = useMemo(() => {
    if (filters.primary_category === 'all') return [];
    return CATEGORY_MAPPING[filters.primary_category] || [];
  }, [filters.primary_category]);

  const updateUrlParams = useCallback((newFilters) => {
    const params = new URLSearchParams(searchParams);
    Object.keys(newFilters).forEach(key => {
      if (newFilters[key] !== 'all' && newFilters[key] !== false) {
        params.set(key, newFilters[key]);
      } else {
        params.delete(key);
      }
    });
    setSearchParams(params);
  }, [searchParams, setSearchParams]);

  const fetchBusinesses = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const filterParts = ['is_approved=true', 'status="approved"'];
      const query = searchParams.get('q');
      
      if (query) {
        const safeQuery = query.replace(/"/g, '\\"');
        filterParts.push(`(name~"${safeQuery}" || description~"${safeQuery}" || primary_category~"${safeQuery}" || subcategory~"${safeQuery}")`);
      }
      if (!isNearMe && filters.city && filters.city !== 'all') {
        filterParts.push(`city="${filters.city}"`);
      }
      if (filters.primary_category && filters.primary_category !== 'all') {
        filterParts.push(`primary_category="${filters.primary_category}"`);
      }
      if (filters.subcategory && filters.subcategory !== 'all') {
        filterParts.push(`subcategory="${filters.subcategory}"`);
      }
      if (filters.minRating && filters.minRating !== 'all') {
        filterParts.push(`rating>=${filters.minRating}`);
      }
      if (filters.featured) {
        filterParts.push('is_featured=true');
      }

      const filterString = filterParts.join(' && ');

      if (isNearMe && userLat && userLon) {
        const result = await pb.collection('businesses').getFullList({
          filter: filterString,
          $autoCancel: false
        });

        const withDistance = result.map(biz => ({
          ...biz,
          distance: calculateDistance(userLat, userLon, biz.latitude, biz.longitude)
        })).filter(biz => biz.distance !== null);

        withDistance.sort((a, b) => (a.distance || 9999) - (b.distance || 9999));
        const perPage = 12;
        const total = Math.ceil(withDistance.length / perPage);
        const start = (currentPage - 1) * perPage;
        const paginatedItems = withDistance.slice(start, start + perPage);

        setBusinesses(paginatedItems);
        setTotalPages(total || 1);
      } else {
        let sortField = '-rating';
        if (sortBy === 'newest') sortField = '-created';
        if (sortBy === 'rating') sortField = '-rating';

        const result = await pb.collection('businesses').getList(currentPage, 12, {
          filter: filterString,
          sort: sortField,
          $autoCancel: false
        });

        setBusinesses(result.items);
        setTotalPages(result.totalPages);
      }
    } catch (err) {
      console.error('Error fetching businesses:', err);
      setError(err.message || 'אירעה שגיאה בטעינת התוצאות. אנא נסה שוב.');
    } finally {
      setLoading(false);
    }
  }, [searchParams, filters, sortBy, currentPage, isNearMe, userLat, userLon]);

  useEffect(() => {
    if (isNearMe && sortBy !== 'distance') {
      setSortBy('distance');
    }
    fetchBusinesses();
  }, [fetchBusinesses, isNearMe, sortBy]);

  const handleFilterChange = useCallback((key, value) => {
    const newFilters = { ...filters, [key]: value };
    if (key === 'primary_category') newFilters.subcategory = 'all';
    setFilters(newFilters);
    updateUrlParams(newFilters);
    setCurrentPage(1);
  }, [filters, updateUrlParams]);

  const clearFilters = useCallback(() => {
    const defaultFilters = { city: 'all', primary_category: 'all', subcategory: 'all', minRating: 'all', featured: false };
    setFilters(defaultFilters);
    setSearchParams(new URLSearchParams());
    setSortBy('rating');
    setCurrentPage(1);
  }, [setSearchParams]);

  const clearNearMe = useCallback(() => {
    searchParams.delete('nearMe');
    searchParams.delete('lat');
    searchParams.delete('lon');
    setSearchParams(searchParams);
    setSortBy('rating');
    setCurrentPage(1);
  }, [searchParams, setSearchParams]);

  const openMap = useCallback(() => {
    navigate(`/map?${searchParams.toString()}`);
  }, [navigate, searchParams]);

  const FiltersContent = () => (
    <div className="space-y-6 md:space-y-8 animate-fade-in">
      <div>
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-bold text-foreground">קטגוריות</h3>
          {filters.primary_category !== 'all' && (
            <button onClick={() => handleFilterChange('primary_category', 'all')} className="text-xs text-primary hover:underline font-medium">
              נקה בחירה
            </button>
          )}
        </div>
        <div className="space-y-1.5">
          <button
            onClick={() => handleFilterChange('primary_category', 'all')}
            className={cn("w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-all text-sm", filters.primary_category === 'all' ? "bg-primary text-primary-foreground font-semibold shadow-sm" : "text-foreground hover:bg-muted")}
          >
            <span>כל הקטגוריות</span>
          </button>
          {MASTER_CATEGORIES.map((cat) => (
            <button
              key={`category-filter-${cat}`}
              onClick={() => handleFilterChange('primary_category', cat)}
              className={cn("w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all text-sm text-right", filters.primary_category === cat ? "bg-primary/10 text-primary font-semibold" : "text-foreground hover:bg-muted hover:text-primary")}
            >
              <span>{cat}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="h-px bg-border/50 w-full" />

      {!isNearMe && (
        <div>
          <h3 className="font-bold mb-3 text-foreground">עיר</h3>
          <Select key="filter-city" value={filters.city || undefined} onValueChange={(value) => handleFilterChange('city', value)}>
            <SelectTrigger className="text-right bg-background rounded-xl">
              <SelectValue placeholder="כל הערים" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem key="city-all" value="all">כל הערים</SelectItem>
              {cities.map((city, index) => (
                <SelectItem key={`city-${index}-${city}`} value={city}>{city}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      <div>
        <h3 className="font-bold mb-3 text-foreground">דירוג מינימלי</h3>
        <Select key="filter-minrating" value={filters.minRating || undefined} onValueChange={(value) => handleFilterChange('minRating', value)}>
          <SelectTrigger className="text-right bg-background rounded-xl">
            <SelectValue placeholder="כל הדירוגים" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem key="rating-all" value="all">כל הדירוגים</SelectItem>
            <SelectItem key="rating-4" value="4">4+ כוכבים</SelectItem>
            <SelectItem key="rating-4.5" value="4.5">4.5+ כוכבים</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex items-center gap-3 bg-secondary/30 p-4 rounded-xl border border-border/50">
        <Checkbox id="featured" checked={filters.featured} onCheckedChange={(c) => handleFilterChange('featured', c)} className="rounded-md" />
        <Label htmlFor="featured" className="cursor-pointer font-semibold select-none leading-none">עסקים מומלצים בלבד</Label>
      </div>

      <Button variant="outline" onClick={clearFilters} className="w-full rounded-xl mt-4">
        נקה את כל הסינונים
      </Button>
    </div>
  );

  return (
    <>
      <Helmet>
        <title>תוצאות חיפוש - עסקים בקליק</title>
        <meta name="description" content="תוצאות חיפוש עסקים מומלצים בישראל" />
      </Helmet>

      <div className="min-h-screen bg-background flex flex-col">
        <Header />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-1 w-full mt-20 section-padding">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 md:mb-8 gap-4">
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5 }}>
              <h1 className="text-2xl md:text-4xl font-extrabold text-foreground mb-2">תוצאות חיפוש</h1>
              {searchParams.get('q') && (
                <p className="text-muted-foreground text-sm md:text-base">מציג תוצאות עבור: <span className="font-medium text-foreground">"{searchParams.get('q')}"</span></p>
              )}
            </motion.div>
            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5 }} className="flex flex-wrap items-center gap-3 w-full md:w-auto">
              <Button onClick={openMap} className="rounded-xl shadow-md border-border shrink-0 flex-1 md:flex-none">
                <Map className="ml-2 h-4 w-4" />
                הצג במפה
              </Button>
              <Select key="sort-results" value={sortBy || undefined} onValueChange={(val) => { setSortBy(val); updateUrlParams({...filters, sort: val}); }} disabled={isNearMe}>
                <SelectTrigger className="w-full md:w-[220px] text-right bg-card rounded-xl shadow-sm">
                  <SelectValue placeholder="מיין לפי" />
                </SelectTrigger>
                <SelectContent>
                  {isNearMe && <SelectItem key="sort-distance" value="distance">הכי קרוב</SelectItem>}
                  <SelectItem key="sort-rating" value="rating">הכי מומלץ (ברירת מחדל)</SelectItem>
                  <SelectItem key="sort-newest" value="newest">הכי חדש</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" className="md:hidden rounded-xl shrink-0 w-full mt-2" onClick={() => setMobileFiltersOpen(!mobileFiltersOpen)}>
                <Filter className="ml-2 h-4 w-4" /> {mobileFiltersOpen ? 'הסתר סינון' : 'סינון מתקדם'}
              </Button>
            </motion.div>
          </div>

          {isNearMe && (
            <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="bg-accent/10 border border-accent/20 text-accent-foreground px-4 py-3 rounded-xl flex items-center justify-between mb-6 md:mb-8 shadow-sm">
              <div className="flex items-center gap-2">
                <Navigation className="h-5 w-5 text-accent shrink-0" />
                <span className="font-medium text-sm md:text-base">חיפוש עסקים קרובים אליי פעיל (לפי מרחק)</span>
              </div>
              <Button variant="ghost" size="sm" onClick={clearNearMe} className="hover:bg-accent/20 rounded-lg h-8 px-2 shrink-0">
                <X className="h-4 w-4 ml-1" /> בטל
              </Button>
            </motion.div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 md:gap-8">
            <aside className="hidden md:block md:col-span-3">
              <div className="sticky top-28">
                <Card className="rounded-3xl border-0 shadow-lg overflow-hidden bg-card">
                  <CardContent className="p-6">
                    <FiltersContent />
                  </CardContent>
                </Card>
              </div>
            </aside>

            {/* Mobile Inline Filters */}
            <AnimatePresence>
              {mobileFiltersOpen && (
                <motion.div 
                  initial={{ height: 0, opacity: 0 }} 
                  animate={{ height: 'auto', opacity: 1 }} 
                  exit={{ height: 0, opacity: 0 }} 
                  className="md:hidden overflow-hidden mb-6"
                >
                  <Card className="rounded-2xl border border-border shadow-sm">
                    <CardContent className="p-5">
                      <FiltersContent />
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="md:col-span-9">
              <AnimatePresence>
                {filters.primary_category !== 'all' && availableSubcategories.length > 0 && (
                  <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="mb-6 md:mb-8">
                    <div className="flex items-center gap-2 md:gap-3 overflow-x-auto pb-4 hide-scrollbar snap-x">
                      <Button variant={filters.subcategory === 'all' ? 'default' : 'secondary'} className="rounded-full shrink-0 snap-start shadow-sm font-medium text-sm h-9" onClick={() => handleFilterChange('subcategory', 'all')}>
                        הכל
                      </Button>
                      {availableSubcategories.map(sub => (
                        <Button key={`subcategory-filter-${sub}`} variant={filters.subcategory === sub ? 'default' : 'secondary'} className={cn("rounded-full shrink-0 snap-start shadow-sm font-medium transition-all text-sm h-9", filters.subcategory !== sub && "hover:bg-primary/10 hover:text-primary bg-background border border-border")} onClick={() => handleFilterChange('subcategory', sub)}>
                          {sub}
                        </Button>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {error ? (
                <Card className="p-8 md:p-16 text-center rounded-3xl border-dashed border-2 border-destructive/30 bg-destructive/5 shadow-none animate-fade-in">
                  <div className="w-16 h-16 md:w-20 md:h-20 bg-destructive/10 rounded-full flex items-center justify-center mx-auto mb-6">
                    <AlertCircle className="h-8 w-8 md:h-10 md:w-10 text-destructive" />
                  </div>
                  <h3 className="text-xl md:text-2xl font-bold mb-3 text-foreground">שגיאה בטעינת התוצאות</h3>
                  <p className="text-sm md:text-base text-muted-foreground mb-8 max-w-md mx-auto">
                    {error}
                  </p>
                  <Button onClick={fetchBusinesses} className="rounded-xl px-8" size="lg">
                    <RefreshCcw className="mr-2 h-4 w-4" /> נסה שוב
                  </Button>
                </Card>
              ) : loading ? (
                <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                  <SkeletonLoader count={6} type="card" />
                </div>
              ) : businesses.length === 0 ? (
                <Card className="p-8 md:p-16 text-center rounded-3xl border-dashed border-2 bg-card shadow-none animate-fade-in">
                  <div className="w-16 h-16 md:w-20 md:h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-6">
                    <Store className="h-8 w-8 md:h-10 md:w-10 text-muted-foreground/60" />
                  </div>
                  <h3 className="text-xl md:text-2xl font-bold mb-3 text-foreground">לא נמצאו תוצאות</h3>
                  <p className="text-sm md:text-base text-muted-foreground mb-8 max-w-md mx-auto">
                    לא מצאנו עסקים התואמים לחיפוש שלך. נסה להסיר חלק מהסינונים או לשנות את מילות החיפוש.
                  </p>
                  <Button onClick={clearFilters} className="rounded-xl px-8" size="lg">נקה סינונים והצג הכל</Button>
                </Card>
              ) : (
                <>
                  <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                    {businesses.map((business, idx) => (
                      <motion.div key={business.id} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: idx * 0.05 }} className="h-full">
                        <BusinessCard business={business} />
                      </motion.div>
                    ))}
                  </div>

                  {totalPages > 1 && (
                    <div className="flex justify-center items-center gap-2 mt-10 md:mt-12 mb-4">
                      <Button variant="outline" className="rounded-xl px-3 md:px-4 text-sm md:text-base" disabled={currentPage === 1} onClick={() => setCurrentPage(prev => prev - 1)}>הקודם</Button>
                      <div className="flex items-center gap-1">
                        {[...Array(totalPages)].map((_, i) => (
                          <Button key={i} variant={currentPage === i + 1 ? 'default' : 'ghost'} className={cn("rounded-xl w-8 h-8 md:w-10 md:h-10 p-0 font-medium text-sm md:text-base", currentPage !== i + 1 && "hover:bg-secondary/50")} onClick={() => setCurrentPage(i + 1)}>{i + 1}</Button>
                        ))}
                      </div>
                      <Button variant="outline" className="rounded-xl px-3 md:px-4 text-sm md:text-base" disabled={currentPage === totalPages} onClick={() => setCurrentPage(prev => prev + 1)}>הבא</Button>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        </div>

        <Footer />
      </div>
    </>
  );
};

export default SearchResultsPage;