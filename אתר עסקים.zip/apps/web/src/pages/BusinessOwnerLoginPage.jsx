import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Store, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { useBusinessOwnerAuth } from '@/contexts/BusinessOwnerAuthContext.jsx';
import { toast } from 'sonner';

const BusinessOwnerLoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useBusinessOwnerAuth();
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(email, password);
      toast.success('התחברת בהצלחה לניהול העסקים');
      navigate('/owner/dashboard');
    } catch (error) {
      toast.error('התחברות נכשלה. אנא בדוק את הפרטים ונסה שוב.');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>התחברות בעלי עסקים - עסקים בקליק</title>
      </Helmet>
      <div className="min-h-screen bg-muted flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-md mb-8">
          <Link to="/" className="flex items-center justify-center gap-2 text-primary hover:text-primary/80 transition-colors">
            <ArrowRight className="h-5 w-5" />
            <span className="font-medium">חזרה לאתר</span>
          </Link>
        </div>

        <Card className="sm:mx-auto sm:w-full sm:max-w-md shadow-xl border-0">
          <CardHeader className="space-y-2 text-center pt-8">
            <div className="mx-auto w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mb-4">
              <Store className="h-8 w-8 text-primary" />
            </div>
            <CardTitle className="text-2xl font-bold text-foreground">כניסת בעלי עסקים</CardTitle>
            <CardDescription className="text-base">התחבר כדי לנהל את העסק שלך</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-5">
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">דוא"ל</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-3 bg-background border border-input rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent transition-all outline-none text-foreground"
                  placeholder="name@example.com"
                  dir="ltr"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">סיסמה</label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-3 bg-background border border-input rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent transition-all outline-none text-foreground"
                  placeholder="••••••••"
                  dir="ltr"
                />
              </div>
              <Button type="submit" className="w-full h-12 text-base rounded-xl mt-6" disabled={loading}>
                {loading ? 'מתחבר...' : 'התחבר לפורטל'}
              </Button>
            </form>
          </CardContent>
          <CardFooter className="justify-center border-t py-6 bg-muted/20">
            <p className="text-sm text-muted-foreground">
              אין לך חשבון בעל עסק?{' '}
              <Link to="/owner/signup" className="text-primary font-semibold hover:underline">
                הירשם כאן
              </Link>
            </p>
          </CardFooter>
        </Card>
      </div>
    </>
  );
};

export default BusinessOwnerLoginPage;