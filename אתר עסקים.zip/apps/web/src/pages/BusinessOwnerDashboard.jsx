import React, { useState, useEffect, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Eye, Plus, Edit, Store, Trash2, MessageSquare, LogOut } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import { useBusinessOwnerAuth } from '@/contexts/BusinessOwnerAuthContext.jsx';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';

const BusinessOwnerDashboard = () => {
  const { currentOwner, logout } = useBusinessOwnerAuth();
  const navigate = useNavigate();
  const [businesses, setBusinesses] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchBusinesses = useCallback(async () => {
    if (!currentOwner?.id) return;
    setLoading(true);
    try {
      const records = await pb.collection('businesses').getList(1, 50, {
        filter: `owner_id="${currentOwner.id}"`,
        sort: '-created',
        $autoCancel: false
      });
      setBusinesses(records.items);
    } catch (error) {
      console.error('Error fetching businesses:', error);
      toast.error('שגיאה בטעינת העסקים');
    } finally {
      setLoading(false);
    }
  }, [currentOwner]);

  useEffect(() => {
    fetchBusinesses();
  }, [fetchBusinesses]);

  const handleDelete = async (id) => {
    if (!window.confirm('האם אתה בטוח שברצונך למחוק עסק זה? פעולה זו אינה הפיכה.')) {
      return;
    }
    try {
      await pb.collection('businesses').delete(id, { $autoCancel: false });
      toast.success('העסק נמחק בהצלחה');
      setBusinesses(businesses.filter(b => b.id !== id));
    } catch (error) {
      console.error('Error deleting business:', error);
      toast.error('שגיאה במחיקת העסק');
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <>
      <Helmet>
        <title>פאנל ניהול עסקים</title>
      </Helmet>

      <div className="min-h-screen bg-muted/30">
        <header className="bg-card border-b border-border sticky top-0 z-30 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center">
                <Store className="h-5 w-5 text-primary" />
              </div>
              <h1 className="text-xl font-bold text-foreground">פורטל עסקים</h1>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-sm font-medium hidden md:inline-block">מחובר כ: {currentOwner?.email}</span>
              <Button variant="ghost" size="sm" onClick={handleLogout} className="text-muted-foreground hover:text-destructive">
                <LogOut className="h-4 w-4 ml-2" />
                התנתק
              </Button>
            </div>
          </div>
        </header>

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
            <div>
              <h2 className="text-3xl font-extrabold text-foreground mb-1">העסקים שלי</h2>
              <p className="text-muted-foreground">נהל את כרטיסי העסק שלך, צפה בביקורות ועדכן פרטים</p>
            </div>
            <Link to="/owner/add-business">
              <Button size="lg" className="rounded-xl shadow-md">
                <Plus className="ml-2 h-5 w-5" />
                הוסף עסק חדש
              </Button>
            </Link>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(3)].map((_, i) => (
                <Card key={i} className="rounded-2xl overflow-hidden border-0 shadow-md">
                  <div className="h-48 bg-muted animate-pulse"></div>
                  <CardContent className="p-6">
                    <div className="h-6 bg-muted rounded w-1/2 mb-4 animate-pulse"></div>
                    <div className="h-10 bg-muted rounded animate-pulse"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : businesses.length === 0 ? (
            <Card className="rounded-3xl border-dashed border-2 bg-card/50 p-16 text-center shadow-none">
              <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-6">
                <Store className="h-10 w-10 text-muted-foreground/50" />
              </div>
              <h3 className="text-2xl font-bold mb-3 text-foreground">עדיין אין לך עסקים</h3>
              <p className="text-muted-foreground mb-8 max-w-md mx-auto">
                הוסף את העסק הראשון שלך כדי להתחיל לקבל לקוחות וביקורות.
              </p>
              <Link to="/owner/add-business">
                <Button size="lg" className="rounded-xl px-8">הקם עסק ראשון</Button>
              </Link>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {businesses.map((business) => (
                <Card key={business.id} className="overflow-hidden rounded-2xl border border-border shadow-sm hover:shadow-lg transition-all flex flex-col group">
                  <div className="relative h-48 overflow-hidden bg-muted">
                    {business.images && business.images.length > 0 ? (
                      <img
                        src={pb.files.getUrl(business, business.images[0], { thumb: '400x300' })}
                        alt={business.name}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Store className="h-12 w-12 text-muted-foreground/30" />
                      </div>
                    )}
                    <div className="absolute top-3 right-3">
                      <span className={`px-2.5 py-1 rounded-lg text-xs font-bold shadow-sm ${
                        business.is_approved && business.status === 'approved' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {business.is_approved && business.status === 'approved' ? 'מאושר' : 'בהמתנה'}
                      </span>
                    </div>
                  </div>
                  
                  <CardContent className="p-5 flex-1 flex flex-col">
                    <div className="mb-4">
                      <span className="text-xs font-semibold text-primary bg-primary/10 px-2 py-1 rounded-md mb-2 inline-block">
                        {business.primary_category}
                      </span>
                      <h3 className="text-xl font-bold text-foreground line-clamp-1">{business.name}</h3>
                      <p className="text-sm text-muted-foreground truncate mt-1">{business.city} {business.address && `• ${business.address}`}</p>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3 mt-auto pt-4 border-t border-border">
                      <Link to={`/owner/edit/${business.id}`}>
                        <Button variant="outline" size="sm" className="w-full rounded-lg bg-card">
                          <Edit className="ml-2 h-4 w-4" />
                          ערוך פרטים
                        </Button>
                      </Link>
                      <Link to={`/owner/reviews/${business.id}`}>
                        <Button variant="outline" size="sm" className="w-full rounded-lg bg-card">
                          <MessageSquare className="ml-2 h-4 w-4" />
                          ביקורות
                        </Button>
                      </Link>
                      {business.is_approved && business.status === 'approved' && (
                        <Link to={`/business/${business.id}`} className="col-span-2">
                          <Button variant="secondary" size="sm" className="w-full rounded-lg">
                            <Eye className="ml-2 h-4 w-4" />
                            צפה בעמוד הציבורי
                          </Button>
                        </Link>
                      )}
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="col-span-2 text-destructive hover:text-destructive hover:bg-destructive/10 rounded-lg"
                        onClick={() => handleDelete(business.id)}
                      >
                        <Trash2 className="ml-2 h-4 w-4" />
                        מחק עסק
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </main>
      </div>
    </>
  );
};

export default BusinessOwnerDashboard;