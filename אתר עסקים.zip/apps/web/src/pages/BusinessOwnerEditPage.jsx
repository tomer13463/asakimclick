import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { ArrowRight, Upload, X, Save, Store, Clock, Image as ImageIcon, MapPinned, Info, Loader2, AlertCircle } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { toast } from 'sonner';

import OpeningHoursTable, { defaultHours } from '@/components/OpeningHoursTable.jsx';
import AddressAutocomplete from '@/components/AddressAutocomplete.jsx';
import MapLocationPicker from '@/components/MapLocationPicker.jsx';

const CATEGORY_MAPPING = {
  'שירותי תחזוקה ובית': [
    'מוסכניק', 'חשמלאי', 'אינסטלטור', 'נגר', 'צבע', 'בנאי', 'גינון', 'ניקוי', 
    'כביסה וגיהוץ', 'תיקון מכשירים', 'תיקון רהיטים', 'הסעות', 'משלוחים', 
    'ניקוי שטיחים', 'ניקוי מזגנים', 'תיקון דלתות וחלונות', 'בדיקת בתים', 'ניקוי בריכות'
  ],
  'מקצועות': [
    'טיפול בעלים', 'הדרכה', 'תרגום', 'עיצוב גרפי', 'בניית אתרים', 'שירותי חשבונות', 
    'ייעוץ עסקי', 'ביטוח', 'משכנתא', 'עורך דין', 'רופא שיניים', 'רופא', 
    'פיזיותרפיה', 'קוסמטיקה', 'ספר', "מסאז'", 'כושר גופני', 'יוגה'
  ],
  'חנויות': [
    'ביגוד', 'נעליים', 'תכשיטים', 'ספרים', 'צעצועים', 'חיות מחמד', 'אלקטרוניקה', 
    'ריהוט', 'כלים', 'ספורט', 'גיטרות', 'מצלמות', 'משקפיים', 'שעונים', 'בשמים', 
    'תרופות', 'מזון בריא', 'קפה', 'תה', 'יין', 'בירה', 'סיגרים', 'טבק', 'מתנות', 
    'פרחים', 'צמחים'
  ],
  'מסעדות וקפה': [
    'מטבח', 'צילום', 'וידאו', 'מוזיקה', 'אירוח', 'מלון', 'מסעדה', 'בר', 'קפה', 'בר קוקטיילים'
  ]
};

const PRIMARY_CATEGORIES = Object.keys(CATEGORY_MAPPING);

const VALID_CITIES = [
  'תל אביב', 'ירושלים', 'חיפה', 'באר שבע', 'ראשון לציון', 'פתח תקווה', 
  'אשדוד', 'נתניה', 'רמת גן', 'גבעתיים', 'כפר סבא', 'הרצליה', 'רעננה', 
  'מודיעין', 'לוד', 'רמלה', 'אשקלון', 'קריית שמונה', 'צפת', 'טבריה', 'תל אביב יפו', 'ראש העין'
];

const normalizeCity = (city) => {
  if (!city) return '';
  return city
    .replace(/[־–−-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
};

const parseAddressString = (addressStr) => {
  let street = '';
  let building = '';
  let city = '';
  
  if (!addressStr) return { street, building, city };

  // (1) Street name: everything before the first number
  // (2) House number: first sequence of digits (and optional attached letters/symbols)
  // (3) City: everything after the house number
  const match = addressStr.match(/^([^\d]+?)\s+(\d+[א-תA-Za-z\/\-]*)(?:[\s,]+(.*))?$/);
  
  if (match) {
    street = match[1].trim();
    building = match[2].trim();
    if (match[3]) {
      // Extract the city, removing leading delimiters
      let afterNumber = match[3].replace(/^[, \-]+/, '').trim();
      const parts = afterNumber.split(',');
      city = normalizeCity(parts[0]);
    }
  } else {
    // Fallback for addresses without numbers (e.g. just a city name)
    const parts = addressStr.split(',');
    street = parts[0].trim();
    if (parts.length > 1) {
      city = normalizeCity(parts[parts.length - 1]);
    }
  }
  
  return { street, building, city };
};

const BusinessOwnerEditPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [business, setBusiness] = useState(null);
  const [cityError, setCityError] = useState('');

  const [formData, setFormData] = useState({
    name: '',
    primary_category: '',
    subcategory: '',
    phone: '',
    whatsapp: '',
    website: '',
    description: '',
    services: '',
    address: '',
    city: '',
    street: '',
    building_number: '',
    opening_hours: defaultHours,
    latitude: '',
    longitude: ''
  });

  const [existingImages, setExistingImages] = useState([]);
  const [newImages, setNewImages] = useState([]);
  const [imagePreviews, setImagePreviews] = useState([]);

  const fetchInitialData = useCallback(async () => {
    try {
      const record = await pb.collection('businesses').getOne(id, { $autoCancel: false });
      setBusiness(record);
      
      let parsedHours = defaultHours;
      try {
        if (record.opening_hours && record.opening_hours.startsWith('[')) {
          parsedHours = JSON.parse(record.opening_hours);
        }
      } catch (e) {
        console.error('Failed to parse opening hours', e);
      }

      const parsed = parseAddressString(record.address);

      setFormData({
        name: record.name || '',
        primary_category: record.primary_category || '',
        subcategory: record.subcategory || '',
        phone: record.phone || '',
        whatsapp: record.whatsapp || '',
        website: record.website || '',
        description: record.description || '',
        services: record.services || '',
        address: record.address || '',
        city: normalizeCity(record.city) || parsed.city,
        street: parsed.street,
        building_number: parsed.building,
        opening_hours: parsedHours,
        latitude: record.latitude || '',
        longitude: record.longitude || ''
      });
      setExistingImages(record.images || []);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error('שגיאה בטעינת נתוני העסק');
      navigate('/owner/dashboard');
    } finally {
      setLoading(false);
    }
  }, [id, navigate]);

  useEffect(() => {
    fetchInitialData();
  }, [fetchInitialData]);

  const availableSubcategories = useMemo(() => {
    if (!formData.primary_category) return [];
    return CATEGORY_MAPPING[formData.primary_category] || [];
  }, [formData.primary_category]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => {
      let finalValue = value;
      if (name === 'city') {
        finalValue = normalizeCity(value);
        if (cityError) setCityError('');
      }
      const updated = { ...prev, [name]: finalValue };
      if (name === 'primary_category') {
        updated.subcategory = '';
      }
      return updated;
    });
  };

  const handleAddressSelect = (addressData) => {
    const parsed = parseAddressString(addressData.address);
    const newCity = normalizeCity(addressData.city) || parsed.city || normalizeCity(formData.city);
    
    setFormData(prev => ({
      ...prev,
      address: addressData.address,
      city: newCity,
      street: addressData.street || parsed.street || prev.street,
      building_number: addressData.buildingNumber || parsed.building || prev.building_number,
      latitude: addressData.latitude || prev.latitude,
      longitude: addressData.longitude || prev.longitude
    }));
    
    if (cityError) setCityError('');
  };

  const handleMapLocationSelect = (locationData) => {
    setFormData(prev => {
      let parsed = {};
      if (locationData.address) {
        parsed = parseAddressString(locationData.address);
      }
      const newCity = normalizeCity(locationData.city) || parsed.city || normalizeCity(prev.city);
      
      return {
        ...prev,
        latitude: locationData.latitude,
        longitude: locationData.longitude,
        ...(locationData.address && { 
          address: locationData.address,
          city: newCity,
          street: locationData.street || parsed.street || prev.street,
          building_number: locationData.buildingNumber || parsed.building || prev.building_number
        })
      };
    });
    
    if (cityError) setCityError('');
  };

  const handleImageChange = (e) => {
    const files = Array.from(e.target.files);
    setNewImages(prev => [...prev, ...files]);
    const previews = files.map(file => URL.createObjectURL(file));
    setImagePreviews(prev => [...prev, ...previews]);
  };

  const removeNewImage = (index) => {
    setNewImages(prev => prev.filter((_, i) => i !== index));
    setImagePreviews(prev => {
      const newPreviews = [...prev];
      URL.revokeObjectURL(newPreviews[index]);
      newPreviews.splice(index, 1);
      return newPreviews;
    });
  };

  const removeExistingImage = (imgString) => {
    setExistingImages(prev => prev.filter(img => img !== imgString));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setCityError('');

    if (!formData.name || !formData.primary_category) {
      toast.error('נא למלא את שדות החובה: שם וקטגוריה');
      return;
    }
    
    if (formData.city && !VALID_CITIES.includes(formData.city)) {
      setCityError(`העיר "${formData.city}" לא קיימת. בחר עיר מהרשימה`);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    if (!formData.latitude || !formData.longitude) {
      toast.error('נא לבחור מיקום מדויק במפה');
      return;
    }

    setSaving(true);
    try {
      const submitData = new FormData();
      
      submitData.append('name', formData.name);
      submitData.append('primary_category', formData.primary_category);
      
      if (formData.subcategory) {
        submitData.append('subcategory', formData.subcategory);
      } else {
        submitData.append('subcategory', '');
      }
      
      submitData.append('phone', formData.phone);
      submitData.append('whatsapp', formData.whatsapp);
      submitData.append('website', formData.website);
      submitData.append('description', formData.description);
      submitData.append('services', formData.services);
      
      const streetPart = [formData.street, formData.building_number].filter(Boolean).join(' ');
      const constructedAddress = [streetPart, formData.city].filter(Boolean).join(', ');
      const finalAddress = constructedAddress || formData.address;
      
      submitData.append('address', finalAddress);
      if (formData.city) submitData.append('city', formData.city);
      
      submitData.append('latitude', formData.latitude);
      submitData.append('longitude', formData.longitude);
      submitData.append('opening_hours', JSON.stringify(formData.opening_hours));

      existingImages.forEach(img => {
        submitData.append('images', img);
      });
      newImages.forEach(file => {
        submitData.append('images', file);
      });

      await pb.collection('businesses').update(id, submitData, { $autoCancel: false });
      
      toast.success('פרטי העסק עודכנו בהצלחה');
      navigate('/owner/dashboard');
    } catch (error) {
      console.error('Error updating business:', error);
      toast.error('שגיאה בעדכון העסק');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-muted/30">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>עריכת עסק - {business?.name}</title>
      </Helmet>

      <div className="min-h-screen bg-muted/30 pb-24">
        <header className="bg-card border-b border-border sticky top-0 z-30 shadow-sm backdrop-blur-md bg-card/90">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center gap-4">
            <Link to="/owner/dashboard" className="text-muted-foreground hover:text-primary transition-colors flex items-center gap-2">
              <ArrowRight className="h-6 w-6" />
              <span className="font-medium hidden sm:inline">חזרה לדאשבורד</span>
            </Link>
            <div className="h-6 w-px bg-border mx-2"></div>
            <h1 className="text-xl font-bold text-foreground truncate">עריכת עסק: {business?.name}</h1>
          </div>
        </header>

        <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 pt-10">
          {cityError && (
            <Alert variant="destructive" className="mb-8 border-2">
              <AlertCircle className="h-5 w-5" />
              <AlertDescription className="text-base font-medium mr-2">
                {cityError}
              </AlertDescription>
            </Alert>
          )}

          <form onSubmit={handleSubmit} className="space-y-10">
            
            <section className="bg-card rounded-2xl shadow-sm border border-border/50 p-6 md:p-8">
               <div className="flex items-center gap-3 mb-8 pb-4 border-b border-border/40">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                  <Store className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold">פרטים בסיסיים</h2>
                  <p className="text-sm text-muted-foreground mt-1">עדכן את מידע העסק והתקשורת</p>
                </div>
              </div>
              
              <div className="mb-6">
                <Label htmlFor="name" className="text-sm font-semibold mb-2 block">שם העסק *</Label>
                <Input id="name" name="name" value={formData.name} onChange={handleInputChange} className="h-12 bg-background border-input rounded-xl focus-visible:ring-2 focus-visible:ring-primary/20 text-base" required />
              </div>

              <div className={`grid grid-cols-1 ${availableSubcategories.length > 0 ? 'md:grid-cols-2' : ''} gap-6 mb-6`}>
                <div>
                  <Label className="text-sm font-semibold mb-2 block">קטגוריה ראשית *</Label>
                  <Select key="edit-primary-category" value={formData.primary_category || undefined} onValueChange={(val) => handleSelectChange('primary_category', val)} required>
                    <SelectTrigger className="h-12 bg-background border-input rounded-xl text-right text-base">
                      <SelectValue placeholder="בחר קטגוריה ראשית" />
                    </SelectTrigger>
                    <SelectContent>
                      {PRIMARY_CATEGORIES.map(cat => (
                        <SelectItem key={cat} value={cat} className="cursor-pointer">{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                {availableSubcategories.length > 0 && (
                  <div>
                    <Label className="text-sm font-semibold mb-2 block">תת-קטגוריה</Label>
                    <Select 
                      key="edit-subcategory"
                      value={formData.subcategory || undefined} 
                      onValueChange={(val) => handleSelectChange('subcategory', val)}
                    >
                      <SelectTrigger className="h-12 bg-background border-input rounded-xl text-right text-base">
                        <SelectValue placeholder="בחר תת-קטגוריה" />
                      </SelectTrigger>
                      <SelectContent>
                        {availableSubcategories.map(sub => (
                          <SelectItem key={sub} value={sub} className="cursor-pointer">{sub}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div>
                  <Label htmlFor="phone" className="text-sm font-semibold mb-2 block">טלפון</Label>
                  <Input id="phone" name="phone" value={formData.phone} onChange={handleInputChange} className="h-12 bg-background border-input rounded-xl text-base" dir="ltr" />
                </div>
                <div>
                  <Label htmlFor="whatsapp" className="text-sm font-semibold mb-2 block">וואטסאפ (ללא 0)</Label>
                  <Input id="whatsapp" name="whatsapp" value={formData.whatsapp} onChange={handleInputChange} className="h-12 bg-background border-input rounded-xl text-base" dir="ltr" placeholder="5X..." />
                </div>
                <div>
                  <Label htmlFor="website" className="text-sm font-semibold mb-2 block">אתר אינטרנט</Label>
                  <Input id="website" name="website" value={formData.website} onChange={handleInputChange} className="h-12 bg-background border-input rounded-xl text-base" dir="ltr" />
                </div>
              </div>

              <div>
                <Label htmlFor="description" className="text-sm font-semibold mb-2 block">תיאור העסק</Label>
                <Textarea id="description" name="description" value={formData.description} onChange={handleInputChange} className="bg-background rounded-xl resize-none border-input text-base p-4" rows={5} placeholder="ספר על העסק שלך..." />
              </div>
            </section>

            <section className="bg-card rounded-2xl shadow-sm border border-border/50 p-6 md:p-8">
              <div className="flex items-center gap-3 mb-8 pb-4 border-b border-border/40">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                  <MapPinned className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold">מיקום וכתובת</h2>
                  <p className="text-sm text-muted-foreground mt-1">הזן כתובת או עדכן את המיקום המדויק על גבי המפה</p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                <div className="lg:col-span-5 flex flex-col gap-6">
                  <AddressAutocomplete 
                    initialAddress={formData.address}
                    onAddressSelect={handleAddressSelect}
                    onRawChange={(val) => handleSelectChange('address', val)}
                  />

                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <Label className="text-xs text-muted-foreground mb-1.5 block">רחוב</Label>
                      <Input value={formData.street} onChange={(e) => handleSelectChange('street', e.target.value)} className="bg-background h-10" />
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground mb-1.5 block">מספר בית</Label>
                      <Input value={formData.building_number} onChange={(e) => handleSelectChange('building_number', e.target.value)} className="bg-background h-10" />
                    </div>
                    <div>
                      <Label className={`text-xs mb-1.5 block ${cityError ? 'text-destructive font-bold' : 'text-muted-foreground'}`}>עיר</Label>
                      <Input 
                        value={formData.city} 
                        onChange={(e) => handleSelectChange('city', e.target.value)} 
                        className={`bg-background h-10 ${cityError ? 'border-destructive ring-1 ring-destructive/20' : ''}`} 
                      />
                    </div>
                  </div>

                  {formData.latitude && formData.longitude && (
                    <div className="bg-secondary/40 p-4 rounded-xl border border-secondary mt-auto">
                      <div className="flex items-center gap-2 mb-2 text-secondary-foreground">
                        <Info className="h-4 w-4" />
                        <span className="text-sm font-semibold">מיקום מפה נוכחי</span>
                      </div>
                      <div className="flex gap-4 text-xs font-medium font-mono text-muted-foreground" dir="ltr">
                        <span>Lat: {parseFloat(formData.latitude).toFixed(5)}</span>
                        <span>Lng: {parseFloat(formData.longitude).toFixed(5)}</span>
                      </div>
                    </div>
                  )}
                </div>

                <div className="lg:col-span-7 h-[450px] lg:h-auto min-h-[450px]">
                  <MapLocationPicker 
                    latitude={formData.latitude}
                    longitude={formData.longitude}
                    onLocationSelect={handleMapLocationSelect}
                  />
                </div>
              </div>
            </section>

            <section className="bg-card rounded-2xl shadow-sm border border-border/50 p-6 md:p-8">
               <div className="flex items-center gap-3 mb-8 pb-4 border-b border-border/40">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                  <Clock className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold">שעות פעילות</h2>
                  <p className="text-sm text-muted-foreground mt-1">הגדר את שעות פתיחת העסק במהלך השבוע</p>
                </div>
              </div>
              <OpeningHoursTable 
                hours={formData.opening_hours}
                onChange={(newHours) => handleSelectChange('opening_hours', newHours)}
              />
            </section>

            <section className="bg-card rounded-2xl shadow-sm border border-border/50 p-6 md:p-8">
              <div className="flex items-center gap-3 mb-8 pb-4 border-b border-border/40">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                  <ImageIcon className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold">תמונות ומדיה</h2>
                  <p className="text-sm text-muted-foreground mt-1">ניהול גלריית התמונות של העסק</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
                {existingImages.map((imgStr, index) => (
                  <div key={`existing-image-${index}`} className="relative aspect-square rounded-xl overflow-hidden group bg-muted border border-border shadow-sm">
                    <img src={pb.files.getUrl(business, imgStr, { thumb: '300x300' })} alt="Existing" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-all flex items-center justify-center backdrop-blur-[1px]">
                      <Button type="button" variant="destructive" size="icon" onClick={() => removeExistingImage(imgStr)} className="h-10 w-10 rounded-full hover:scale-110 transition-transform">
                        <X className="h-5 w-5" />
                      </Button>
                    </div>
                  </div>
                ))}

                {imagePreviews.map((src, idx) => (
                  <div key={`new-image-${idx}`} className="relative aspect-square rounded-xl overflow-hidden group bg-muted border border-border shadow-sm">
                    <img src={src} alt="Preview" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-all flex items-center justify-center backdrop-blur-[1px]">
                      <Button type="button" variant="destructive" size="icon" onClick={() => removeNewImage(idx)} className="h-10 w-10 rounded-full hover:scale-110 transition-transform">
                        <X className="h-5 w-5" />
                      </Button>
                    </div>
                    <div className="absolute top-2 right-2 bg-primary text-primary-foreground text-[10px] px-2 py-0.5 rounded-full font-bold shadow-sm">חדש</div>
                  </div>
                ))}

                {(existingImages.length + newImages.length) < 10 && (
                  <label className="flex flex-col items-center justify-center aspect-square border-2 border-dashed border-border rounded-xl cursor-pointer hover:bg-muted transition-colors bg-background group">
                    <Upload className="h-8 w-8 text-muted-foreground mb-2 group-hover:text-primary transition-colors" />
                    <span className="text-sm font-medium text-muted-foreground group-hover:text-foreground transition-colors">הוסף תמונות</span>
                    <input type="file" multiple accept="image/*" className="hidden" onChange={handleImageChange} />
                  </label>
                )}
              </div>
            </section>

            <div className="flex flex-col-reverse sm:flex-row justify-end gap-4 pt-6 pb-10">
              <Button type="button" variant="outline" size="lg" onClick={() => navigate('/owner/dashboard')} className="rounded-xl px-8 h-14 w-full sm:w-auto font-semibold">
                ביטול שינויים
              </Button>
              <Button type="submit" size="lg" disabled={saving} className="rounded-xl px-12 h-14 w-full sm:w-auto text-base font-bold shadow-lg">
                {saving ? <><Loader2 className="mr-2 h-5 w-5 animate-spin" /> שומר שינויים...</> : <><Save className="ml-2 h-5 w-5" /> שמור שינויים בעסק</>}
              </Button>
            </div>
          </form>
        </main>
      </div>
    </>
  );
};

export default BusinessOwnerEditPage;