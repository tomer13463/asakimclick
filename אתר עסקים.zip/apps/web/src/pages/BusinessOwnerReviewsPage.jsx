import React, { useState, useEffect, useCallback } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { ArrowRight, Star, CheckCircle, XCircle, Trash2, Image as ImageIcon } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';

const BusinessOwnerReviewsPage = () => {
  const { businessId } = useParams();
  const navigate = useNavigate();
  const [reviews, setReviews] = useState([]);
  const [business, setBusiness] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const biz = await pb.collection('businesses').getOne(businessId, { $autoCancel: false });
      setBusiness(biz);

      const revs = await pb.collection('reviews').getFullList({
        filter: `business_id="${businessId}"`,
        sort: '-created',
        $autoCancel: false
      });
      setReviews(revs);
    } catch (error) {
      console.error('Error fetching reviews:', error);
      toast.error('שגיאה בטעינת ביקורות');
      navigate('/owner/dashboard');
    } finally {
      setLoading(false);
    }
  }, [businessId, navigate]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const updateStatus = async (id, newStatus) => {
    try {
      await pb.collection('reviews').update(id, { status: newStatus }, { $autoCancel: false });
      toast.success(`סטטוס הביקורת עודכן ל-${newStatus === 'approved' ? 'מאושר' : 'נדחה'}`);
      setReviews(reviews.map(r => r.id === id ? { ...r, status: newStatus } : r));
    } catch (error) {
      console.error('Error updating status:', error);
      toast.error('שגיאה בעדכון הסטטוס');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('האם אתה בטוח שברצונך למחוק ביקורת זו לצמיתות?')) return;
    
    try {
      await pb.collection('reviews').delete(id, { $autoCancel: false });
      toast.success('הביקורת נמחקה בהצלחה');
      setReviews(reviews.filter(r => r.id !== id));
    } catch (error) {
      console.error('Error deleting review:', error);
      toast.error('שגיאה במחיקת הביקורת');
    }
  };

  const getStatusBadge = (status) => {
    switch(status) {
      case 'approved': return <span className="bg-green-100 text-green-800 px-2.5 py-1 rounded-full text-xs font-bold">מאושר</span>;
      case 'rejected': return <span className="bg-red-100 text-red-800 px-2.5 py-1 rounded-full text-xs font-bold">נדחה</span>;
      default: return <span className="bg-yellow-100 text-yellow-800 px-2.5 py-1 rounded-full text-xs font-bold">ממתין לאישור</span>;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-muted/30">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>ניהול ביקורות - {business?.name}</title>
      </Helmet>

      <div className="min-h-screen bg-muted/30 pb-20">
        <header className="bg-card border-b border-border sticky top-0 z-30 shadow-sm">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center gap-4">
            <Link to="/owner/dashboard" className="text-muted-foreground hover:text-primary transition-colors">
              <ArrowRight className="h-6 w-6" />
            </Link>
            <h1 className="text-xl font-bold text-foreground">ביקורות: {business?.name}</h1>
          </div>
        </header>

        <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-10">
          <div className="mb-8">
            <h2 className="text-3xl font-extrabold text-foreground mb-2">ניהול ביקורות הלקוחות</h2>
            <p className="text-muted-foreground">אשר או דחה ביקורות לפני פרסומן בעמוד העסק שלך.</p>
          </div>

          {reviews.length === 0 ? (
            <Card className="rounded-3xl border-dashed border-2 bg-card/50 p-16 text-center shadow-none">
              <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-6">
                <Star className="h-10 w-10 text-muted-foreground/50" />
              </div>
              <h3 className="text-2xl font-bold mb-3 text-foreground">אין ביקורות עדיין</h3>
              <p className="text-muted-foreground">כאשר לקוחות ישאירו ביקורות על העסק שלך, הן יופיעו כאן.</p>
            </Card>
          ) : (
            <div className="space-y-6">
              {reviews.map((review) => (
                <Card key={review.id} className={`rounded-2xl border-l-4 shadow-sm ${
                  review.status === 'approved' ? 'border-l-green-500' :
                  review.status === 'rejected' ? 'border-l-red-500' :
                  'border-l-yellow-500'
                }`}>
                  <CardContent className="p-6">
                    <div className="flex flex-col md:flex-row gap-6">
                      <div className="flex-1">
                        <div className="flex justify-between items-start mb-3">
                          <div>
                            <div className="flex items-center gap-3 mb-1">
                              <h3 className="font-bold text-lg">{review.user_name}</h3>
                              {getStatusBadge(review.status)}
                            </div>
                            <div className="flex items-center">
                              {[...Array(5)].map((_, i) => (
                                <Star
                                  key={i}
                                  className={`h-4 w-4 ${i < review.rating ? 'fill-yellow-400 text-yellow-400' : 'text-muted'}`}
                                />
                              ))}
                              <span className="ml-2 text-sm text-muted-foreground">
                                {new Date(review.created).toLocaleDateString('he-IL')}
                              </span>
                            </div>
                          </div>
                        </div>
                        
                        <p className="text-foreground leading-relaxed bg-muted/30 p-4 rounded-xl mt-3">
                          {review.comment}
                        </p>
                      </div>

                      {review.image && (
                        <div className="shrink-0 md:w-48 aspect-video md:aspect-square rounded-xl overflow-hidden bg-muted border border-border">
                          <img 
                            src={pb.files.getUrl(review, review.image, { thumb: '300x300' })} 
                            alt="Review attachment" 
                            className="w-full h-full object-cover cursor-pointer hover:scale-105 transition-transform"
                            onClick={() => window.open(pb.files.getUrl(review, review.image), '_blank')}
                          />
                        </div>
                      )}
                    </div>

                    <div className="flex flex-wrap gap-3 mt-6 pt-6 border-t border-border">
                      {review.status !== 'approved' && (
                        <Button 
                          variant="outline" 
                          className="bg-green-50 text-green-700 hover:bg-green-100 hover:text-green-800 border-green-200"
                          onClick={() => updateStatus(review.id, 'approved')}
                        >
                          <CheckCircle className="ml-2 h-4 w-4" />
                          אשר פרסום
                        </Button>
                      )}
                      
                      {review.status !== 'rejected' && (
                        <Button 
                          variant="outline" 
                          className="bg-yellow-50 text-yellow-700 hover:bg-yellow-100 hover:text-yellow-800 border-yellow-200"
                          onClick={() => updateStatus(review.id, 'rejected')}
                        >
                          <XCircle className="ml-2 h-4 w-4" />
                          דחה פרסום
                        </Button>
                      )}

                      <div className="flex-1"></div>

                      <Button 
                        variant="ghost" 
                        className="text-destructive hover:bg-destructive/10"
                        onClick={() => handleDelete(review.id)}
                      >
                        <Trash2 className="ml-2 h-4 w-4" />
                        מחק לצמיתות
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </main>
      </div>
    </>
  );
};

export default BusinessOwnerReviewsPage;