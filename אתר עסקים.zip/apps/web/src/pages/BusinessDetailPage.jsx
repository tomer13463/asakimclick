import React, { useState, useEffect, useCallback } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Star, MapPin, Phone, MessageCircle, Globe, Clock, Navigation, Store, Compass } from 'lucide-react';
import { MapContainer, TileLayer, Marker } from 'react-leaflet';
import L from 'leaflet';
import { motion } from 'framer-motion';
import pb from '@/lib/pocketbaseClient';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem } from '@/components/ui/dropdown-menu';
import { useAuth } from '@/contexts/AuthContext.jsx';
import ReviewModal from '@/components/ReviewModal.jsx';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import BusinessHoursStatus from '@/components/BusinessHoursStatus.jsx';
import SkeletonLoader from '@/components/SkeletonLoader.jsx';
import { toast } from 'sonner';

const iconUrl = 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png';
const iconRetinaUrl = 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png';
const shadowUrl = 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png';

const customIcon = new L.Icon({
  iconUrl,
  iconRetinaUrl,
  shadowUrl,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const safeParseOpeningHours = (data) => {
  if (Array.isArray(data)) return data;
  if (typeof data !== 'string') return [];
  try {
    const parsed = JSON.parse(data);
    if (Array.isArray(parsed)) return parsed;
    return [];
  } catch (error) {
    return [];
  }
};

const extractAddressWithoutCity = (addressStr, cityName) => {
  if (!addressStr) return '';
  
  // If city is not in the address, return as-is
  if (!cityName || !addressStr.includes(cityName)) {
    return addressStr;
  }
  
  // Remove the city and surrounding delimiters from the end
  let result = addressStr;
  
  // Try to remove ", city" pattern
  result = result.replace(new RegExp(`,\\s*${cityName}\\s*$`), '');
  
  // Try to remove "city" at the end if comma removal didn't work
  if (result === addressStr) {
    result = result.replace(new RegExp(`\\s*${cityName}\\s*$`), '');
  }
  
  return result.trim();
};

const BusinessDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const [business, setBusiness] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);

  const fetchBusinessData = useCallback(async () => {
    setLoading(true);
    try {
      const biz = await pb.collection('businesses').getOne(id, { $autoCancel: false });
      
      if (biz.status !== 'approved' || biz.is_approved !== true) {
        const user = pb.authStore.model;
        const isOwner = user?.collectionName === 'business_owners' && biz.owner_id === user.id;
        const isAdmin = user?.collectionName === 'admin_users';
        
        if (!isOwner && !isAdmin) {
          toast.error('העסק אינו מאושר לצפייה');
          setBusiness(null);
          navigate('/');
          return;
        }
      }

      setBusiness(biz);

      const revs = await pb.collection('reviews').getList(1, 50, {
        filter: `business_id="${id}" && status="approved" && is_approved=true`,
        sort: '-created',
        $autoCancel: false
      });
      setReviews(revs.items);
    } catch (error) {
      console.error('Error fetching business:', error);
      toast.error('העסק לא נמצא');
      navigate('/');
    } finally {
      setLoading(false);
    }
  }, [id, navigate]);

  useEffect(() => {
    fetchBusinessData();
  }, [fetchBusinessData]);

  const handleReviewSuccess = () => {
    fetchBusinessData();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <Header />
        <div className="flex-1 w-full pt-20">
          <SkeletonLoader type="detail" />
        </div>
        <Footer />
      </div>
    );
  }

  if (!business) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <Header />
        <div className="flex-1 flex flex-col items-center justify-center p-4 animate-fade-in">
          <Store className="h-16 w-16 text-muted-foreground mb-4" />
          <h2 className="text-2xl font-bold mb-2">עסק לא קיים או שאינו מאושר</h2>
          <Link to="/search">
            <Button className="transition-transform active:scale-95">חזרה לחיפוש</Button>
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  const images = business.images || [];
  const hasImages = images.length > 0;
  
  const heroImage = hasImages 
    ? (images[0].startsWith('http') ? images[0] : pb.files.getUrl(business, images[0], { thumb: '1200x800' })) 
    : null;

  const openingHours = safeParseOpeningHours(business.opening_hours);
  
  // Extract address without city suffix
  const addressWithoutCity = extractAddressWithoutCity(business.address, business.city);

  return (
    <>
      <Helmet>
        <title>{business.name} - עסקים בקליק</title>
        <meta name="description" content={business.description || `${business.category} ב${business.city}`} />
      </Helmet>

      <div className="min-h-screen bg-background flex flex-col animate-fade-in">
        <Header />

        <section className="relative w-full h-[50vh] min-h-[400px] pt-20">
          <div className="absolute inset-0">
            {heroImage ? (
              <>
                <img src={heroImage} alt={business.name} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent mix-blend-multiply"></div>
              </>
            ) : (
              <>
                <div className="w-full h-full bg-secondary/30 flex flex-col items-center justify-center pt-10">
                  <Store className="h-28 w-28 text-primary/10 mb-4" />
                  <span className="text-3xl md:text-5xl font-extrabold text-primary/10 tracking-tight">
                    {business.subcategory || business.primary_category}
                  </span>
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent"></div>
              </>
            )}
          </div>
          <div className="absolute bottom-0 w-full p-6 md:p-12 max-w-7xl mx-auto inset-x-0 z-10">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
              <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-4">
                <div>
                  <div className="inline-block bg-primary/20 backdrop-blur-md border border-primary/30 text-primary-foreground px-3 py-1 rounded-full text-sm font-bold mb-4 shadow-sm">
                    {business.primary_category}
                  </div>
                  <h1 className="text-4xl md:text-6xl font-extrabold text-foreground mb-4 drop-shadow-md" style={{ textBalance: 'balance' }}>
                    {business.name}
                  </h1>
                </div>
                {business.opening_hours && (
                  <div className="mb-2 bg-background/95 backdrop-blur-md rounded-xl p-2 shadow-lg border border-border">
                    <BusinessHoursStatus openingHoursJSON={business.opening_hours} />
                  </div>
                )}
              </div>
              <div className="flex flex-wrap items-center gap-6 text-foreground drop-shadow-md font-medium">
                <div className="flex items-center gap-1.5">
                  <Star className="h-6 w-6 fill-yellow-400 text-yellow-400" />
                  <span className="text-xl font-bold">{business.rating?.toFixed(1) || '5.0'}</span>
                  <span className="opacity-80">({business.reviews_count || 0} ביקורות)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <MapPin className="h-5 w-5" />
                  <span>{business.city}</span>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            
            <div className="lg:col-span-2 space-y-10">
              
              {images.length > 1 && (
                <section>
                  <h2 className="text-2xl font-bold mb-4">גלריה</h2>
                  <Carousel className="w-full">
                    <CarouselContent className="-ml-4 transition-transform ease-in-out duration-300">
                      {images.map((img, idx) => {
                        const imgSrc = img.startsWith('http') ? img : pb.files.getUrl(business, img, { thumb: '600x450' });
                        return (
                          <CarouselItem key={idx} className="pl-4 basis-4/5 md:basis-1/2 lg:basis-1/3">
                            <div className="aspect-[4/3] rounded-2xl overflow-hidden border border-border shadow-sm">
                              <img 
                                src={imgSrc} 
                                alt={`${business.name} - תמונה ${idx + 1}`}
                                className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                              />
                            </div>
                          </CarouselItem>
                        );
                      })}
                    </CarouselContent>
                    <CarouselPrevious className="right-4" />
                    <CarouselNext className="left-4" />
                  </Carousel>
                </section>
              )}

              <section>
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
                  <Card className="border-0 shadow-lg rounded-3xl overflow-hidden bg-card text-card-foreground">
                    <CardContent className="p-8 space-y-8">
                      {business.description && (
                        <div>
                          <h2 className="text-2xl font-bold mb-4">אודות העסק</h2>
                          <p className="text-muted-foreground leading-relaxed whitespace-pre-line text-lg">
                            {business.description}
                          </p>
                        </div>
                      )}
                      
                      {business.services && (
                        <div>
                          <h3 className="text-xl font-bold mb-3">שירותים מרכזיים</h3>
                          <div className="bg-muted p-6 rounded-2xl">
                            <p className="text-foreground leading-relaxed whitespace-pre-line">
                              {business.services}
                            </p>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              </section>

              <section>
                <div className="flex justify-between items-end mb-6">
                  <div>
                    <h2 className="text-2xl font-bold">ביקורות לקוחות</h2>
                    <p className="text-muted-foreground">מה אומרים על {business.name}</p>
                  </div>
                  {isAuthenticated ? (
                    <Button onClick={() => setIsReviewModalOpen(true)} className="rounded-xl shadow-md transition-transform active:scale-95">
                      <Star className="ml-2 h-4 w-4" />
                      כתוב ביקורת
                    </Button>
                  ) : (
                    <Link to="/login">
                      <Button variant="outline" className="rounded-xl transition-transform active:scale-95">התחבר כדי להגיב</Button>
                    </Link>
                  )}
                </div>

                {reviews.length === 0 ? (
                  <Card className="rounded-3xl border-dashed border-2 bg-transparent p-12 text-center shadow-none">
                    <MessageCircle className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
                    <p className="text-lg font-medium text-foreground">אין עדיין ביקורות</p>
                    <p className="text-muted-foreground">היה הראשון לספר על החוויה שלך!</p>
                  </Card>
                ) : (
                  <div className="space-y-6">
                    {reviews.map((review, idx) => (
                      <motion.div 
                        key={review.id}
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.4, delay: idx * 0.1 }}
                      >
                        <Card className="rounded-2xl border-0 shadow-md bg-card transition-shadow hover:shadow-lg">
                          <CardContent className="p-6 flex flex-col sm:flex-row gap-6">
                            <div className="flex-1">
                              <div className="flex items-center gap-3 mb-2">
                                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary font-bold">
                                  {review.user_name.charAt(0)}
                                </div>
                                <div>
                                  <h4 className="font-bold">{review.user_name}</h4>
                                  <div className="flex items-center">
                                    {[...Array(5)].map((_, i) => (
                                      <Star key={i} className={`h-3 w-3 ${i < review.rating ? 'fill-yellow-400 text-yellow-400' : 'text-muted-foreground/30'}`} />
                                    ))}
                                    <span className="text-xs text-muted-foreground mr-2">
                                      {new Date(review.created).toLocaleDateString('he-IL')}
                                    </span>
                                  </div>
                                </div>
                              </div>
                              <p className="text-foreground mt-3 leading-relaxed">
                                {review.comment}
                              </p>
                            </div>
                            {review.image && (
                              <div className="sm:w-32 aspect-square rounded-xl overflow-hidden shrink-0 border border-border">
                                <img src={pb.files.getUrl(review, review.image, { thumb: '200x200' })} className="w-full h-full object-cover" alt="Review media" />
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                )}
              </section>

            </div>

            <aside className="space-y-8">
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
                <Card className="rounded-3xl border-0 shadow-xl overflow-hidden bg-primary text-primary-foreground">
                  <CardContent className="p-1">
                    <div className="bg-card text-card-foreground m-1 rounded-[22px] p-6 space-y-4">
                      <h3 className="font-bold text-lg border-b border-border pb-3 mb-4">יצירת קשר</h3>
                      
                      {business.phone && (
                        <Button 
                          variant="outline" 
                          size="lg" 
                          className="w-full justify-start text-right font-semibold rounded-xl bg-background border-border hover:bg-secondary h-14 transition-transform active:scale-95"
                          onClick={() => window.location.href = `tel:${business.phone}`}
                        >
                          <Phone className="ml-3 h-5 w-5 text-primary" />
                          {business.phone}
                        </Button>
                      )}
                      
                      {business.whatsapp && (
                        <Button 
                          size="lg" 
                          className="w-full justify-start text-right font-semibold rounded-xl bg-[#25D366] hover:bg-[#20BA5A] text-white border-0 h-14 shadow-md transition-transform active:scale-95"
                          onClick={() => window.open(`https://wa.me/${business.whatsapp.replace(/[^0-9]/g, '')}`, '_blank')}
                        >
                          <MessageCircle className="ml-3 h-5 w-5" />
                          וואטסאפ
                        </Button>
                      )}

                      {business.website && (
                        <Button 
                          variant="ghost" 
                          size="lg" 
                          className="w-full justify-start text-right font-medium rounded-xl hover:bg-muted h-12 transition-transform active:scale-95"
                          onClick={() => window.open(business.website.startsWith('http') ? business.website : `https://${business.website}`, '_blank')}
                        >
                          <Globe className="ml-3 h-5 w-5 text-muted-foreground" />
                          אתר אינטרנט
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
                <Card className="rounded-3xl border-0 shadow-lg overflow-hidden bg-card">
                  <CardContent className="p-0">
                    <div className="p-6 space-y-6">
                      <div>
                        <h3 className="font-bold text-sm text-muted-foreground uppercase tracking-wider mb-3">שעות פתיחה</h3>
                        <div className="flex gap-3 text-foreground font-medium">
                          <Clock className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                          <div className="w-full">
                            {openingHours.length > 0 ? (
                              <div className="space-y-1">
                                {openingHours.map((day, idx) => (
                                  <div key={idx} className={cn(
                                    "flex justify-between text-sm py-1 border-b border-border/50 last:border-0",
                                    new Date().getDay() === idx ? "font-bold text-primary" : ""
                                  )}>
                                    <span>{day.day}</span>
                                    <span>{day.isClosed ? 'סגור' : `${day.open} - ${day.close}`}</span>
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <p className="whitespace-pre-line leading-relaxed">שעות הפתיחה לא עודכנו</p>
                            )}
                          </div>
                        </div>
                      </div>

                      <div>
                        <h3 className="font-bold text-sm text-muted-foreground uppercase tracking-wider mb-3">כתובת</h3>
                        <div className="flex gap-3 text-foreground font-medium">
                          <MapPin className="h-5 w-5 text-primary shrink-0" />
                          <p>
                            {business.city && addressWithoutCity 
                              ? `${business.city} • ${addressWithoutCity}` 
                              : (addressWithoutCity || business.city)}
                          </p>
                        </div>
                      </div>
                    </div>

                    {business.latitude && business.longitude ? (
                      <div className="px-6 pb-6 pt-2 space-y-4">
                        <div className="flex items-center justify-between">
                          <h3 className="font-bold text-lg text-foreground">מפה וניווט</h3>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button className="rounded-xl shadow-md transition-transform active:scale-95 text-primary-foreground bg-primary hover:bg-primary/90">
                                <Compass className="ml-2 h-5 w-5" />
                                נווט לעסק
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="rounded-xl w-56">
                              <DropdownMenuItem 
                                className="cursor-pointer py-3" 
                                onClick={() => window.open(`https://www.google.com/maps/dir/?api=1&destination=${business.latitude},${business.longitude}`, '_blank')}
                              >
                                <div className="flex items-center font-medium">
                                  <MapPin className="mr-2 ml-2 h-4 w-4 text-muted-foreground" />
                                  ניווט עם Google Maps
                                </div>
                              </DropdownMenuItem>
                              <DropdownMenuItem 
                                className="cursor-pointer py-3" 
                                onClick={() => window.open(`https://waze.com/ul?ll=${business.latitude},${business.longitude}&navigate=yes`, '_blank')}
                              >
                                <div className="flex items-center font-medium">
                                  <Navigation className="mr-2 ml-2 h-4 w-4 text-muted-foreground" />
                                  ניווט עם Waze
                                </div>
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                        <div className="h-[400px] md:h-[500px] w-full rounded-2xl border border-border shadow-inner overflow-hidden relative z-0">
                          <MapContainer 
                            center={[business.latitude, business.longitude]} 
                            zoom={14} 
                            scrollWheelZoom={false}
                            className="h-full w-full"
                          >
                            <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                            <Marker position={[business.latitude, business.longitude]} icon={customIcon} />
                          </MapContainer>
                        </div>
                      </div>
                    ) : (
                      <div className="h-32 w-full bg-muted flex flex-col items-center justify-center border-t border-border mt-4">
                        <MapPin className="h-6 w-6 text-muted-foreground/50 mb-2" />
                        <p className="text-xs text-muted-foreground">מיקום על המפה לא זמין</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </motion.div>

            </aside>
          </div>
        </main>
        
        <Footer />
      </div>

      <ReviewModal 
        isOpen={isReviewModalOpen} 
        onClose={() => setIsReviewModalOpen(false)} 
        businessId={id} 
        onSuccess={handleReviewSuccess} 
      />
    </>
  );
};

export default BusinessDetailPage;