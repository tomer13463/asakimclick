import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import pb from '@/lib/pocketbaseClient';
import { BookOpen } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import BlogCard from '@/components/BlogCard.jsx';
import SkeletonLoader from '@/components/SkeletonLoader.jsx';
import { setMetaTags } from '@/lib/seoUtils.js';

const BlogPage = () => {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setMetaTags({
      title: 'בלוג עסקים בקליק - טיפים, חדשות ומדריכים',
      description: 'מאמרים מרתקים, טיפים מקצועיים ומדריכים מעשיים על בחירת עסקים, שירותים וצרכנות נבונה.',
      keywords: 'בלוג, כתבות, טיפים, עסקים מומלצים, מדריכים'
    });

    const fetchPosts = async () => {
      try {
        const result = await pb.collection('blog_posts').getList(1, 50, {
          sort: '-created',
          $autoCancel: false
        });
        setPosts(result.items);
      } catch (err) {
        console.error('Error fetching blog posts:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchPosts();
  }, []);

  return (
    <>
      <Helmet>
        <title>בלוג - עסקים בקליק</title>
      </Helmet>

      <div className="min-h-screen bg-background flex flex-col">
        <Header />

        <main className="flex-1 w-full pt-20">
          <section className="bg-secondary/30 py-16 md:py-24 border-b border-border/50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-6 text-primary">
                  <BookOpen className="w-8 h-8" />
                </div>
                <h1 className="text-4xl md:text-6xl font-extrabold text-foreground mb-4" style={{ textBalance: 'balance' }}>
                  הבלוג של <span className="text-primary">עסקים בקליק</span>
                </h1>
                <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                  חדשות, טיפים, ומדריכים מקצועיים שיעזרו לכם להיות צרכנים חכמים יותר.
                </p>
              </motion.div>
            </div>
          </section>

          <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <SkeletonLoader count={6} type="card" />
              </div>
            ) : posts.length === 0 ? (
              <div className="text-center py-20 bg-card rounded-3xl border border-dashed">
                <h3 className="text-2xl font-bold text-foreground mb-2">טרם פורסמו פוסטים</h3>
                <p className="text-muted-foreground">בקרוב נעלה לכאן תוכן חדש ומעניין.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {posts.map((post, idx) => (
                  <motion.div
                    key={post.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: idx * 0.1 }}
                  >
                    <BlogCard post={post} />
                  </motion.div>
                ))}
              </div>
            )}
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default BlogPage;