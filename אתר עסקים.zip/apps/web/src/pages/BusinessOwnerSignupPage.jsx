import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Store, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { useBusinessOwnerAuth } from '@/contexts/BusinessOwnerAuthContext.jsx';
import { toast } from 'sonner';

const BusinessOwnerSignupPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passwordConfirm, setPasswordConfirm] = useState('');
  const [loading, setLoading] = useState(false);
  const { signup, login } = useBusinessOwnerAuth();
  const navigate = useNavigate();

  const handleSignup = async (e) => {
    e.preventDefault();
    if (password !== passwordConfirm) {
      toast.error('הסיסמאות אינן תואמות');
      return;
    }
    if (password.length < 8) {
      toast.error('הסיסמה חייבת להכיל לפחות 8 תווים');
      return;
    }

    setLoading(true);
    try {
      await signup(email, password, passwordConfirm);
      await login(email, password);
      toast.success('החשבון נוצר בהצלחה!');
      navigate('/owner/dashboard');
    } catch (error) {
      toast.error('שגיאה ביצירת חשבון. ייתכן והאימייל כבר בשימוש.');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>הרשמת בעלי עסקים - עסקים בקליק</title>
      </Helmet>
      <div className="min-h-screen bg-muted flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-md mb-8">
          <Link to="/" className="flex items-center justify-center gap-2 text-primary hover:text-primary/80 transition-colors">
            <ArrowRight className="h-5 w-5" />
            <span className="font-medium">חזרה לאתר</span>
          </Link>
        </div>

        <Card className="sm:mx-auto sm:w-full sm:max-w-md shadow-xl border-0">
          <CardHeader className="space-y-2 text-center pt-8">
            <div className="mx-auto w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mb-4">
              <Store className="h-8 w-8 text-primary" />
            </div>
            <CardTitle className="text-2xl font-bold text-foreground">הרשמת בעל עסק</CardTitle>
            <CardDescription className="text-base">צור חשבון כדי להוסיף ולנהל את העסק שלך</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSignup} className="space-y-5">
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">דוא"ל</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-3 bg-background border border-input rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent transition-all outline-none text-foreground"
                  placeholder="name@example.com"
                  dir="ltr"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">סיסמה (לפחות 8 תווים)</label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-3 bg-background border border-input rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent transition-all outline-none text-foreground"
                  placeholder="••••••••"
                  dir="ltr"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">אימות סיסמה</label>
                <input
                  type="password"
                  required
                  value={passwordConfirm}
                  onChange={(e) => setPasswordConfirm(e.target.value)}
                  className="w-full px-4 py-3 bg-background border border-input rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent transition-all outline-none text-foreground"
                  placeholder="••••••••"
                  dir="ltr"
                />
              </div>
              <Button type="submit" className="w-full h-12 text-base rounded-xl mt-6" disabled={loading}>
                {loading ? 'יוצר חשבון...' : 'צור חשבון חדש'}
              </Button>
            </form>
          </CardContent>
          <CardFooter className="justify-center border-t py-6 bg-muted/20">
            <p className="text-sm text-muted-foreground">
              כבר יש לך חשבון?{' '}
              <Link to="/owner/login" className="text-primary font-semibold hover:underline">
                התחבר כאן
              </Link>
            </p>
          </CardFooter>
        </Card>
      </div>
    </>
  );
};

export default BusinessOwnerSignupPage;