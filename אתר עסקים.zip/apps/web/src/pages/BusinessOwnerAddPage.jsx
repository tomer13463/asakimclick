import React, { useState, useRef, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Upload, X, Store, Clock, Phone, Loader2, Image as ImageIcon, MapPinned, Info } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import { useBusinessOwnerAuth } from '@/contexts/BusinessOwnerAuthContext.jsx';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

import OpeningHoursTable, { defaultHours } from '@/components/OpeningHoursTable.jsx';
import AddressAutocomplete from '@/components/AddressAutocomplete.jsx';
import MapLocationPicker from '@/components/MapLocationPicker.jsx';

const CATEGORY_MAPPING = {
  'שירותי תחזוקה ובית': [
    'מוסכניק', 'חשמלאי', 'אינסטלטור', 'נגר', 'צבע', 'בנאי', 'גינון', 'ניקוי', 
    'כביסה וגיהוץ', 'תיקון מכשירים', 'תיקון רהיטים', 'הסעות', 'משלוחים', 
    'ניקוי שטיחים', 'ניקוי מזגנים', 'תיקון דלתות וחלונות', 'בדיקת בתים', 'ניקוי בריכות'
  ],
  'מקצועות': [
    'טיפול בעלים', 'הדרכה', 'תרגום', 'עיצוב גרפי', 'בניית אתרים', 'שירותי חשבונות', 
    'ייעוץ עסקי', 'ביטוח', 'משכנתא', 'עורך דין', 'רופא שיניים', 'רופא', 
    'פיזיותרפיה', 'קוסמטיקה', 'ספר', "מסאז'", 'כושר גופני', 'יוגה'
  ],
  'חנויות': [
    'ביגוד', 'נעליים', 'תכשיטים', 'ספרים', 'צעצועים', 'חיות מחמד', 'אלקטרוניקה', 
    'ריהוט', 'כלים', 'ספורט', 'גיטרות', 'מצלמות', 'משקפיים', 'שעונים', 'בשמים', 
    'תרופות', 'מזון בריא', 'קפה', 'תה', 'יין', 'בירה', 'סיגרים', 'טבק', 'מתנות', 
    'פרחים', 'צמחים'
  ],
  'מסעדות וקפה': [
    'מטבח', 'צילום', 'וידאו', 'מוזיקה', 'אירוח', 'מלון', 'מסעדה', 'בר', 'קפה', 'בר קוקטיילים'
  ]
};

const PRIMARY_CATEGORIES = Object.keys(CATEGORY_MAPPING);

// EXACT cities from database schema - character-for-character match
const CITIES = [
  'תל אביב',
  'ירושלים',
  'חיפה',
  'באר שבע',
  'ראשון לציון',
  'פתח תקווה',
  'אשדוד',
  'נתניה',
  'רמת גן',
  'גבעתיים',
  'כפר סבא',
  'הרצליה',
  'רעננה',
  'מודיעין',
  'לוד',
  'רמלה',
  'אשקלון',
  'קריית שמונה',
  'צפת',
  'טבריה',
  'תל אביב יפו',
  'ראש העין'
];

const BusinessOwnerAddPage = () => {
  const navigate = useNavigate();
  const { currentOwner } = useBusinessOwnerAuth();
  const currentUser = currentOwner;
  
  const [submitting, setSubmitting] = useState(false);
  
  const [formData, setFormData] = useState({
    name: '',
    primary_category: '',
    subcategory: '',
    phone: '',
    address: '',
    city: '',
    street: '',
    building_number: '',
    opening_hours: defaultHours,
    latitude: '',
    longitude: ''
  });

  const [mainImage, setMainImage] = useState(null);
  const [additionalImages, setAdditionalImages] = useState([]);
  
  const [mainImagePreview, setMainImagePreview] = useState(null);
  const [additionalImagePreviews, setAdditionalImagePreviews] = useState([]);

  const mainImageInputRef = useRef(null);
  const additionalImagesInputRef = useRef(null);

  const availableSubcategories = useMemo(() => {
    if (!formData.primary_category) return [];
    return CATEGORY_MAPPING[formData.primary_category] || [];
  }, [formData.primary_category]);

  const handleChange = (field, value) => {
    setFormData(prev => {
      const updated = { ...prev, [field]: value };
      if (field === 'primary_category') {
        updated.subcategory = ''; // Reset subcategory when primary changes
      }
      return updated;
    });
  };

  const handleAddressSelect = (addressData) => {
    setFormData(prev => ({
      ...prev,
      address: addressData.address,
      city: addressData.city || prev.city,
      street: addressData.street,
      building_number: addressData.buildingNumber,
      latitude: addressData.latitude || prev.latitude,
      longitude: addressData.longitude || prev.longitude
    }));
  };

  const handleMapLocationSelect = (locationData) => {
    setFormData(prev => ({
      ...prev,
      latitude: locationData.latitude,
      longitude: locationData.longitude,
      ...(locationData.address && { 
        address: locationData.address,
        city: locationData.city || prev.city,
        street: locationData.street,
        building_number: locationData.buildingNumber
      })
    }));
  };

  const handleMainImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setMainImage(file);
      // Use FileReader API as requested
      const reader = new FileReader();
      reader.onloadend = () => {
        setMainImagePreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAdditionalImagesChange = (e) => {
    const files = Array.from(e.target.files);
    const totalCurrentImages = 1 + additionalImages.length;
    if (totalCurrentImages + files.length > 10) {
      toast.error('ניתן להעלות עד 10 תמונות בסך הכל');
      return;
    }
    
    setAdditionalImages(prev => [...prev, ...files]);
    
    // Use FileReader API for all additional files
    files.forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAdditionalImagePreviews(prev => [...prev, reader.result]);
      };
      reader.readAsDataURL(file);
    });
  };

  const removeMainImage = () => {
    setMainImage(null);
    setMainImagePreview(null);
    if (mainImageInputRef.current) mainImageInputRef.current.value = '';
  };

  const removeAdditionalImage = (index) => {
    setAdditionalImages(prev => prev.filter((_, i) => i !== index));
    setAdditionalImagePreviews(prev => {
      const newPreviews = [...prev];
      newPreviews.splice(index, 1);
      return newPreviews;
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.name.trim()) return toast.error('נא להזין שם עסק');
    if (!formData.primary_category) return toast.error('נא לבחור קטגוריה ראשית');
    if (!formData.city) return toast.error('נא לבחור עיר');
    if (!formData.address) return toast.error('נא להזין כתובת');
    if (!formData.latitude || !formData.longitude) return toast.error('נא לבחור מיקום במפה');
    if (!mainImage) return toast.error('נא להעלות תמונה ראשית לעסק');

    const hasValidHours = formData.opening_hours.some(day => !day.isClosed && day.open && day.close);
    if (!hasValidHours) return toast.error('נא להזין שעות פעילות לפחות ליום אחד');

    setSubmitting(true);
    try {
      const submitData = new FormData();
      submitData.append('name', formData.name);
      submitData.append('primary_category', formData.primary_category);
      if (formData.subcategory) submitData.append('subcategory', formData.subcategory);
      if (formData.phone) submitData.append('phone', formData.phone);
      
      const fullAddress = [formData.street, formData.building_number, formData.city].filter(Boolean).join(', ') || formData.address;
      submitData.append('address', fullAddress);
      submitData.append('city', formData.city);
      
      submitData.append('latitude', formData.latitude);
      submitData.append('longitude', formData.longitude);
      submitData.append('opening_hours', JSON.stringify(formData.opening_hours));
      submitData.append('owner_id', currentUser?.id);
      submitData.append('status', 'pending');
      
      submitData.append('images', mainImage);
      additionalImages.forEach(img => submitData.append('images', img));

      await pb.collection('businesses').create(submitData, { $autoCancel: false });

      toast.success('העסק נוצר בהצלחה ונשלח לאישור!');
      navigate('/owner/dashboard');
    } catch (error) {
      console.error('Error creating business:', error);
      toast.error('שגיאה בשמירת העסק. אנא בדוק את הפרטים ונסה שוב.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>הוספת עסק חדש - פורטל עסקים</title>
      </Helmet>

      <div className="min-h-screen bg-muted/30 pb-24">
        <header className="bg-card border-b border-border sticky top-0 z-30 shadow-sm backdrop-blur-md bg-card/90">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
            <h1 className="text-xl font-bold text-foreground">הוספת עסק חדש</h1>
            <Button variant="ghost" onClick={() => navigate(-1)} className="text-muted-foreground hover:text-foreground">
              ביטול חזרה
            </Button>
          </div>
        </header>

        <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 pt-10">
          <form onSubmit={handleSubmit} className="space-y-10">
            
            {/* Basic Details */}
            <section className="bg-card rounded-2xl shadow-sm border border-border/50 p-6 md:p-8">
              <div className="flex items-center gap-3 mb-8 pb-4 border-b border-border/40">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                  <Store className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold">פרטים בסיסיים</h2>
                  <p className="text-sm text-muted-foreground mt-1">מידע כללי ופרטי התקשרות של העסק</p>
                </div>
              </div>
              
              <div className="space-y-6">
                <div>
                  <Label htmlFor="name" className="text-sm font-semibold mb-2 block">שם העסק *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => handleChange('name', e.target.value)}
                    className="h-12 bg-background border-input rounded-xl focus-visible:ring-2 focus-visible:ring-primary/20 focus-visible:border-primary text-base"
                    placeholder="הזן את שם העסק"
                    required
                  />
                </div>

                <div className={`grid grid-cols-1 ${availableSubcategories.length > 0 ? 'md:grid-cols-2' : ''} gap-6`}>
                  <div>
                    <Label className="text-sm font-semibold mb-2 block">קטגוריה ראשית *</Label>
                    <Select key="owner-add-primary-category" value={formData.primary_category || undefined} onValueChange={(val) => handleChange('primary_category', val)}>
                      <SelectTrigger className="h-12 bg-background border-input rounded-xl text-right text-base">
                        <SelectValue placeholder="בחר קטגוריה ראשית" />
                      </SelectTrigger>
                      <SelectContent>
                        {PRIMARY_CATEGORIES.map(cat => (
                          <SelectItem key={cat} value={cat} className="cursor-pointer">{cat}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {availableSubcategories.length > 0 && (
                    <div>
                      <Label className="text-sm font-semibold mb-2 block">תת-קטגוריה</Label>
                      <Select 
                        key="owner-add-subcategory"
                        value={formData.subcategory || undefined} 
                        onValueChange={(val) => handleChange('subcategory', val)}
                      >
                        <SelectTrigger className="h-12 bg-background border-input rounded-xl text-right text-base">
                          <SelectValue placeholder="בחר תת-קטגוריה" />
                        </SelectTrigger>
                        <SelectContent>
                          {availableSubcategories.map(sub => (
                            <SelectItem key={sub} value={sub} className="cursor-pointer">{sub}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>

                <div>
                  <Label htmlFor="phone" className="text-sm font-semibold mb-2 block">מספר טלפון</Label>
                  <div className="relative">
                    <Phone className="absolute left-4 top-3.5 h-5 w-5 text-muted-foreground" />
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => handleChange('phone', e.target.value)}
                      className="h-12 bg-background border-input rounded-xl pl-12 text-base"
                      placeholder="05x-xxxxxxx"
                      dir="ltr"
                    />
                  </div>
                </div>
              </div>
            </section>

            {/* Premium Location Section */}
            <section className="bg-card rounded-2xl shadow-sm border border-border/50 p-6 md:p-8">
              <div className="flex items-center gap-3 mb-8 pb-4 border-b border-border/40">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                  <MapPinned className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold">מיקום וכתובת</h2>
                  <p className="text-sm text-muted-foreground mt-1">הזן כתובת או בחר מיקום מדויק על גבי המפה</p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                {/* Left Column: Inputs */}
                <div className="lg:col-span-5 flex flex-col gap-6">
                  <AddressAutocomplete 
                    initialAddress={formData.address}
                    onAddressSelect={handleAddressSelect}
                    onRawChange={(val) => handleChange('address', val)}
                  />

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-semibold mb-2 block">עיר *</Label>
                      <Select key="owner-add-city" value={formData.city || undefined} onValueChange={(val) => handleChange('city', val)} required>
                        <SelectTrigger className="h-12 bg-background border-input rounded-xl text-right text-base">
                          <SelectValue placeholder="בחר עיר" />
                        </SelectTrigger>
                        <SelectContent>
                          {CITIES.map((city, index) => (
                            <SelectItem key={`city-${index}-${city}`} value={city} className="cursor-pointer">{city}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground mb-1.5 block">רחוב</Label>
                      <Input value={formData.street} onChange={(e) => handleChange('street', e.target.value)} className="bg-background h-12 rounded-xl" />
                    </div>
                  </div>

                  {formData.latitude && formData.longitude && (
                    <div className="bg-secondary/40 p-4 rounded-xl border border-secondary mt-auto">
                      <div className="flex items-center gap-2 mb-2 text-secondary-foreground">
                        <Info className="h-4 w-4" />
                        <span className="text-sm font-semibold">קואורדינטות נבחרו</span>
                      </div>
                      <div className="flex gap-4 text-xs font-medium font-mono text-muted-foreground" dir="ltr">
                        <span>Lat: {parseFloat(formData.latitude).toFixed(5)}</span>
                        <span>Lng: {parseFloat(formData.longitude).toFixed(5)}</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Right Column: Map */}
                <div className="lg:col-span-7 h-[450px] lg:h-auto min-h-[450px]">
                  <MapLocationPicker 
                    latitude={formData.latitude}
                    longitude={formData.longitude}
                    onLocationSelect={handleMapLocationSelect}
                  />
                </div>
              </div>
            </section>

            {/* Opening Hours */}
            <section className="bg-card rounded-2xl shadow-sm border border-border/50 p-6 md:p-8">
               <div className="flex items-center gap-3 mb-8 pb-4 border-b border-border/40">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                  <Clock className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold">שעות פעילות</h2>
                  <p className="text-sm text-muted-foreground mt-1">הגדר את שעות פתיחת העסק במהלך השבוע</p>
                </div>
              </div>
              <OpeningHoursTable 
                hours={formData.opening_hours}
                onChange={(newHours) => handleChange('opening_hours', newHours)}
              />
            </section>

            {/* Images */}
            <section className="bg-card rounded-2xl shadow-sm border border-border/50 p-6 md:p-8">
               <div className="flex items-center gap-3 mb-8 pb-4 border-b border-border/40">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                  <ImageIcon className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold">תמונות ומדיה</h2>
                  <p className="text-sm text-muted-foreground mt-1">העלה תמונה ראשית ייצוגית ותמונות נוספות של העסק</p>
                </div>
              </div>

              <div className="space-y-8">
                <div>
                  <Label className="text-sm font-semibold mb-3 block">תמונה ראשית (חובה) *</Label>
                  {!mainImagePreview ? (
                    <label className="flex flex-col items-center justify-center w-full aspect-[21/9] md:aspect-[4/1] border-2 border-dashed border-primary/30 rounded-2xl cursor-pointer hover:bg-primary/5 hover:border-primary transition-all bg-background group">
                      <div className="flex flex-col items-center justify-center pt-5 pb-6 text-center px-4">
                        <div className="bg-primary/10 p-4 rounded-full mb-4 group-hover:scale-110 transition-transform">
                          <Upload className="h-8 w-8 text-primary" />
                        </div>
                        <p className="text-base font-semibold text-foreground mb-1">לחץ להעלאת תמונה ראשית</p>
                        <p className="text-sm text-muted-foreground">PNG, JPG עד 5MB</p>
                      </div>
                      <input type="file" ref={mainImageInputRef} className="hidden" accept="image/*" onChange={handleMainImageChange} />
                    </label>
                  ) : (
                    <div className="relative w-full aspect-[21/9] md:aspect-[4/1] rounded-2xl overflow-hidden group border border-border shadow-sm bg-muted flex items-center justify-center">
                      <img src={mainImagePreview} alt="Main preview" className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <Button type="button" variant="destructive" onClick={removeMainImage} className="rounded-xl shadow-lg h-12 px-6">
                          <X className="h-5 w-5 ml-2" /> החלף תמונה ראשית
                        </Button>
                      </div>
                    </div>
                  )}
                </div>

                <div>
                  <Label className="text-sm font-semibold mb-3 block">גלריית תמונות (אופציונלי)</Label>
                  <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
                    {additionalImagePreviews.map((src, idx) => (
                      <div key={`additional-image-${idx}`} className="relative aspect-square rounded-xl overflow-hidden group border border-border bg-muted shadow-sm flex items-center justify-center">
                        <img src={src} alt={`Gallery preview ${idx}`} className="w-full h-full object-cover" />
                        <button type="button" onClick={() => removeAdditionalImage(idx)} className="absolute top-2 right-2 bg-black/60 text-white hover:bg-destructive rounded-full p-1.5 opacity-0 group-hover:opacity-100 transition-all backdrop-blur-sm hover:scale-110">
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                    
                    {additionalImages.length < 9 && (
                      <label className="flex flex-col items-center justify-center aspect-square border-2 border-dashed border-border rounded-xl cursor-pointer hover:bg-muted transition-colors bg-background group">
                        <Upload className="h-6 w-6 text-muted-foreground mb-2 group-hover:text-primary transition-colors" />
                        <span className="text-xs font-medium text-muted-foreground text-center px-2 group-hover:text-foreground transition-colors">הוסף תמונות</span>
                        <input type="file" multiple ref={additionalImagesInputRef} className="hidden" accept="image/*" onChange={handleAdditionalImagesChange} />
                      </label>
                    )}
                  </div>
                </div>
              </div>
            </section>

            <div className="flex flex-col-reverse sm:flex-row justify-end gap-4 pt-6">
              <Button type="button" variant="outline" size="lg" onClick={() => navigate(-1)} className="rounded-xl px-8 h-14 bg-background border-border text-foreground hover:bg-muted w-full sm:w-auto font-semibold" disabled={submitting}>
                ביטול חזרה
              </Button>
              <Button type="submit" size="lg" disabled={submitting} className="rounded-xl px-12 h-14 text-base shadow-lg w-full sm:w-auto font-bold bg-primary hover:bg-primary/90 text-primary-foreground">
                {submitting ? <><Loader2 className="mr-2 h-5 w-5 animate-spin" /> שומר עסק...</> : 'שליחת עסק לאישור'}
              </Button>
            </div>
          </form>
        </main>
      </div>
    </>
  );
};

export default BusinessOwnerAddPage;