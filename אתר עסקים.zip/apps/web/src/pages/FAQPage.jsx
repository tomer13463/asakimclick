import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { HelpCircle } from 'lucide-react';
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from '@/components/ui/accordion';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { setMetaTags } from '@/lib/seoUtils.js';
import { getFAQSchema } from '@/lib/schemaUtils.js';

const faqs = [
  {
    question: "איך מוצאים עסקים?",
    answer: "ניתן למצוא עסקים באמצעות שורת החיפוש בעמוד הבית, על ידי הקלדת שם העסק, תחום העיסוק או העיר. בנוסף, ניתן לנווט דרך עמוד הקטגוריות ולסנן תוצאות לפי דירוג ומרחק."
  },
  {
    question: "איך משאירים ביקורת?",
    answer: "כדי להשאיר ביקורת יש להתחבר למערכת. לאחר מכן, היכנסו לעמוד העסק הרלוונטי, לחצו על כפתור 'הוסף ביקורת', דרגו באמצעות כוכבים וכתבו את חוות דעתכם. הביקורת תעבור אישור מהיר לפני פרסומה."
  },
  {
    question: "איך מוסיפים עסק?",
    answer: "בעלי עסקים יכולים להצטרף לפלטפורמה על ידי לחיצה על 'הוסף עסק' בתפריט העליון, יצירת חשבון בעל עסק, ומילוי פרטי העסק. הצוות שלנו יבדוק את הבקשה ויאשר את העסק בהקדם."
  },
  {
    question: "איך משתמשים בחיפוש?",
    answer: "מנוע החיפוש שלנו מאפשר לחפש טקסט חופשי. ניתן להקליד מילות מפתח, שמות של מקצועות, או שירותים ספציפיים. לקבלת תוצאות מדויקות יותר, השתמשו במסננים בצד ימין של עמוד התוצאות."
  },
  {
    question: "איך משתמשים בקטגוריות?",
    answer: "עמוד הקטגוריות מרכז את כל תחומי העיסוק בצורה מסודרת. לחיצה על קטגוריה ראשית (כמו 'שירותי בית') תציג לכם את כל העסקים בתחום זה, ולאחר מכן תוכלו לסנן לתתי-קטגוריות ספציפיות כמו 'אינסטלטור' או 'חשמלאי'."
  },
  {
    question: "מה זה ביקורות?",
    answer: "ביקורות הן חוות דעת אותנטיות שנכתבו על ידי משתמשים שקיבלו שירות מהעסק. הדירוג משוקלל לכוכבים מ-1 עד 5. אנו משתדלים לאמת כל ביקורת כדי להבטיח את אמינות הפלטפורמה."
  },
  {
    question: "איך עובד הניווט?",
    answer: "בכל עמוד עסק תמצאו כפתורי ניווט חכמים למפה. לחיצה עליהם תפתח את אפליקציית Waze או Google Maps במכשיר שלכם עם הכתובת המדויקת של העסק לנווט ישיר ומהיר."
  }
];

const FAQPage = () => {
  useEffect(() => {
    setMetaTags({
      title: 'שאלות נפוצות - עסקים בקליק',
      description: 'תשובות לשאלות נפוצות על פלטפורמת מפתח עסקים, חיפוש עסקים, השארת ביקורות והצטרפות כבעל עסק.',
      keywords: 'שאלות נפוצות, עזרה, מדריך, עסקים בקליק'
    });
  }, []);

  const schema = getFAQSchema(faqs);

  return (
    <>
      <Helmet>
        <title>שאלות נפוצות - עסקים בקליק</title>
        <script type="application/ld+json">{JSON.stringify(schema)}</script>
      </Helmet>

      <div className="min-h-screen bg-background flex flex-col">
        <Header />

        <main className="flex-1 w-full max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-24 md:py-32">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-16"
          >
            <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-6 text-primary">
              <HelpCircle className="w-8 h-8" />
            </div>
            <h1 className="text-4xl md:text-5xl font-extrabold text-foreground mb-4" style={{ textBalance: 'balance' }}>
              שאלות נפוצות
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              כל מה שצריך לדעת על השימוש בפלטפורמה, מציאת עסקים וניהול חשבונות.
            </p>
          </motion.div>

          <motion.div
            initial="hidden"
            animate="visible"
            variants={{
              hidden: { opacity: 0 },
              visible: {
                opacity: 1,
                transition: { staggerChildren: 0.1 }
              }
            }}
            className="bg-card rounded-3xl shadow-sm border border-border p-6 md:p-8"
          >
            <Accordion type="single" collapsible className="w-full">
              {faqs.map((faq, index) => (
                <motion.div 
                  key={index}
                  variants={{
                    hidden: { opacity: 0, y: 10 },
                    visible: { opacity: 1, y: 0 }
                  }}
                >
                  <AccordionItem value={`item-${index}`} className="border-b border-border/50 py-2">
                    <AccordionTrigger className="text-lg font-semibold text-foreground hover:text-primary transition-colors text-right justify-between [&[data-state=open]>svg]:rotate-180">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-base text-muted-foreground leading-relaxed pt-2 pb-4 accordion-content-open">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                </motion.div>
              ))}
            </Accordion>
          </motion.div>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default FAQPage;