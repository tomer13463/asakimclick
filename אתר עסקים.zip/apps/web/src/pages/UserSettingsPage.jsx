import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Settings, User, Mail, Lock, Loader2 } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import { useAuth } from '@/contexts/AuthContext.jsx';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { toast } from 'sonner';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

const UserSettingsPage = () => {
  const { currentUser } = useAuth();
  
  const [name, setName] = useState(currentUser?.name || '');
  const [email, setEmail] = useState('');
  
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  
  const [nameLoading, setNameLoading] = useState(false);
  const [emailLoading, setEmailLoading] = useState(false);
  const [passwordLoading, setPasswordLoading] = useState(false);

  const handleUpdateName = async (e) => {
    e.preventDefault();
    if (!name.trim()) return toast.error('שם לא יכול להיות ריק');
    
    setNameLoading(true);
    try {
      await pb.collection('users').update(currentUser.id, { name }, { $autoCancel: false });
      toast.success('השם עודכן בהצלחה');
    } catch (error) {
      console.error('Update name error:', error);
      toast.error('שגיאה בעדכון השם');
    } finally {
      setNameLoading(false);
    }
  };

  const handleUpdateEmail = async (e) => {
    e.preventDefault();
    if (!email.trim() || !email.includes('@')) return toast.error('כתובת אימייל לא תקינה');
    
    setEmailLoading(true);
    try {
      // In PB we can request email change
      await pb.collection('users').requestEmailChange(email, { $autoCancel: false });
      toast.success('נשלח מייל אישור לכתובת החדשה');
      setEmail('');
    } catch (error) {
      console.error('Update email error:', error);
      toast.error(error.message || 'שגיאה בשינוי כתובת אימייל');
    } finally {
      setEmailLoading(false);
    }
  };

  const handleUpdatePassword = async (e) => {
    e.preventDefault();
    if (!oldPassword) return toast.error('יש להזין סיסמה נוכחית');
    if (newPassword.length < 8) return toast.error('הסיסמה החדשה חייבת להכיל לפחות 8 תווים');
    if (newPassword !== confirmPassword) return toast.error('הסיסמאות אינן תואמות');

    setPasswordLoading(true);
    try {
      await pb.collection('users').update(currentUser.id, {
        oldPassword: oldPassword,
        password: newPassword,
        passwordConfirm: confirmPassword
      }, { $autoCancel: false });
      
      toast.success('הסיסמה עודכנה בהצלחה');
      setOldPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (error) {
      console.error('Update password error:', error);
      toast.error('הסיסמה הנוכחית שגויה או אירעה שגיאה אחרת');
    } finally {
      setPasswordLoading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>הגדרות חשבון - עסקים בקליק</title>
      </Helmet>

      <div className="min-h-screen bg-muted/30 flex flex-col">
        <Header />

        <main className="flex-1 w-full max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex items-center gap-4 mb-8">
            <div className="bg-primary/10 p-3 rounded-2xl text-primary">
              <Settings className="h-8 w-8" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-foreground">הגדרות חשבון</h1>
              <p className="text-muted-foreground">ניהול פרטים אישיים ואבטחה</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
            <div className="md:col-span-8 space-y-8">
              
              {/* Profile Settings */}
              <Card className="border-0 shadow-md rounded-2xl">
                <CardHeader className="border-b border-border/50 pb-4">
                  <CardTitle className="text-xl flex items-center gap-2">
                    <User className="h-5 w-5 text-primary" />
                    פרטים אישיים
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <form onSubmit={handleUpdateName} className="space-y-4">
                    <div>
                      <Label htmlFor="name" className="mb-2 block">שם מלא</Label>
                      <Input 
                        id="name" 
                        value={name} 
                        onChange={(e) => setName(e.target.value)} 
                        className="bg-background rounded-xl"
                      />
                    </div>
                    <div className="flex justify-end">
                      <Button type="submit" disabled={nameLoading} className="rounded-xl">
                        {nameLoading ? <Loader2 className="h-4 w-4 animate-spin ml-2" /> : null}
                        שמור שינויים
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>

              {/* Email Settings */}
              <Card className="border-0 shadow-md rounded-2xl">
                <CardHeader className="border-b border-border/50 pb-4">
                  <CardTitle className="text-xl flex items-center gap-2">
                    <Mail className="h-5 w-5 text-primary" />
                    שינוי כתובת אימייל
                  </CardTitle>
                  <CardDescription>
                    אימייל נוכחי: <span className="font-semibold text-foreground">{currentUser?.email}</span>
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <form onSubmit={handleUpdateEmail} className="space-y-4">
                    <div>
                      <Label htmlFor="email" className="mb-2 block">כתובת אימייל חדשה</Label>
                      <Input 
                        id="email" 
                        type="email" 
                        value={email} 
                        onChange={(e) => setEmail(e.target.value)} 
                        placeholder="new@example.com"
                        className="bg-background rounded-xl text-left"
                        dir="ltr"
                      />
                    </div>
                    <div className="flex justify-end">
                      <Button type="submit" variant="secondary" disabled={emailLoading} className="rounded-xl">
                        {emailLoading ? <Loader2 className="h-4 w-4 animate-spin ml-2" /> : null}
                        בקש שינוי כתובת
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>

              {/* Password Settings */}
              <Card className="border-0 shadow-md rounded-2xl">
                <CardHeader className="border-b border-border/50 pb-4">
                  <CardTitle className="text-xl flex items-center gap-2">
                    <Lock className="h-5 w-5 text-primary" />
                    שינוי סיסמה
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <form onSubmit={handleUpdatePassword} className="space-y-4">
                    <div>
                      <Label htmlFor="oldPassword" className="mb-2 block">סיסמה נוכחית</Label>
                      <Input 
                        id="oldPassword" 
                        type="password" 
                        value={oldPassword} 
                        onChange={(e) => setOldPassword(e.target.value)} 
                        className="bg-background rounded-xl text-left"
                        dir="ltr"
                      />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="newPassword" className="mb-2 block">סיסמה חדשה</Label>
                        <Input 
                          id="newPassword" 
                          type="password" 
                          value={newPassword} 
                          onChange={(e) => setNewPassword(e.target.value)} 
                          className="bg-background rounded-xl text-left"
                          dir="ltr"
                        />
                      </div>
                      <div>
                        <Label htmlFor="confirmPassword" className="mb-2 block">אימות סיסמה חדשה</Label>
                        <Input 
                          id="confirmPassword" 
                          type="password" 
                          value={confirmPassword} 
                          onChange={(e) => setConfirmPassword(e.target.value)} 
                          className="bg-background rounded-xl text-left"
                          dir="ltr"
                        />
                      </div>
                    </div>
                    <div className="flex justify-end">
                      <Button type="submit" variant="default" disabled={passwordLoading} className="rounded-xl">
                        {passwordLoading ? <Loader2 className="h-4 w-4 animate-spin ml-2" /> : null}
                        עדכן סיסמה
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>

            </div>

            {/* Sidebar info */}
            <div className="md:col-span-4 space-y-6">
              <Card className="border-0 shadow-md rounded-2xl bg-primary/5">
                <CardContent className="p-6">
                  <h3 className="font-bold text-lg mb-2 text-primary">טיפים לאבטחה</h3>
                  <ul className="text-sm text-muted-foreground space-y-3 list-disc list-inside pr-4 marker:text-primary/50">
                    <li>השתמש בסיסמה ייחודית המכילה אותיות, מספרים ותווים מיוחדים.</li>
                    <li>לעולם אל תשתף את פרטי ההתחברות שלך עם אף אחד.</li>
                    <li>הקפד להחליף סיסמה כל מספר חודשים.</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default UserSettingsPage;