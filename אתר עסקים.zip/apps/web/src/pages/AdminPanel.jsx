import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

// FIX: Redirect outdated AdminPanel to the fully functional AdminPage
const AdminPanel = () => {
  const navigate = useNavigate();
  
  useEffect(() => {
    navigate('/admin', { replace: true });
  }, [navigate]);

  return null;
};

export default AdminPanel;