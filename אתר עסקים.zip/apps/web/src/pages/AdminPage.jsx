import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { 
  ShieldAlert, Store, Star, Trash2, 
  Check, X, RefreshCcw
} from 'lucide-react';
import { toast } from 'sonner';

import pb from '@/lib/pocketbaseClient';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const updateBusinessRating = async (businessId) => {
  if (!businessId) return;
  try {
    const reviews = await pb.collection('reviews').getFullList({
      filter: `business_id="${businessId}" && status="approved" && is_approved=true`,
      $autoCancel: false
    });
    const count = reviews.length;
    const avg = count > 0 ? reviews.reduce((sum, r) => sum + r.rating, 0) / count : 0;
    const finalRating = Math.round(avg * 10) / 10;
    
    await pb.collection('businesses').update(businessId, {
      rating: finalRating,
      reviews_count: count
    }, { $autoCancel: false });
    
  } catch (err) {
    console.error('Failed to recalculate business rating:', err);
    throw err;
  }
};

const AdminApprovalPanel = () => {
  const [pendingBiz, setPendingBiz] = useState([]);
  const [pendingRev, setPendingRev] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [bizRes, revRes] = await Promise.all([
        pb.collection('businesses').getFullList({ filter: 'status != "approved" || is_approved = false', sort: '-created', $autoCancel: false }),
        pb.collection('reviews').getFullList({ filter: 'status != "approved" || is_approved = false', sort: '-created', $autoCancel: false })
      ]);
      setPendingBiz(bizRes);
      setPendingRev(revRes);
    } catch (err) {
      toast.error('שגיאה בטעינת נתונים לאישור');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleApproveBiz = async (id) => {
    setActionLoading(id);
    try {
      await pb.collection('businesses').update(id, { is_approved: true, status: 'approved' }, { $autoCancel: false });
      toast.success('עסק אושר בהצלחה ויופיע בתוצאות החיפוש');
      await fetchData();
    } catch (err) {
      toast.error('שגיאה באישור עסק: ' + err.message);
    } finally {
      setActionLoading(null);
    }
  };

  const handleRejectBiz = async (id) => {
    if(!window.confirm('לדחות עסק זה? הוא יוסתר מהחיפוש.')) return;
    setActionLoading(id);
    try {
      await pb.collection('businesses').update(id, { is_approved: false, status: 'rejected' }, { $autoCancel: false });
      toast.success('עסק נדחה בהצלחה');
      await fetchData();
    } catch (err) {
      toast.error('שגיאה בדחיית עסק: ' + err.message);
    } finally {
      setActionLoading(null);
    }
  };

  const handleApproveRev = async (rev) => {
    setActionLoading(rev.id);
    try {
      await pb.collection('reviews').update(rev.id, { is_approved: true, status: 'approved' }, { $autoCancel: false });
      await updateBusinessRating(rev.business_id);
      toast.success('ביקורת אושרה ודירוג העסק עודכן בהתאם');
      await fetchData();
    } catch (err) {
      toast.error('שגיאה באישור ביקורת: ' + err.message);
    } finally {
      setActionLoading(null);
    }
  };

  const handleRejectRev = async (rev) => {
    if(!window.confirm('לדחות ביקורת זו?')) return;
    setActionLoading(rev.id);
    try {
      await pb.collection('reviews').update(rev.id, { is_approved: false, status: 'rejected' }, { $autoCancel: false });
      toast.success('ביקורת נדחתה והוסתרה מהעסק');
      await fetchData();
    } catch (err) {
      toast.error('שגיאה בדחיית ביקורת: ' + err.message);
    } finally {
      setActionLoading(null);
    }
  };

  return (
    <div className="space-y-8">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle>עסקים ממתינים לאישור ({pendingBiz.length})</CardTitle>
          <Button variant="ghost" size="sm" onClick={fetchData} disabled={loading}><RefreshCcw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /></Button>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">שם העסק</TableHead>
                  <TableHead className="text-right">קטגוריה</TableHead>
                  <TableHead className="text-right">תאריך</TableHead>
                  <TableHead className="text-right">פעולות</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? <TableRow><TableCell colSpan={4} className="text-center py-8">טוען נתונים...</TableCell></TableRow> :
                 pendingBiz.length === 0 ? <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">אין עסקים ממתינים לאישור</TableCell></TableRow> :
                 pendingBiz.map(b => (
                   <TableRow key={b.id}>
                     <TableCell className="font-medium">{b.name}</TableCell>
                     <TableCell>{b.primary_category}</TableCell>
                     <TableCell>{new Date(b.created).toLocaleDateString('he-IL')}</TableCell>
                     <TableCell>
                       <div className="flex gap-2">
                         <Button size="sm" className="bg-green-600 hover:bg-green-700" disabled={actionLoading === b.id} onClick={() => handleApproveBiz(b.id)}>
                           <Check className="w-4 h-4 mr-1"/> אשר
                         </Button>
                         <Button size="sm" variant="destructive" disabled={actionLoading === b.id} onClick={() => handleRejectBiz(b.id)}>
                           <X className="w-4 h-4 mr-1"/> דחה
                         </Button>
                       </div>
                     </TableCell>
                   </TableRow>
                 ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle>ביקורות ממתינות לאישור ({pendingRev.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right w-1/3">תוכן</TableHead>
                  <TableHead className="text-right">דירוג</TableHead>
                  <TableHead className="text-right">מאת</TableHead>
                  <TableHead className="text-right">פעולות</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? <TableRow><TableCell colSpan={4} className="text-center py-8">טוען נתונים...</TableCell></TableRow> :
                 pendingRev.length === 0 ? <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">אין ביקורות ממתינות לאישור</TableCell></TableRow> :
                 pendingRev.map(r => (
                   <TableRow key={r.id}>
                     <TableCell className="max-w-[200px] truncate" title={r.comment}>{r.comment}</TableCell>
                     <TableCell>
                       <div className="flex items-center text-amber-500">
                         {r.rating} <Star className="w-3 h-3 ml-1 fill-current" />
                       </div>
                     </TableCell>
                     <TableCell>{r.user_name || 'אנונימי'}</TableCell>
                     <TableCell>
                       <div className="flex gap-2">
                         <Button size="sm" className="bg-green-600 hover:bg-green-700" disabled={actionLoading === r.id} onClick={() => handleApproveRev(r)}>
                           <Check className="w-4 h-4 mr-1"/> אשר
                         </Button>
                         <Button size="sm" variant="destructive" disabled={actionLoading === r.id} onClick={() => handleRejectRev(r)}>
                           <X className="w-4 h-4 mr-1"/> דחה
                         </Button>
                       </div>
                     </TableCell>
                   </TableRow>
                 ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

const AdminBusinessManagement = () => {
  const [businesses, setBusinesses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [actionLoading, setActionLoading] = useState(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const res = await pb.collection('businesses').getFullList({ sort: '-created', $autoCancel: false });
      setBusinesses(res);
    } catch (err) { toast.error('שגיאה בטעינת עסקים'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleStatusChange = async (business, newStatus, isApproved) => {
    setActionLoading(business.id);
    try {
      await pb.collection('businesses').update(business.id, { status: newStatus, is_approved: isApproved }, { $autoCancel: false });
      toast.success(`סטטוס העסק עודכן ל: ${newStatus}`);
      await fetchData();
    } catch (err) {
      toast.error('שגיאה בעדכון סטטוס עסק: ' + err.message);
    } finally {
      setActionLoading(null);
    }
  };

  const handleDelete = async (business) => {
    if(!window.confirm('למחוק עסק זה לצמיתות? פעולה זו אינה הפיכה!')) return;
    setActionLoading(business.id);
    try {
      await pb.collection('businesses').delete(business.id, { $autoCancel: false });
      toast.success('עסק נמחק בהצלחה לצמיתות');
      await fetchData();
    } catch (err) { 
      toast.error('שגיאה במחיקת עסק: ' + err.message); 
    } finally {
      setActionLoading(null);
    }
  };

  const filtered = businesses.filter(b => b.name.includes(search));

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row justify-between gap-4 mb-4">
        <Input placeholder="חיפוש עסק לפי שם..." value={search} onChange={e => setSearch(e.target.value)} className="max-w-md bg-card" />
        <Button variant="outline" onClick={fetchData} disabled={loading} className="shrink-0">
          <RefreshCcw className={`w-4 h-4 ml-2 ${loading ? 'animate-spin' : ''}`} /> רענן
        </Button>
      </div>
      
      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-right">שם העסק</TableHead>
              <TableHead className="text-right">קטגוריה</TableHead>
              <TableHead className="text-right">סטטוס</TableHead>
              <TableHead className="text-right">פעולות</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? <TableRow><TableCell colSpan={4} className="text-center py-8">טוען נתונים...</TableCell></TableRow> :
             filtered.length === 0 ? <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">לא נמצאו עסקים</TableCell></TableRow> :
             filtered.map(b => (
               <TableRow key={b.id}>
                 <TableCell className="font-medium">{b.name}</TableCell>
                 <TableCell>{b.primary_category}</TableCell>
                 <TableCell>
                   <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${
                     b.status === 'approved' && b.is_approved ? 'bg-green-100 text-green-800' : 
                     b.status === 'rejected' ? 'bg-red-100 text-red-800' : 
                     'bg-yellow-100 text-yellow-800'
                   }`}>
                     {b.status === 'approved' && b.is_approved ? 'מאושר' : b.status === 'rejected' ? 'נדחה' : 'ממתין'}
                   </span>
                 </TableCell>
                 <TableCell>
                   <div className="flex items-center gap-1">
                     {!(b.status === 'approved' && b.is_approved) && (
                       <Button size="sm" variant="ghost" className="text-green-600 hover:text-green-700 hover:bg-green-50" disabled={actionLoading === b.id} onClick={() => handleStatusChange(b, 'approved', true)} title="אשר עסק">
                         <Check className="w-4 h-4" />
                       </Button>
                     )}
                     {b.status !== 'rejected' && (
                       <Button size="sm" variant="ghost" className="text-orange-600 hover:text-orange-700 hover:bg-orange-50" disabled={actionLoading === b.id} onClick={() => handleStatusChange(b, 'rejected', false)} title="דחה עסק">
                         <X className="w-4 h-4" />
                       </Button>
                     )}
                     <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive hover:bg-destructive/10" disabled={actionLoading === b.id} onClick={() => handleDelete(b)} title="מחק לצמיתות">
                       <Trash2 className="w-4 h-4"/>
                     </Button>
                   </div>
                 </TableCell>
               </TableRow>
             ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

const AdminReviewManagement = () => {
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const res = await pb.collection('reviews').getFullList({ sort: '-created', expand: 'business_id', $autoCancel: false });
      setReviews(res);
    } catch (err) { toast.error('שגיאה בטעינת ביקורות'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleStatusChange = async (review, newStatus, isApproved) => {
    setActionLoading(review.id);
    try {
      await pb.collection('reviews').update(review.id, { status: newStatus, is_approved: isApproved }, { $autoCancel: false });
      await updateBusinessRating(review.business_id);
      toast.success(`סטטוס ביקורת עודכן ודירוג העסק חושב מחדש`);
      await fetchData();
    } catch (err) {
      toast.error('שגיאה בעדכון ביקורת: ' + err.message);
    } finally {
      setActionLoading(null);
    }
  };

  const handleDelete = async (review) => {
    if(!window.confirm('למחוק ביקורת זו לצמיתות?')) return;
    setActionLoading(review.id);
    try {
      await pb.collection('reviews').delete(review.id, { $autoCancel: false });
      if (review.status === 'approved' || review.is_approved) {
        await updateBusinessRating(review.business_id);
      }
      toast.success('ביקורת נמחקה לצמיתות');
      await fetchData();
    } catch (err) { 
      toast.error('שגיאה במחיקה: ' + err.message); 
    } finally {
      setActionLoading(null);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-end mb-4">
        <Button variant="outline" onClick={fetchData} disabled={loading} className="shrink-0">
          <RefreshCcw className={`w-4 h-4 ml-2 ${loading ? 'animate-spin' : ''}`} /> רענן רשימה
        </Button>
      </div>

      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-right w-1/3">תוכן</TableHead>
              <TableHead className="text-right">עסק</TableHead>
              <TableHead className="text-right">דירוג</TableHead>
              <TableHead className="text-right">סטטוס</TableHead>
              <TableHead className="text-right">פעולות</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? <TableRow><TableCell colSpan={5} className="text-center py-8">טוען נתונים...</TableCell></TableRow> :
             reviews.length === 0 ? <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">לא נמצאו ביקורות</TableCell></TableRow> :
             reviews.map(r => (
               <TableRow key={r.id}>
                 <TableCell className="max-w-[200px] truncate" title={r.comment}>{r.comment}</TableCell>
                 <TableCell className="truncate max-w-[150px]">{r.expand?.business_id?.name || 'עסק לא ידוע'}</TableCell>
                 <TableCell>{r.rating}</TableCell>
                 <TableCell>
                   <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${
                     r.status === 'approved' && r.is_approved ? 'bg-green-100 text-green-800' : 
                     r.status === 'rejected' ? 'bg-red-100 text-red-800' : 
                     'bg-yellow-100 text-yellow-800'
                   }`}>
                     {r.status === 'approved' && r.is_approved ? 'מאושר' : r.status === 'rejected' ? 'נדחה' : 'ממתין'}
                   </span>
                 </TableCell>
                 <TableCell>
                   <div className="flex items-center gap-1">
                     {!(r.status === 'approved' && r.is_approved) && (
                       <Button size="sm" variant="ghost" className="text-green-600 hover:text-green-700 hover:bg-green-50" disabled={actionLoading === r.id} onClick={() => handleStatusChange(r, 'approved', true)} title="אשר ביקורת">
                         <Check className="w-4 h-4" />
                       </Button>
                     )}
                     {r.status !== 'rejected' && (
                       <Button size="sm" variant="ghost" className="text-orange-600 hover:text-orange-700 hover:bg-orange-50" disabled={actionLoading === r.id} onClick={() => handleStatusChange(r, 'rejected', false)} title="דחה ביקורת">
                         <X className="w-4 h-4" />
                       </Button>
                     )}
                     <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive hover:bg-destructive/10" disabled={actionLoading === r.id} onClick={() => handleDelete(r)} title="מחק לצמיתות">
                       <Trash2 className="w-4 h-4"/>
                     </Button>
                   </div>
                 </TableCell>
               </TableRow>
             ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

const AdminUserManagement = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const res = await pb.collection('users').getFullList({ sort: '-created', $autoCancel: false });
      setUsers(res);
    } catch (err) { toast.error('שגיאה בטעינת משתמשים'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleDelete = async (user) => {
    if(!window.confirm('למחוק משתמש זה לצמיתות?')) return;
    setActionLoading(user.id);
    try {
      await pb.collection('users').delete(user.id, { $autoCancel: false });
      toast.success('משתמש נמחק בהצלחה');
      await fetchData();
    } catch (err) { 
      toast.error('שגיאה במחיקה: ' + err.message); 
    } finally {
      setActionLoading(null);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-end mb-4">
        <Button variant="outline" onClick={fetchData} disabled={loading} className="shrink-0">
          <RefreshCcw className={`w-4 h-4 ml-2 ${loading ? 'animate-spin' : ''}`} /> רענן רשימה
        </Button>
      </div>

      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-right">שם</TableHead>
              <TableHead className="text-right">אימייל</TableHead>
              <TableHead className="text-right">תאריך הצטרפות</TableHead>
              <TableHead className="text-right">פעולות</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? <TableRow><TableCell colSpan={4} className="text-center py-8">טוען נתונים...</TableCell></TableRow> :
             users.length === 0 ? <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">לא נמצאו משתמשים</TableCell></TableRow> :
             users.map(u => (
               <TableRow key={u.id}>
                 <TableCell className="font-medium">{u.name || '---'}</TableCell>
                 <TableCell>{u.email}</TableCell>
                 <TableCell>{new Date(u.created).toLocaleDateString('he-IL')}</TableCell>
                 <TableCell>
                   <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive hover:bg-destructive/10" disabled={actionLoading === u.id} onClick={() => handleDelete(u)}>
                     <Trash2 className="w-4 h-4"/>
                   </Button>
                 </TableCell>
               </TableRow>
             ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

const DashboardTab = () => {
  const [stats, setStats] = useState({ totalBiz: 0, approvedBiz: 0, pendingBiz: 0, totalRev: 0, approvedRev: 0, pendingRev: 0 });
  const [loading, setLoading] = useState(true);
  
  const fetchStats = useCallback(async () => {
    setLoading(true);
    try {
      const [biz, rev] = await Promise.all([
        pb.collection('businesses').getFullList({ $autoCancel: false }),
        pb.collection('reviews').getFullList({ $autoCancel: false })
      ]);
      setStats({
        totalBiz: biz.length,
        approvedBiz: biz.filter(b => b.status === 'approved' && b.is_approved).length,
        pendingBiz: biz.filter(b => b.status !== 'approved' || !b.is_approved).length,
        totalRev: rev.length,
        approvedRev: rev.filter(r => r.status === 'approved' && r.is_approved).length,
        pendingRev: rev.filter(r => r.status !== 'approved' || !r.is_approved).length
      });
    } catch (err) { 
      toast.error('שגיאה בשליפת נתונים סטטיסטיים');
      console.error(err); 
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchStats(); }, [fetchStats]);

  return (
    <div className="space-y-6">
      <div className="flex justify-end">
        <Button variant="outline" size="sm" onClick={fetchStats} disabled={loading}>
          <RefreshCcw className={`w-4 h-4 ml-2 ${loading ? 'animate-spin' : ''}`} /> רענן נתונים
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="shadow-sm border-border">
          <CardHeader className="bg-secondary/30 pb-4 border-b border-border">
            <CardTitle className="text-xl flex items-center gap-2">
              <Store className="w-5 h-5 text-primary" />
              סטטיסטיקות עסקים
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 pt-6">
            <div className="flex justify-between items-center bg-card p-3 rounded-lg border border-border/50">
              <span className="text-muted-foreground font-medium">סה״כ עסקים רשומים:</span> 
              <span className="font-bold text-xl">{stats.totalBiz}</span>
            </div>
            <div className="flex justify-between items-center bg-green-500/10 p-3 rounded-lg border border-green-500/20 text-green-700">
              <span className="font-medium">עסקים מאושרים:</span> 
              <span className="font-bold text-xl">{stats.approvedBiz}</span>
            </div>
            <div className="flex justify-between items-center bg-amber-500/10 p-3 rounded-lg border border-amber-500/20 text-amber-700">
              <span className="font-medium">עסקים ממתינים לאישור:</span> 
              <span className="font-bold text-xl">{stats.pendingBiz}</span>
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-sm border-border">
          <CardHeader className="bg-secondary/30 pb-4 border-b border-border">
            <CardTitle className="text-xl flex items-center gap-2">
              <Star className="w-5 h-5 text-primary" />
              סטטיסטיקות ביקורות
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 pt-6">
            <div className="flex justify-between items-center bg-card p-3 rounded-lg border border-border/50">
              <span className="text-muted-foreground font-medium">סה״כ ביקורות שנכתבו:</span> 
              <span className="font-bold text-xl">{stats.totalRev}</span>
            </div>
            <div className="flex justify-between items-center bg-green-500/10 p-3 rounded-lg border border-green-500/20 text-green-700">
              <span className="font-medium">ביקורות מאושרות:</span> 
              <span className="font-bold text-xl">{stats.approvedRev}</span>
            </div>
            <div className="flex justify-between items-center bg-amber-500/10 p-3 rounded-lg border border-amber-500/20 text-amber-700">
              <span className="font-medium">ביקורות ממתינות לאישור:</span> 
              <span className="font-bold text-xl">{stats.pendingRev}</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

const AdminPage = () => {
  const navigate = useNavigate();
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [checkingAuth, setCheckingAuth] = useState(true);

  useEffect(() => {
    const model = pb.authStore.model;
    if (pb.authStore.isValid && model?.collectionName === 'admin_users') {
      setIsAuthorized(true);
    }
    setCheckingAuth(false);
  }, []);

  const handleLogout = () => {
    pb.authStore.clear();
    navigate('/');
  };

  if (checkingAuth) return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="flex flex-col items-center gap-4">
        <RefreshCcw className="w-10 h-10 animate-spin text-primary" />
        <span className="text-lg font-medium text-muted-foreground">מוודא הרשאות...</span>
      </div>
    </div>
  );

  if (!isAuthorized) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background text-center p-4">
        <ShieldAlert className="w-20 h-20 text-destructive mb-6" />
        <h1 className="text-4xl font-extrabold text-foreground mb-4">גישה נדחתה</h1>
        <p className="text-lg text-muted-foreground mb-8 max-w-md">
          אין לך הרשאות ניהול למערכת זו. אנא התחבר עם חשבון מנהל כדי להמשיך.
        </p>
        <Link to="/"><Button size="lg" className="rounded-xl px-8">חזרה לעמוד הבית</Button></Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted/20 flex flex-col" dir="rtl">
      <Helmet>
        <title>פאנל ניהול | עסקים בקליק</title>
      </Helmet>

      <header className="bg-card border-b border-border py-4 px-6 sticky top-0 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3 text-primary font-extrabold text-xl">
            <ShieldAlert className="w-6 h-6" /> פאנל מנהלים
          </div>
          <div className="flex items-center gap-4">
            <Link to="/"><Button variant="ghost" className="font-medium">חזרה לאתר</Button></Link>
            <Button variant="outline" className="text-destructive border-destructive/30 hover:bg-destructive hover:text-destructive-foreground transition-colors" onClick={handleLogout}>
              התנתק מהמערכת
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto w-full p-4 sm:p-6 lg:p-8">
        <Tabs defaultValue="dashboard" className="w-full">
          <TabsList className="mb-8 p-1.5 bg-card border border-border rounded-xl flex flex-wrap h-auto gap-2 shadow-sm">
            <TabsTrigger value="dashboard" className="rounded-lg px-4 py-2.5 flex-1 font-medium data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">ראשי</TabsTrigger>
            <TabsTrigger value="approvals" className="rounded-lg px-4 py-2.5 flex-1 font-medium data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">אישורים ממתינים</TabsTrigger>
            <TabsTrigger value="businesses" className="rounded-lg px-4 py-2.5 flex-1 font-medium data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">ניהול עסקים</TabsTrigger>
            <TabsTrigger value="reviews" className="rounded-lg px-4 py-2.5 flex-1 font-medium data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">ניהול ביקורות</TabsTrigger>
            <TabsTrigger value="users" className="rounded-lg px-4 py-2.5 flex-1 font-medium data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">ניהול משתמשים</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="animate-in fade-in duration-300"><DashboardTab /></TabsContent>
          <TabsContent value="approvals" className="animate-in fade-in duration-300"><AdminApprovalPanel /></TabsContent>
          <TabsContent value="businesses" className="animate-in fade-in duration-300"><AdminBusinessManagement /></TabsContent>
          <TabsContent value="reviews" className="animate-in fade-in duration-300"><AdminReviewManagement /></TabsContent>
          <TabsContent value="users" className="animate-in fade-in duration-300"><AdminUserManagement /></TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default AdminPage;