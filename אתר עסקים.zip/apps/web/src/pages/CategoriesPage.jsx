import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Wrench, Briefcase, Store, Coffee } from 'lucide-react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

const MASTER_CATEGORIES = [
  { name: 'שירותי תחזוקה ובית', icon: <Wrench className="h-8 w-8" /> },
  { name: 'מקצועות', icon: <Briefcase className="h-8 w-8" /> },
  { name: 'חנויות', icon: <Store className="h-8 w-8" /> },
  { name: 'מסעדות וקפה', icon: <Coffee className="h-8 w-8" /> }
];

const CategoriesPage = () => {
  const navigate = useNavigate();

  const handleCategoryClick = (categoryName) => {
    navigate(`/search?primary_category=${encodeURIComponent(categoryName)}`);
  };

  return (
    <>
      <Helmet>
        <title>כל הקטגוריות - עסקים בקליק</title>
        <meta name="description" content="עיין בכל קטגוריות העסקים הזמינות בפלטפורמה" />
      </Helmet>

      <div className="min-h-screen bg-background flex flex-col animate-fade-in">
        <Header />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 flex-1 w-full mt-10">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-16"
          >
            <h1 className="text-4xl md:text-5xl font-extrabold mb-6 text-foreground" style={{ textBalance: 'balance' }}>
              כל הקטגוריות
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              בחר קטגוריה כדי לראות את כל העסקים בתחום ולמצוא בדיוק את מה שאתה מחפש.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {MASTER_CATEGORIES.map((category, index) => (
              <motion.div
                key={`category-grid-${index}`}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
              >
                <Card
                  className="cursor-pointer hover:shadow-xl transition-all duration-300 hover:-translate-y-2 h-full rounded-3xl border-border/50 bg-card group"
                  onClick={() => handleCategoryClick(category.name)}
                >
                  <CardContent className="p-8 text-center flex flex-col items-center justify-center h-full gap-6">
                    <div className="w-20 h-20 rounded-2xl bg-primary/10 flex items-center justify-center text-primary text-3xl group-hover:scale-110 transition-transform duration-300 shadow-sm">
                      {category.icon}
                    </div>
                    <p className="font-bold text-2xl text-foreground group-hover:text-primary transition-colors">
                      {category.name}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        <Footer />
      </div>
    </>
  );
};

export default CategoriesPage;