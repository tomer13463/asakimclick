import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Target, Heart, Zap, ShieldCheck, Search, SlidersHorizontal, MousePointerClick, MessageSquare as MessageSquareText } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Card, CardContent } from '@/components/ui/card';
import { setMetaTags } from '@/lib/seoUtils.js';
import { getOrganizationSchema } from '@/lib/schemaUtils.js';

const AboutPage = () => {
  useEffect(() => {
    setMetaTags({
      title: 'אודות עסקים בקליק - המשימה שלנו',
      description: 'למדו עלינו ועל המשימה שלנו להנגיש לכם את העסקים המומלצים והאמינים ביותר בישראל בקלות ובמהירות.',
      keywords: 'אודות, מפתח עסקים, משימה, ערכים, שירותים'
    });
  }, []);

  const schema = getOrganizationSchema();

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.15 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } }
  };

  const processSteps = [
    { icon: <Search className="w-6 h-6" />, title: 'חיפוש', desc: 'מצאו עסקים לפי שם, תחום או מיקום בקלות ובמהירות.' },
    { icon: <SlidersHorizontal className="w-6 h-6" />, title: 'סינון', desc: 'מיינו את התוצאות לפי דירוג, מרחק או זמינות להתאמה מושלמת.' },
    { icon: <MousePointerClick className="w-6 h-6" />, title: 'בחירה', desc: 'השוו בין עסקים בעזרת ביקורות אמינות מלקוחות אמיתיים.' },
    { icon: <MessageSquareText className="w-6 h-6" />, title: 'יצירת קשר', desc: 'פנו לעסק ישירות בלחיצת כפתור דרך טלפון, ווטסאפ או ניווט.' }
  ];

  const advantages = [
    { icon: <ShieldCheck className="w-8 h-8" />, title: 'אמינות ושקיפות', desc: 'אנו מאמתים את העסקים ומקפידים על ביקורות אמיתיות בלבד.' },
    { icon: <Zap className="w-8 h-8" />, title: 'מהירות', desc: 'ממשק מהיר ומתקדם שמאפשר למצוא שירות במינימום קליקים.' },
    { icon: <Heart className="w-8 h-8" />, title: 'חינם לשימוש', desc: 'השימוש בפלטפורמה למציאת עסקים הוא חינמי לחלוטין לקהל הרחב.' },
    { icon: <Target className="w-8 h-8" />, title: 'דיוק בהתאמה', desc: 'מנגנון חיפוש חכם שיודע להתאים את הצורך המדויק שלך לשירות הזמין.' }
  ];

  return (
    <>
      <Helmet>
        <title>אודות עסקים בקליק</title>
        <script type="application/ld+json">{JSON.stringify(schema)}</script>
      </Helmet>

      <div className="min-h-screen bg-background flex flex-col">
        <Header />

        <main className="flex-1 w-full pt-20">
          {/* Hero Section */}
          <section className="relative py-24 md:py-32 overflow-hidden bg-secondary/30">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
              <motion.div initial="hidden" animate="visible" variants={containerVariants}>
                <motion.span variants={itemVariants} className="inline-block py-1.5 px-4 rounded-full bg-primary/10 text-primary font-bold text-sm mb-6 border border-primary/20">
                  הסיפור שלנו
                </motion.span>
                <motion.h1 variants={itemVariants} className="text-4xl md:text-6xl font-extrabold text-foreground mb-6" style={{ textBalance: 'balance' }}>
                  אודות <span className="text-primary">עסקים בקליק</span>
                </motion.h1>
                <motion.p variants={itemVariants} className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                  הפלטפורמה המובילה והחדשנית בישראל למציאת בעלי מקצוע, שירותים ועסקים מומלצים בסביבה שלך.
                </motion.p>
              </motion.div>
            </div>
          </section>

          {/* Mission & Value (Zig Zag) */}
          <section className="py-20 bg-background">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-20 items-center mb-24">
                <motion.div initial={{ opacity: 0, x: 50 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }}>
                  <h2 className="text-3xl font-bold text-foreground mb-4">מי אנחנו?</h2>
                  <p className="text-lg text-muted-foreground leading-relaxed">
                    עסקים בקליק הוקמה במטרה לפתור את אחת הבעיות הנפוצות ביותר היום: מציאת איש מקצוע אמין ואיכותי ברגע האמת. אנחנו קהילה שצומחת סביב שקיפות, שירות הוגן, וכלכלה מקומית חזקה. דרך המערכת שלנו אנחנו מחברים בין צרכנים הזקוקים לשירות לבין העסקים הטובים ביותר שיכולים לספק אותו.
                  </p>
                </motion.div>
                <motion.div initial={{ opacity: 0, scale: 0.9 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ duration: 0.6 }} className="relative h-80 md:h-[400px] rounded-3xl overflow-hidden shadow-xl">
                  <img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=1000&auto=format&fit=crop" alt="צוות מפתח עסקים" className="w-full h-full object-cover" />
                </motion.div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-20 items-center">
                <motion.div initial={{ opacity: 0, scale: 0.9 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ duration: 0.6 }} className="relative h-80 md:h-[400px] rounded-3xl overflow-hidden shadow-xl order-2 md:order-1">
                  <img src="https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=1000&auto=format&fit=crop" alt="ערכי החברה" className="w-full h-full object-cover" />
                </motion.div>
                <motion.div initial={{ opacity: 0, x: -50 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }} className="order-1 md:order-2">
                  <h2 className="text-3xl font-bold text-foreground mb-4">הערך שלנו</h2>
                  <p className="text-lg text-muted-foreground leading-relaxed">
                    הערך המרכזי שאנו מביאים הוא החיסכון העצום בזמן ובהתלבטויות. אין צורך לחפש שעות ברשת או לשאול בקבוצות – ריכזנו עבורכם מנוע חיפוש מתקדם עם מאגר מדורג של העסקים המקומיים המובילים. כל עסק מקבל דף דיגיטלי מקיף עם מידע רלוונטי שמאפשר לכם לקבל החלטה צרכנית נבונה.
                  </p>
                </motion.div>
              </div>
            </div>
          </section>

          {/* How it Works */}
          <section className="py-20 bg-secondary/30">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-16">
                <h2 className="text-3xl md:text-4xl font-extrabold text-foreground mb-4">איך זה עובד?</h2>
                <p className="text-lg text-muted-foreground">4 צעדים פשוטים לשירות המושלם</p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                {processSteps.map((step, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: idx * 0.1 }}
                    className="text-center flex flex-col items-center"
                  >
                    <div className="w-16 h-16 bg-primary text-primary-foreground rounded-2xl flex items-center justify-center shadow-lg mb-6 relative">
                      {step.icon}
                      <div className="absolute -top-3 -right-3 w-8 h-8 bg-background border-2 border-primary text-primary rounded-full flex items-center justify-center font-bold text-sm">
                        {idx + 1}
                      </div>
                    </div>
                    <h3 className="text-xl font-bold text-foreground mb-3">{step.title}</h3>
                    <p className="text-muted-foreground">{step.desc}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>

          {/* Advantages (Bento Grid) */}
          <section className="py-20 bg-background">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-16">
                <h2 className="text-3xl md:text-4xl font-extrabold text-foreground mb-4">למה לבחור בנו?</h2>
                <p className="text-lg text-muted-foreground">היתרונות שהופכים אותנו לבחירה הראשונה</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
                {advantages.map((adv, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, scale: 0.95 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: idx * 0.1 }}
                    className={`h-full ${idx === 0 || idx === 3 ? 'md:col-span-1 lg:col-span-2' : ''}`}
                  >
                    <Card className="h-full bg-card border-border hover:shadow-lg transition-shadow rounded-3xl overflow-hidden">
                      <CardContent className="p-8 flex flex-col md:flex-row items-start md:items-center gap-6">
                        <div className="w-16 h-16 bg-primary/10 text-primary rounded-2xl flex items-center justify-center shrink-0">
                          {adv.icon}
                        </div>
                        <div>
                          <h3 className="text-2xl font-bold text-foreground mb-2">{adv.title}</h3>
                          <p className="text-muted-foreground text-lg leading-relaxed">{adv.desc}</p>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default AboutPage;