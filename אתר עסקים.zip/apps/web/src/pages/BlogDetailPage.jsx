import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Calendar, User, ArrowRight, Tag } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import BlogCard from '@/components/BlogCard.jsx';
import SkeletonLoader from '@/components/SkeletonLoader.jsx';
import { setMetaTags } from '@/lib/seoUtils.js';
import { getArticleSchema } from '@/lib/schemaUtils.js';

const BlogDetailPage = () => {
  const { slug } = useParams();
  const navigate = useNavigate();
  const [post, setPost] = useState(null);
  const [relatedPosts, setRelatedPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPost = async () => {
      setLoading(true);
      try {
        const result = await pb.collection('blog_posts').getFirstListItem(`slug="${slug}"`, {
          $autoCancel: false
        });
        setPost(result);

        setMetaTags({
          title: `${result.title} | בלוג עסקים בקליק`,
          description: result.excerpt || result.title,
          keywords: result.category ? `${result.category}, בלוג, טיפים, עסקים` : 'בלוג, מאמר',
          image: result.featured_image ? pb.files.getUrl(result, result.featured_image) : null
        });

        // Fetch related posts
        if (result.category) {
          const related = await pb.collection('blog_posts').getList(1, 3, {
            filter: `category="${result.category}" && id!="${result.id}"`,
            sort: '-created',
            $autoCancel: false
          });
          setRelatedPosts(related.items);
        }
      } catch (err) {
        console.error('Error fetching post:', err);
        navigate('/blog');
      } finally {
        setLoading(false);
      }
    };

    fetchPost();
  }, [slug, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <Header />
        <div className="flex-1 w-full max-w-4xl mx-auto px-4 pt-32 pb-20">
          <SkeletonLoader count={1} className="h-10 w-3/4 mb-4" />
          <SkeletonLoader count={1} className="h-6 w-1/2 mb-10" />
          <SkeletonLoader count={1} className="h-96 w-full mb-10 rounded-3xl" />
          <SkeletonLoader count={5} className="h-4 w-full mb-2" />
        </div>
        <Footer />
      </div>
    );
  }

  if (!post) return null;

  const imageUrl = post.featured_image 
    ? pb.files.getUrl(post, post.featured_image) 
    : 'https://images.unsplash.com/photo-1432888498266-38ffec3eaf0a?q=80&w=2000&auto=format&fit=crop';
    
  const date = new Date(post.created).toLocaleDateString('he-IL', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  const schema = getArticleSchema(post);

  return (
    <>
      <Helmet>
        <title>{post.title}</title>
        <script type="application/ld+json">{JSON.stringify(schema)}</script>
      </Helmet>

      <div className="min-h-screen bg-background flex flex-col">
        <Header />

        <main className="flex-1 w-full pt-20">
          <article className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
            <Link to="/blog" className="inline-flex items-center text-muted-foreground hover:text-primary transition-colors mb-8 text-sm font-medium">
              <ArrowRight className="w-4 h-4 ml-2" />
              חזרה לכל הכתבות
            </Link>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-center mb-10"
            >
              {post.category && (
                <div className="inline-flex items-center text-primary bg-primary/10 px-3 py-1 rounded-full text-sm font-bold mb-6">
                  <Tag className="w-4 h-4 ml-1.5" />
                  {post.category}
                </div>
              )}
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-foreground mb-6 leading-tight" style={{ textBalance: 'balance' }}>
                {post.title}
              </h1>
              
              <div className="flex flex-wrap items-center justify-center gap-6 text-muted-foreground font-medium text-sm">
                <div className="flex items-center">
                  <Calendar className="w-4 h-4 ml-2" />
                  {date}
                </div>
                <div className="flex items-center">
                  <User className="w-4 h-4 ml-2" />
                  {post.author || "מערכת עסקים בקליק"}
                </div>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="w-full h-64 md:h-[500px] rounded-3xl overflow-hidden mb-12 shadow-xl"
            >
              <img src={imageUrl} alt={post.title} className="w-full h-full object-cover" />
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="prose prose-lg dark:prose-invert prose-headings:font-bold prose-a:text-primary max-w-none text-foreground leading-relaxed bg-card p-6 md:p-12 rounded-3xl border border-border/50 shadow-sm whitespace-pre-wrap"
            >
              {post.content}
            </motion.div>
          </article>

          {/* Related Posts */}
          {relatedPosts.length > 0 && (
            <section className="bg-secondary/30 py-20 mt-10">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <h2 className="text-3xl font-extrabold text-foreground mb-10 text-center">כתבות קשורות שאולי יעניינו אותך</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {relatedPosts.map((relatedPost, idx) => (
                    <motion.div
                      key={relatedPost.id}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.4, delay: idx * 0.1 }}
                    >
                      <BlogCard post={relatedPost} />
                    </motion.div>
                  ))}
                </div>
              </div>
            </section>
          )}
        </main>

        <Footer />
      </div>
    </>
  );
};

export default BlogDetailPage;