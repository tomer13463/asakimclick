import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Trash2, Star, MessageSquare, Store, Edit2 } from 'lucide-react';
import { toast } from 'sonner';
import pb from '@/lib/pocketbaseClient';
import { useAuth } from '@/contexts/AuthContext.jsx';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import SkeletonLoader from '@/components/SkeletonLoader.jsx';

const DashboardPage = () => {
  const { currentUser } = useAuth();
  const [reviews, setReviews] = useState([]);
  const [businesses, setBusinesses] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchData = useCallback(async () => {
    if (!currentUser?.id) return;
    
    try {
      setLoading(true);
      
      const revResult = await pb.collection('reviews').getList(1, 50, {
        filter: `user_id="${currentUser.id}"`,
        $autoCancel: false,
        sort: '-created'
      });

      const businessIds = [...new Set(revResult.items.map(r => r.business_id).filter(Boolean))];
      let bizMap = {};
      if (businessIds.length > 0) {
        const filterStr = businessIds.map(id => `id="${id}"`).join(' || ');
        const businessesData = await pb.collection('businesses').getFullList({
          filter: filterStr,
          $autoCancel: false
        });
        businessesData.forEach(b => {
          bizMap[b.id] = b.name;
        });
      }

      const enrichedReviews = revResult.items.map(review => ({
        ...review,
        business_name: bizMap[review.business_id] || 'עסק לא ידוע'
      }));

      setReviews(enrichedReviews);

      const bizResult = await pb.collection('businesses').getList(1, 50, {
        filter: `owner_id="${currentUser.id}"`,
        $autoCancel: false,
        sort: '-created'
      });
      setBusinesses(bizResult.items);

    } catch (err) {
      console.error('Error fetching data:', err);
      toast.error('לא הצלחנו לטעון את הנתונים שלך.');
    } finally {
      setLoading(false);
    }
  }, [currentUser]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleDeleteReview = async (id) => {
    if (window.confirm('האם אתה בטוח שברצונך למחוק ביקורת זו לצמיתות?')) {
      try {
        await pb.collection('reviews').delete(id, { $autoCancel: false });
        toast.success('הביקורת נמחקה בהצלחה.');
        setReviews(reviews.filter(r => r.id !== id));
      } catch (err) {
        console.error('Error deleting review:', err);
        toast.error('שגיאה במחיקת הביקורת. נסה שוב מאוחר יותר.');
      }
    }
  };

  const handleDeleteBusiness = async (id) => {
    if (window.confirm('האם אתה בטוח שברצונך למחוק עסק זה לצמיתות?')) {
      try {
        await pb.collection('businesses').delete(id, { $autoCancel: false });
        toast.success('העסק נמחק בהצלחה.');
        setBusinesses(businesses.filter(b => b.id !== id));
      } catch (err) {
        console.error('Error deleting business:', err);
        toast.error('שגיאה במחיקת העסק. נסה שוב מאוחר יותר.');
      }
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.4 } }
  };

  return (
    <>
      <Helmet>
        <title>לוח בקרה אישי</title>
        <meta name="description" content="ניהול הביקורות והעסקים שלך במקום אחד" />
        <meta name="robots" content="noindex, nofollow" />
      </Helmet>

      <div className="min-h-screen bg-background flex flex-col">
        <Header />

        <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 md:py-32">
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12"
          >
            <div>
              <h1 className="text-3xl md:text-5xl font-extrabold text-foreground mb-2" style={{ textBalance: 'balance' }}>
                ברוכים הבאים, <span className="text-primary">{currentUser?.name || currentUser?.email || 'אורח'}</span>
              </h1>
              <p className="text-lg text-muted-foreground">ניהול הפעילות שלך במקום אחד.</p>
            </div>
            <Link to="/add-business">
              <Button size="lg" className="rounded-xl font-semibold shadow-md gap-2 w-full md:w-auto h-12">
                <Store className="w-5 h-5" />
                הוסף עסק חדש
              </Button>
            </Link>
          </motion.div>

          <section className="mb-16">
            <h2 className="text-2xl font-bold text-foreground mb-6">העסקים שלי</h2>
            
            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <SkeletonLoader count={3} type="card" />
              </div>
            ) : businesses.length === 0 ? (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-card border border-dashed border-border/60 rounded-3xl p-8 text-center flex flex-col items-center justify-center"
              >
                <Store className="w-10 h-10 text-muted-foreground/50 mb-4" />
                <h3 className="text-xl font-bold text-foreground mb-2">אין לך עסקים רשומים</h3>
                <p className="text-muted-foreground mb-6">הוסף את העסק שלך כדי להגיע ללקוחות חדשים.</p>
              </motion.div>
            ) : (
              <motion.div 
                variants={containerVariants}
                initial="hidden"
                animate="visible"
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
              >
                {businesses.map((business) => (
                  <motion.div key={business.id} variants={itemVariants} className="h-full">
                    <Card className="h-full flex flex-col bg-card hover:shadow-lg transition-all duration-300 rounded-2xl border-border overflow-hidden relative">
                      <div className="absolute top-4 left-4">
                        <span className={`px-2.5 py-1 rounded-lg text-xs font-bold shadow-sm ${
                          business.is_approved && business.status === 'approved' ? 'badge-approved' : 'badge-pending'
                        }`}>
                          {business.is_approved && business.status === 'approved' ? 'מאושר' : 'בהמתנה לאישור'}
                        </span>
                      </div>
                      <CardContent className="p-6 flex flex-col h-full pt-12">
                        <div className="mb-4">
                          <h3 className="text-xl font-bold text-foreground line-clamp-1 mb-1" title={business.name}>
                            {business.name}
                          </h3>
                          <span className="text-sm text-muted-foreground">{business.primary_category}</span>
                        </div>

                        <div className="flex items-center gap-6 mt-2 mb-6">
                          <div className="flex items-center text-muted-foreground">
                            <Star className="w-4 h-4 text-amber-500 fill-amber-500 ml-1.5" />
                            <span className="font-medium text-foreground">{business.rating || 0}</span>
                          </div>
                          <div className="flex items-center text-muted-foreground">
                            <MessageSquare className="w-4 h-4 ml-1.5" />
                            <span className="font-medium text-foreground">{business.reviews_count || 0} ביקורות</span>
                          </div>
                        </div>

                        <div className="mt-auto pt-4 flex gap-3 border-t border-border/50">
                          <Link to={`/owner/edit/${business.id}`} className="flex-1">
                            <Button variant="outline" className="w-full rounded-xl gap-2 h-10 hover:bg-primary/5 hover:text-primary hover:border-primary/30 transition-colors">
                              <Edit2 className="w-4 h-4" />
                              ערוך
                            </Button>
                          </Link>
                          <Button 
                            variant="destructive" 
                            className="rounded-xl gap-2 h-10 bg-destructive/10 text-destructive hover:bg-destructive hover:text-destructive-foreground border-0 transition-colors"
                            onClick={() => handleDeleteBusiness(business.id)}
                            aria-label="מחק עסק"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </motion.div>
            )}
          </section>

          <section>
            <h2 className="text-2xl font-bold text-foreground mb-6">הביקורות שלי</h2>
            
            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <SkeletonLoader count={3} type="card" />
              </div>
            ) : reviews.length === 0 ? (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-card border border-dashed border-border/60 rounded-3xl p-12 text-center flex flex-col items-center justify-center min-h-[300px]"
              >
                <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mb-6">
                  <MessageSquare className="w-10 h-10 text-primary" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-3">עדיין לא כתבת ביקורות</h3>
                <p className="text-muted-foreground mb-8 max-w-md mx-auto">
                  שתף את החוויות שלך ועזור לאחרים למצוא את העסקים הטובים ביותר.
                </p>
                <Link to="/search">
                  <Button className="rounded-xl shadow-md gap-2 h-12 px-6">
                    <Store className="w-5 h-5" />
                    חפש עסקים לדירוג
                  </Button>
                </Link>
              </motion.div>
            ) : (
              <motion.div 
                variants={containerVariants}
                initial="hidden"
                animate="visible"
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
              >
                {reviews.map((review) => (
                  <motion.div key={review.id} variants={itemVariants} className="h-full">
                    <Card className="h-full flex flex-col bg-card hover:shadow-lg transition-all duration-300 rounded-2xl border-border overflow-hidden relative">
                      <div className="absolute top-4 left-4">
                        <span className={`px-2.5 py-1 rounded-lg text-xs font-bold shadow-sm ${
                          review.is_approved && review.status === 'approved' ? 'badge-approved' : 'badge-pending'
                        }`}>
                          {review.is_approved && review.status === 'approved' ? 'מאושר' : 'בהמתנה לאישור'}
                        </span>
                      </div>
                      <CardContent className="p-6 flex flex-col h-full pt-12">
                        <div className="mb-4">
                          <h3 className="text-xl font-bold text-foreground line-clamp-1 mb-2" title={review.business_name}>
                            {review.business_name}
                          </h3>
                          <div className="flex items-center gap-1">
                            {[...Array(5)].map((_, i) => (
                              <Star 
                                key={i} 
                                className={`h-4 w-4 ${i < review.rating ? 'fill-yellow-400 text-yellow-400' : 'text-muted-foreground/30'}`} 
                              />
                            ))}
                          </div>
                        </div>

                        <p className="text-muted-foreground text-sm leading-relaxed mb-6 flex-1">
                          "{review.comment}"
                        </p>

                        <div className="mt-auto pt-4 flex justify-between items-center border-t border-border/50">
                          <span className="text-xs text-muted-foreground">
                            {new Date(review.created).toLocaleDateString('he-IL')}
                          </span>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            className="text-destructive hover:bg-destructive/10 hover:text-destructive transition-colors"
                            onClick={() => handleDeleteReview(review.id)}
                            aria-label="מחק ביקורת"
                          >
                            <Trash2 className="w-4 h-4 ml-2" />
                            מחק
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </motion.div>
            )}
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default DashboardPage;