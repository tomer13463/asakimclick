import React, { createContext, useContext, useState, useEffect } from 'react';
import pb from '@/lib/pocketbaseClient';

const BusinessOwnerAuthContext = createContext();

export const useBusinessOwnerAuth = () => {
  const context = useContext(BusinessOwnerAuthContext);
  if (!context) {
    throw new Error('useBusinessOwnerAuth must be used within BusinessOwnerAuthProvider');
  }
  return context;
};

export const BusinessOwnerAuthProvider = ({ children }) => {
  const [currentOwner, setCurrentOwner] = useState(null);
  const [initialLoading, setInitialLoading] = useState(true);

  useEffect(() => {
    const checkAuth = () => {
      if (pb.authStore.isValid && pb.authStore.model?.collectionName === 'business_owners') {
        setCurrentOwner(pb.authStore.model);
      } else {
        setCurrentOwner(null);
      }
      setInitialLoading(false);
    };

    checkAuth();

    const unsubscribe = pb.authStore.onChange(() => {
      checkAuth();
    });

    return () => {
      unsubscribe();
    };
  }, []);

  const signup = async (email, password, passwordConfirm) => {
    const record = await pb.collection('business_owners').create({
      email,
      password,
      passwordConfirm,
    }, { $autoCancel: false });
    return record;
  };

  const login = async (email, password) => {
    const authData = await pb.collection('business_owners').authWithPassword(email, password, { $autoCancel: false });
    return authData;
  };

  const logout = () => {
    pb.authStore.clear();
  };

  const value = {
    currentOwner,
    signup,
    login,
    logout,
    isAuthenticated: !!currentOwner,
    initialLoading
  };

  return <BusinessOwnerAuthContext.Provider value={value}>{children}</BusinessOwnerAuthContext.Provider>;
};