import { useState, useEffect } from 'react';
import pb from '@/lib/pocketbaseClient';

export const useSearch = (query, delay = 300) => {
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!query || query.trim().length < 2) {
      setResults([]);
      return;
    }

    const searchBusinesses = async () => {
      setLoading(true);
      try {
        const searchTerm = query.trim().replace(/"/g, '\\"');
        const filter = `status="approved" && (name ~ "${searchTerm}" || description ~ "${searchTerm}" || primary_category ~ "${searchTerm}" || subcategory ~ "${searchTerm}")`;
        
        const records = await pb.collection('businesses').getList(1, 5, {
          filter,
          sort: '-rating',
          $autoCancel: false
        });
        
        setResults(records.items);
      } catch (error) {
        console.error('Search error:', error);
        setResults([]);
      } finally {
        setLoading(false);
      }
    };

    const timer = setTimeout(() => {
      searchBusinesses();
    }, delay);

    return () => clearTimeout(timer);
  }, [query, delay]);

  return { results, loading };
};