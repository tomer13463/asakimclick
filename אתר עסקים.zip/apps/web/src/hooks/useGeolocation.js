import { useState } from 'react';

export const useGeolocation = () => {
  const [location, setLocation] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const getLocation = () => {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        const msg = 'הדפדפן שלך לא תומך בשירותי מיקום';
        setError(msg);
        reject(msg);
        return;
      }

      setLoading(true);
      setError(null);

      navigator.geolocation.getCurrentPosition(
        (position) => {
          const coords = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          };
          setLocation(coords);
          setLoading(false);
          resolve(coords);
        },
        (err) => {
          let msg = 'אירעה שגיאה בקבלת המיקום';
          if (err.code === 1) { // PERMISSION_DENIED
            msg = 'אנא אפשר גישה למיקום כדי להשתמש בחיפוש קרוב אליי';
          }
          setError(msg);
          setLoading(false);
          reject(msg);
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0
        }
      );
    });
  };

  return { location, error, loading, getLocation };
};