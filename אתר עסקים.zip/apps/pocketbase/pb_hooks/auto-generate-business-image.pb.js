/// <reference path="../pb_data/types.d.ts" />
onRecordAfterCreateSuccess((e) => {
  const images = e.record.get("images");
  
  // Check if images field is empty or null
  if (!images || (Array.isArray(images) && images.length === 0)) {
    const businessId = e.record.id;
    const subcategory = e.record.get("subcategory");
    
    const client = $app.newHttpClient();
    const payload = {
      businessId: businessId,
      subcategory: subcategory
    };
    
    try {
      client.post("http://localhost:3001/hcgi/api/business-image", {
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });
    } catch (err) {
      console.log("Error calling business-image API: " + err.message);
    }
  }
  
  e.next();
}, "businesses");