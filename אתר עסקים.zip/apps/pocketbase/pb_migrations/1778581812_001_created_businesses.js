/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = new Collection({
    "createRule": "@request.auth.id != ''",
    "deleteRule": "owner_id = @request.auth.id || @request.auth.collectionName = 'admin_users'",
    "fields":     [
          {
                "autogeneratePattern": "[a-z0-9]{15}",
                "hidden": false,
                "id": "text6537235271",
                "max": 15,
                "min": 15,
                "name": "id",
                "pattern": "^[a-z0-9]+$",
                "presentable": false,
                "primaryKey": true,
                "required": true,
                "system": true,
                "type": "text"
          },
          {
                "hidden": false,
                "id": "text0673814831",
                "name": "name",
                "presentable": false,
                "primaryKey": false,
                "required": true,
                "system": false,
                "type": "text",
                "autogeneratePattern": "",
                "max": 0,
                "min": 0,
                "pattern": ""
          },
          {
                "hidden": false,
                "id": "select5867836992",
                "name": "category",
                "presentable": false,
                "primaryKey": false,
                "required": true,
                "system": false,
                "type": "select",
                "maxSelect": 1,
                "values": [
                      "\u05de\u05e1\u05e2\u05d3\u05d5\u05ea",
                      "\u05d1\u05ea\u05d9 \u05e7\u05e4\u05d4",
                      "\u05d7\u05e0\u05d5\u05d9\u05d5\u05ea \u05d7\u05d9\u05d5\u05ea",
                      "\u05d5\u05d8\u05e8\u05d9\u05e0\u05e8\u05d9\u05dd",
                      "\u05de\u05e1\u05e4\u05e8\u05d5\u05ea \u05db\u05dc\u05d1\u05d9\u05dd",
                      "\u05de\u05d5\u05e1\u05db\u05d9\u05dd",
                      "\u05d7\u05e9\u05de\u05dc\u05d0\u05d9\u05dd",
                      "\u05d0\u05d9\u05e0\u05e1\u05d8\u05dc\u05d8\u05d5\u05e8\u05d9\u05dd",
                      "\u05de\u05e0\u05e2\u05d5\u05dc\u05e0\u05d9\u05dd",
                      "\u05e0\u05d9\u05e7\u05d9\u05d5\u05df",
                      "\u05e8\u05d5\u05e4\u05d0\u05d9 \u05e9\u05d9\u05e0\u05d9\u05d9\u05dd",
                      "\u05e2\u05d5\u05e8\u05db\u05d9 \u05d3\u05d9\u05df",
                      "\u05e7\u05d5\u05e1\u05de\u05d8\u05d9\u05e7\u05d4",
                      "\u05d7\u05d3\u05e8\u05d9 \u05db\u05d5\u05e9\u05e8",
                      "\u05de\u05e9\u05dc\u05d5\u05d7\u05d9\u05dd",
                      "\u05de\u05d5\u05e8\u05d9\u05dd \u05e4\u05e8\u05d8\u05d9\u05d9\u05dd",
                      "\u05d8\u05db\u05e0\u05d0\u05d9 \u05de\u05d6\u05d2\u05e0\u05d9\u05dd",
                      "\u05d7\u05e0\u05d5\u05d9\u05d5\u05ea \u05e4\u05e8\u05d7\u05d9\u05dd"
                ]
          },
          {
                "hidden": false,
                "id": "select8571349130",
                "name": "city",
                "presentable": false,
                "primaryKey": false,
                "required": true,
                "system": false,
                "type": "select",
                "maxSelect": 1,
                "values": [
                      "\u05ea\u05dc \u05d0\u05d1\u05d9\u05d1",
                      "\u05d9\u05e8\u05d5\u05e9\u05dc\u05d9\u05dd",
                      "\u05d7\u05d9\u05e4\u05d4",
                      "\u05d1\u05d0\u05e8 \u05e9\u05d1\u05e2",
                      "\u05e8\u05d0\u05e9\u05d5\u05df \u05dc\u05e6\u05d9\u05d5\u05df",
                      "\u05e4\u05ea\u05d7 \u05ea\u05e7\u05d5\u05d5\u05d4",
                      "\u05d0\u05e9\u05d3\u05d5\u05d3",
                      "\u05e0\u05ea\u05e0\u05d9\u05d4",
                      "\u05e8\u05de\u05ea \u05d2\u05df",
                      "\u05d2\u05d1\u05e2\u05ea\u05d9\u05d9\u05dd",
                      "\u05db\u05e4\u05e8 \u05e1\u05d1\u05d0",
                      "\u05d4\u05e8\u05e6\u05dc\u05d9\u05d4",
                      "\u05e8\u05e2\u05e0\u05e0\u05d4",
                      "\u05de\u05d5\u05d3\u05d9\u05e2\u05d9\u05df",
                      "\u05dc\u05d5\u05d3",
                      "\u05e8\u05de\u05dc\u05d4",
                      "\u05d0\u05e9\u05e7\u05dc\u05d5\u05df",
                      "\u05e7\u05e8\u05d9\u05d9\u05ea \u05e9\u05de\u05d5\u05e0\u05d4",
                      "\u05e6\u05e4\u05ea",
                      "\u05d8\u05d1\u05e8\u05d9\u05d4"
                ]
          },
          {
                "hidden": false,
                "id": "text2666341209",
                "name": "address",
                "presentable": false,
                "primaryKey": false,
                "required": false,
                "system": false,
                "type": "text",
                "autogeneratePattern": "",
                "max": 0,
                "min": 0,
                "pattern": ""
          },
          {
                "hidden": false,
                "id": "text5938792449",
                "name": "phone",
                "presentable": false,
                "primaryKey": false,
                "required": false,
                "system": false,
                "type": "text",
                "autogeneratePattern": "",
                "max": 0,
                "min": 0,
                "pattern": ""
          },
          {
                "hidden": false,
                "id": "text5934798697",
                "name": "whatsapp",
                "presentable": false,
                "primaryKey": false,
                "required": false,
                "system": false,
                "type": "text",
                "autogeneratePattern": "",
                "max": 0,
                "min": 0,
                "pattern": ""
          },
          {
                "hidden": false,
                "id": "text6551076051",
                "name": "website",
                "presentable": false,
                "primaryKey": false,
                "required": false,
                "system": false,
                "type": "text",
                "autogeneratePattern": "",
                "max": 0,
                "min": 0,
                "pattern": ""
          },
          {
                "hidden": false,
                "id": "text3139520200",
                "name": "description",
                "presentable": false,
                "primaryKey": false,
                "required": false,
                "system": false,
                "type": "text",
                "autogeneratePattern": "",
                "max": 0,
                "min": 0,
                "pattern": ""
          },
          {
                "hidden": false,
                "id": "text8186568568",
                "name": "opening_hours",
                "presentable": false,
                "primaryKey": false,
                "required": false,
                "system": false,
                "type": "text",
                "autogeneratePattern": "",
                "max": 0,
                "min": 0,
                "pattern": ""
          },
          {
                "hidden": false,
                "id": "file7084005685",
                "name": "images",
                "presentable": false,
                "primaryKey": false,
                "required": false,
                "system": false,
                "type": "file",
                "maxSelect": 10,
                "maxSize": 20971520,
                "mimeTypes": [
                      "image/jpeg",
                      "image/png",
                      "image/gif",
                      "image/webp"
                ],
                "thumbs": []
          },
          {
                "hidden": false,
                "id": "text5051701767",
                "name": "services",
                "presentable": false,
                "primaryKey": false,
                "required": false,
                "system": false,
                "type": "text",
                "autogeneratePattern": "",
                "max": 0,
                "min": 0,
                "pattern": ""
          },
          {
                "hidden": false,
                "id": "number6047474440",
                "name": "rating",
                "presentable": false,
                "primaryKey": false,
                "required": false,
                "system": false,
                "type": "number",
                "max": 5,
                "min": 1,
                "onlyInt": false
          },
          {
                "hidden": false,
                "id": "number5679528560",
                "name": "reviews_count",
                "presentable": false,
                "primaryKey": false,
                "required": false,
                "system": false,
                "type": "number",
                "max": null,
                "min": null,
                "onlyInt": false
          },
          {
                "hidden": false,
                "id": "select9745511909",
                "name": "status",
                "presentable": false,
                "primaryKey": false,
                "required": true,
                "system": false,
                "type": "select",
                "maxSelect": 1,
                "values": [
                      "pending",
                      "approved",
                      "rejected"
                ]
          },
          {
                "hidden": false,
                "id": "text8656053484",
                "name": "owner_id",
                "presentable": false,
                "primaryKey": false,
                "required": false,
                "system": false,
                "type": "text",
                "autogeneratePattern": "",
                "max": 0,
                "min": 0,
                "pattern": ""
          },
          {
                "hidden": false,
                "id": "bool2813507238",
                "name": "is_featured",
                "presentable": false,
                "primaryKey": false,
                "required": false,
                "system": false,
                "type": "bool"
          },
          {
                "hidden": false,
                "id": "autodate0759142505",
                "name": "created",
                "onCreate": true,
                "onUpdate": false,
                "presentable": false,
                "system": false,
                "type": "autodate"
          },
          {
                "hidden": false,
                "id": "autodate3782188133",
                "name": "updated",
                "onCreate": true,
                "onUpdate": true,
                "presentable": false,
                "system": false,
                "type": "autodate"
          }
    ],
    "id": "pbc_9666655333",
    "indexes": [],
    "listRule": "status = 'approved'",
    "name": "businesses",
    "system": false,
    "type": "base",
    "updateRule": "owner_id = @request.auth.id || @request.auth.collectionName = 'admin_users'",
    "viewRule": "status = 'approved'"
  });

  try {
    return app.save(collection);
  } catch (e) {
    if (e.message.includes("Collection name must be unique")) {
      console.log("Collection already exists, skipping");
      return;
    }
    throw e;
  }
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("pbc_9666655333");
    return app.delete(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})