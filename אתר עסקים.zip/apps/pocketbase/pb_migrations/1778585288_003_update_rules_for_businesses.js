/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("businesses");
  collection.createRule = "@request.auth.collectionName = 'business_owners'";
  collection.updateRule = "owner_id = @request.auth.id || @request.auth.collectionName = 'admin_users'";
  collection.deleteRule = "owner_id = @request.auth.id || @request.auth.collectionName = 'admin_users'";
  return app.save(collection);
}, (app) => {
  try {
  const collection = app.findCollectionByNameOrId("businesses");
  collection.createRule = "@request.auth.id != ''";
  collection.updateRule = "owner_id = @request.auth.id || @request.auth.collectionName = 'admin_users'";
  collection.deleteRule = "owner_id = @request.auth.id || @request.auth.collectionName = 'admin_users'";
  return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})