/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("reviews");
  collection.createRule = "@request.auth.id != ''";
  collection.updateRule = "@request.auth.collectionName = 'admin_users' || @request.auth.collectionName = 'business_owners'";
  return app.save(collection);
}, (app) => {
  try {
  const collection = app.findCollectionByNameOrId("reviews");
  collection.createRule = "";
  collection.updateRule = null;
  return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})