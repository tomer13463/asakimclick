/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("businesses");

  const record0 = new Record(collection);
    record0.set("name", "\u05de\u05e1\u05e2\u05d3\u05ea \u05d4\u05d9\u05dd");
    record0.set("category", "\u05de\u05e1\u05e2\u05d3\u05d5\u05ea");
    record0.set("city", "\u05ea\u05dc \u05d0\u05d1\u05d9\u05d1");
    record0.set("address", "\u05e8\u05d7\u05d5\u05d1 \u05d4\u05d9\u05dd 45");
    record0.set("phone", "03-5551234");
    record0.set("whatsapp", "0501234567");
    record0.set("description", "\u05de\u05e1\u05e2\u05d3\u05d4 \u05d9\u05e9\u05e8\u05d0\u05dc\u05d9\u05ea \u05de\u05e9\u05d5\u05d1\u05d7\u05ea \u05e2\u05dd \u05d3\u05d2\u05d9\u05dd \u05d8\u05e8\u05d9\u05d9\u05dd \u05d5\u05d8\u05d0\u05d6\u05d4 \u05e9\u05d8\u05d7\u05d5\u05df");
    record0.set("opening_hours", "12:00-23:00");
    record0.set("rating", 4.5);
    record0.set("reviews_count", 45);
    record0.set("status", "approved");
    record0.set("is_featured", true);
  try {
    app.save(record0);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record1 = new Record(collection);
    record1.set("name", "\u05e7\u05e4\u05d4 \u05dc\u05d1\u05df");
    record1.set("category", "\u05d1\u05ea\u05d9 \u05e7\u05e4\u05d4");
    record1.set("city", "\u05d9\u05e8\u05d5\u05e9\u05dc\u05d9\u05dd");
    record1.set("address", "\u05d9\u05e4\u05d5 \u05d4\u05e0\u05d1\u05d9 20");
    record1.set("phone", "02-6234567");
    record1.set("whatsapp", "0502345678");
    record1.set("description", "\u05e7\u05e4\u05d4 \u05d0\u05d9\u05d8\u05dc\u05e7\u05d9 \u05e2\u05dd \u05e7\u05d8\u05d2\u05d5\u05e8\u05d9\u05d4 \u05d1\u05d9\u05e9\u05e8\u05d0\u05dc\u05d9\u05ea \u05d5\u05d8\u05d8\u05d5 \u05d1\u05d9\u05d9\u05d3\u05d9\u05e9");
    record1.set("opening_hours", "07:00-20:00");
    record1.set("rating", 4.2);
    record1.set("reviews_count", 32);
    record1.set("status", "approved");
    record1.set("is_featured", false);
  try {
    app.save(record1);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record2 = new Record(collection);
    record2.set("name", "\u05d7\u05e0\u05d5\u05ea \u05d7\u05d9\u05d5\u05ea \u05e4\u05e8\u05d7");
    record2.set("category", "\u05d7\u05e0\u05d5\u05d9\u05d5\u05ea \u05d7\u05d9\u05d5\u05ea");
    record2.set("city", "\u05d7\u05d9\u05e4\u05d4");
    record2.set("address", "\u05d4\u05d2\u05d3\u05d5\u05dc 15");
    record2.set("phone", "04-8345678");
    record2.set("whatsapp", "0503456789");
    record2.set("description", "\u05d7\u05e0\u05d5\u05ea \u05d7\u05d9\u05d5\u05ea \u05de\u05e9\u05d5\u05d1\u05d7\u05ea \u05e2\u05dd \u05de\u05d2\u05d5\u05d5\u05df \u05d1\u05d9\u05e9\u05e8\u05d0\u05dc\u05d9 \u05d5\u05d1\u05d9\u05e0\u05dc\u05d0\u05d5\u05de\u05d9");
    record2.set("opening_hours", "09:00-18:00");
    record2.set("rating", 4.3);
    record2.set("reviews_count", 28);
    record2.set("status", "approved");
    record2.set("is_featured", true);
  try {
    app.save(record2);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record3 = new Record(collection);
    record3.set("name", "\u05d5\u05d8\u05e8\u05d9\u05e0\u05e8 \u05d3\"\u05e8 \u05db\u05d4\u05df");
    record3.set("category", "\u05d5\u05d8\u05e8\u05d9\u05e0\u05e8\u05d9\u05dd");
    record3.set("city", "\u05d1\u05d0\u05e8 \u05e9\u05d1\u05e2");
    record3.set("address", "\u05d4\u05d3\u05e8\u05d5\u05dd 88");
    record3.set("phone", "08-6456789");
    record3.set("whatsapp", "0504567890");
    record3.set("description", "\u05e7\u05dc\u05d9\u05e0\u05d9\u05e7\u05d4 \u05d5\u05d8\u05e8\u05d9\u05e0\u05e8\u05d9\u05ea \u05de\u05e9\u05d5\u05d1\u05d7\u05ea \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e8\u05d5\u05d8\u05d9\u05dd \u05d5\u05d7\u05d9\u05e1\u05d5\u05df");
    record3.set("opening_hours", "08:00-17:00");
    record3.set("rating", 4.7);
    record3.set("reviews_count", 38);
    record3.set("status", "approved");
    record3.set("is_featured", false);
  try {
    app.save(record3);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record4 = new Record(collection);
    record4.set("name", "\u05de\u05e1\u05e4\u05e8\u05ea \u05db\u05dc\u05d1\u05d9\u05dd \u05e4\u05dc\u05d5\u05e1");
    record4.set("category", "\u05de\u05e1\u05e4\u05e8\u05d5\u05ea \u05db\u05dc\u05d1\u05d9\u05dd");
    record4.set("city", "\u05e8\u05d0\u05e9\u05d5\u05df \u05dc\u05e6\u05d9\u05d5\u05df");
    record4.set("address", "\u05d4\u05e8\u05d7\u05d5\u05d1 50");
    record4.set("phone", "09-7567890");
    record4.set("whatsapp", "0505678901");
    record4.set("description", "\u05de\u05e1\u05e4\u05e8\u05d4 \u05de\u05e9\u05d5\u05d1\u05d7\u05ea \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc \u05d5\u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record4.set("opening_hours", "10:00-19:00");
    record4.set("rating", 4.4);
    record4.set("reviews_count", 22);
    record4.set("status", "approved");
    record4.set("is_featured", true);
  try {
    app.save(record4);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record5 = new Record(collection);
    record5.set("name", "\u05de\u05d5\u05e1\u05da \u05d0\u05d1\u05e8\u05d4\u05d5\u05dd");
    record5.set("category", "\u05de\u05d5\u05e1\u05db\u05d9\u05dd");
    record5.set("city", "\u05e4\u05ea\u05d7 \u05ea\u05e7\u05d5\u05d5\u05d4");
    record5.set("address", "\u05d4\u05d2\u05d3\u05d5\u05dc 30");
    record5.set("phone", "09-8678901");
    record5.set("whatsapp", "0506789012");
    record5.set("description", "\u05de\u05d5\u05e1\u05da \u05de\u05e9\u05d5\u05d1\u05d7 \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc \u05d5\u05d8\u05d9\u05e4\u05d5\u05dc");
    record5.set("opening_hours", "08:00-18:00");
    record5.set("rating", 4.1);
    record5.set("reviews_count", 19);
    record5.set("status", "approved");
    record5.set("is_featured", false);
  try {
    app.save(record5);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record6 = new Record(collection);
    record6.set("name", "\u05d7\u05e9\u05de\u05dc\u05d0\u05d9 \u05de\u05d5\u05d1\u05d9\u05dc");
    record6.set("category", "\u05d7\u05e9\u05de\u05dc\u05d0\u05d9\u05dd");
    record6.set("city", "\u05d0\u05e9\u05d3\u05d5\u05d3");
    record6.set("address", "\u05d4\u05d3\u05e8\u05d5\u05dd 12");
    record6.set("phone", "08-7789012");
    record6.set("whatsapp", "0507890123");
    record6.set("description", "\u05d7\u05e9\u05de\u05dc\u05d0\u05d9 \u05de\u05e7\u05e6\u05d5\u05e2\u05d9\u05d9\u05dd \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record6.set("opening_hours", "07:00-19:00");
    record6.set("rating", 4.6);
    record6.set("reviews_count", 41);
    record6.set("status", "approved");
    record6.set("is_featured", true);
  try {
    app.save(record6);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record7 = new Record(collection);
    record7.set("name", "\u05d0\u05d9\u05e0\u05e1\u05d8\u05dc\u05d8\u05d5\u05e8 \u05de\u05e7\u05e6\u05d5\u05e2\u05d9");
    record7.set("category", "\u05d0\u05d9\u05e0\u05e1\u05d8\u05dc\u05d8\u05d5\u05e8\u05d9\u05dd");
    record7.set("city", "\u05e0\u05ea\u05e0\u05d9\u05d4");
    record7.set("address", "\u05d4\u05d9\u05e8\u05d3\u05df 25");
    record7.set("phone", "09-8890123");
    record7.set("whatsapp", "0508901234");
    record7.set("description", "\u05d0\u05d9\u05e0\u05e1\u05d8\u05dc\u05d8\u05d5\u05e8 \u05de\u05e7\u05e6\u05d5\u05e2\u05d9 \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record7.set("opening_hours", "08:00-17:00");
    record7.set("rating", 4.3);
    record7.set("reviews_count", 25);
    record7.set("status", "approved");
    record7.set("is_featured", false);
  try {
    app.save(record7);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record8 = new Record(collection);
    record8.set("name", "\u05de\u05e0\u05e2\u05d5\u05dc\u05df 24/7");
    record8.set("category", "\u05de\u05e0\u05e2\u05d5\u05dc\u05e0\u05d9\u05dd");
    record8.set("city", "\u05e8\u05de\u05ea \u05d2\u05df");
    record8.set("address", "\u05d4\u05d2\u05d3\u05d5\u05dc 60");
    record8.set("phone", "03-6901234");
    record8.set("whatsapp", "0509012345");
    record8.set("description", "\u05de\u05e0\u05e2\u05d5\u05dc\u05df \u05e4\u05e2\u05d9\u05dc 24 \u05e9\u05e2\u05d5\u05ea \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record8.set("opening_hours", "00:00-23:59");
    record8.set("rating", 4.8);
    record8.set("reviews_count", 50);
    record8.set("status", "approved");
    record8.set("is_featured", true);
  try {
    app.save(record8);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record9 = new Record(collection);
    record9.set("name", "\u05e9\u05d9\u05e8\u05d5\u05ea \u05e0\u05d9\u05e7\u05d9\u05d5\u05df \u05de\u05e7\u05e6\u05d5\u05e2\u05d9");
    record9.set("category", "\u05e0\u05d9\u05e7\u05d9\u05d5\u05df");
    record9.set("city", "\u05d2\u05d1\u05e2\u05ea\u05d9\u05d9\u05dd");
    record9.set("address", "\u05d4\u05d3\u05e8\u05d5\u05dd 40");
    record9.set("phone", "03-7012345");
    record9.set("whatsapp", "0500123456");
    record9.set("description", "\u05e9\u05d9\u05e8\u05d5\u05ea \u05e0\u05d9\u05e7\u05d9\u05d5\u05df \u05de\u05e7\u05e6\u05d5\u05e2\u05d9\u05d9\u05dd \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record9.set("opening_hours", "08:00-18:00");
    record9.set("rating", 4.2);
    record9.set("reviews_count", 30);
    record9.set("status", "approved");
    record9.set("is_featured", false);
  try {
    app.save(record9);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record10 = new Record(collection);
    record10.set("name", "\u05e7\u05dc\u05d9\u05e0\u05d9\u05e7\u05ea \u05e9\u05d9\u05e0\u05d9\u05d9\u05dd \u05d3\u05e8 \u05dc\u05d5\u05d9");
    record10.set("category", "\u05e8\u05d5\u05e4\u05d0\u05d9 \u05e9\u05d9\u05e0\u05d9\u05d9\u05dd");
    record10.set("city", "\u05db\u05e4\u05e8 \u05e1\u05d1\u05d0");
    record10.set("address", "\u05d4\u05d2\u05d3\u05d5\u05dc 75");
    record10.set("phone", "09-7123456");
    record10.set("whatsapp", "0501234567");
    record10.set("description", "\u05e7\u05dc\u05d9\u05e0\u05d9\u05e7\u05d4 \u05e9\u05d9\u05e0\u05d9\u05d9\u05dd \u05de\u05e9\u05d5\u05d1\u05d7\u05ea \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record10.set("opening_hours", "09:00-17:00");
    record10.set("rating", 4.5);
    record10.set("reviews_count", 35);
    record10.set("status", "approved");
    record10.set("is_featured", true);
  try {
    app.save(record10);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record11 = new Record(collection);
    record11.set("name", "\u05de\u05e9\u05e8\u05d3 \u05e2\u05d5\u05e8\u05db\u05d9 \u05d3\u05d9\u05df \u05db\u05d4\u05df");
    record11.set("category", "\u05e2\u05d5\u05e8\u05db\u05d9 \u05d3\u05d9\u05df");
    record11.set("city", "\u05d4\u05e8\u05e6\u05dc\u05d9\u05d4");
    record11.set("address", "\u05d4\u05d9\u05e8\u05d3\u05df 50");
    record11.set("phone", "09-8234567");
    record11.set("whatsapp", "0502345678");
    record11.set("description", "\u05de\u05e9\u05e8\u05d3 \u05e2\u05d5\u05e8\u05db\u05d9 \u05d3\u05d9\u05df \u05de\u05e9\u05d5\u05d1\u05d7 \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record11.set("opening_hours", "10:00-18:00");
    record11.set("rating", 4.4);
    record11.set("reviews_count", 28);
    record11.set("status", "approved");
    record11.set("is_featured", false);
  try {
    app.save(record11);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record12 = new Record(collection);
    record12.set("name", "\u05e1\u05dc\u05d5\u05df \u05e7\u05d5\u05e1\u05de\u05d8\u05d9\u05e7\u05d4 \u05d9\u05e4\u05d4");
    record12.set("category", "\u05e7\u05d5\u05e1\u05de\u05d8\u05d9\u05e7\u05d4");
    record12.set("city", "\u05e8\u05e2\u05e0\u05e0\u05d4");
    record12.set("address", "\u05d4\u05d2\u05d3\u05d5\u05dc 35");
    record12.set("phone", "09-7345678");
    record12.set("whatsapp", "0503456789");
    record12.set("description", "\u05e1\u05dc\u05d5\u05df \u05e7\u05d5\u05e1\u05de\u05d8\u05d9\u05e7\u05d4 \u05de\u05e9\u05d5\u05d1\u05d7 \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record12.set("opening_hours", "09:00-19:00");
    record12.set("rating", 4.6);
    record12.set("reviews_count", 42);
    record12.set("status", "approved");
    record12.set("is_featured", true);
  try {
    app.save(record12);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record13 = new Record(collection);
    record13.set("name", "\u05d7\u05d3\u05e8 \u05db\u05d5\u05e9\u05e8 \u05e4\u05d9\u05d8\u05e0\u05e1");
    record13.set("category", "\u05d7\u05d3\u05e8\u05d9 \u05db\u05d5\u05e9\u05e8");
    record13.set("city", "\u05de\u05d5\u05d3\u05d9\u05e2\u05d9\u05df");
    record13.set("address", "\u05d4\u05d3\u05e8\u05d5\u05dd 20");
    record13.set("phone", "08-6345678");
    record13.set("whatsapp", "0504567890");
    record13.set("description", "\u05d7\u05d3\u05e8 \u05db\u05d5\u05e9\u05e8 \u05de\u05e9\u05d5\u05d1\u05d7 \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record13.set("opening_hours", "06:00-22:00");
    record13.set("rating", 4.3);
    record13.set("reviews_count", 33);
    record13.set("status", "approved");
    record13.set("is_featured", false);
  try {
    app.save(record13);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record14 = new Record(collection);
    record14.set("name", "\u05de\u05e9\u05dc\u05d5\u05d7\u05d9\u05dd \u05de\u05d4\u05d9\u05e8");
    record14.set("category", "\u05de\u05e9\u05dc\u05d5\u05d7\u05d9\u05dd");
    record14.set("city", "\u05dc\u05d5\u05d3");
    record14.set("address", "\u05d4\u05d2\u05d3\u05d5\u05dc 10");
    record14.set("phone", "08-7456789");
    record14.set("whatsapp", "0505678901");
    record14.set("description", "\u05e9\u05d9\u05e8\u05d5\u05ea \u05de\u05e9\u05dc\u05d5\u05d7\u05d9\u05dd \u05de\u05d4\u05d9\u05e8 \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record14.set("opening_hours", "08:00-20:00");
    record14.set("rating", 4.1);
    record14.set("reviews_count", 24);
    record14.set("status", "approved");
    record14.set("is_featured", true);
  try {
    app.save(record14);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record15 = new Record(collection);
    record15.set("name", "\u05de\u05d5\u05e8\u05d4 \u05e4\u05e8\u05d8\u05d9\u05ea \u05de\u05ea\u05de\u05d8\u05d9\u05e7\u05d4");
    record15.set("category", "\u05de\u05d5\u05e8\u05d9\u05dd \u05e4\u05e8\u05d8\u05d9\u05d9\u05dd");
    record15.set("city", "\u05e8\u05de\u05dc\u05d4");
    record15.set("address", "\u05d4\u05d9\u05e8\u05d3\u05df 15");
    record15.set("phone", "08-8567890");
    record15.set("whatsapp", "0506789012");
    record15.set("description", "\u05de\u05d5\u05e8\u05d4 \u05e4\u05e8\u05d8\u05d9\u05ea \u05de\u05ea\u05de\u05d8\u05d9\u05e7\u05d4 \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record15.set("opening_hours", "15:00-20:00");
    record15.set("rating", 4.7);
    record15.set("reviews_count", 38);
    record15.set("status", "approved");
    record15.set("is_featured", false);
  try {
    app.save(record15);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record16 = new Record(collection);
    record16.set("name", "\u05d8\u05db\u05e0\u05d0\u05d9 \u05de\u05d6\u05d2\u05e0\u05d9\u05dd \u05de\u05e7\u05e6\u05d5\u05e2\u05d9");
    record16.set("category", "\u05d8\u05db\u05e0\u05d0\u05d9 \u05de\u05d6\u05d2\u05e0\u05d9\u05dd");
    record16.set("city", "\u05d0\u05e9\u05e7\u05dc\u05d5\u05df");
    record16.set("address", "\u05d4\u05d3\u05e8\u05d5\u05dd 55");
    record16.set("phone", "08-9678901");
    record16.set("whatsapp", "0507890123");
    record16.set("description", "\u05d8\u05db\u05e0\u05d0\u05d9 \u05de\u05d6\u05d2\u05e0\u05d9\u05dd \u05de\u05e7\u05e6\u05d5\u05e2\u05d9\u05d9\u05dd \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record16.set("opening_hours", "08:00-18:00");
    record16.set("rating", 4.4);
    record16.set("reviews_count", 29);
    record16.set("status", "approved");
    record16.set("is_featured", true);
  try {
    app.save(record16);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record17 = new Record(collection);
    record17.set("name", "\u05d7\u05e0\u05d5\u05ea \u05e4\u05e8\u05d7\u05d9\u05dd \u05d9\u05e4\u05d4");
    record17.set("category", "\u05d7\u05e0\u05d5\u05d9\u05d5\u05ea \u05e4\u05e8\u05d7\u05d9\u05dd");
    record17.set("city", "\u05e7\u05e8\u05d9\u05d9\u05ea \u05e9\u05de\u05d5\u05e0\u05d4");
    record17.set("address", "\u05d4\u05d2\u05d3\u05d5\u05dc 8");
    record17.set("phone", "04-6789012");
    record17.set("whatsapp", "0508901234");
    record17.set("description", "\u05d7\u05e0\u05d5\u05ea \u05e4\u05e8\u05d7\u05d9\u05dd \u05d9\u05e4\u05d4 \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record17.set("opening_hours", "09:00-17:00");
    record17.set("rating", 4.5);
    record17.set("reviews_count", 31);
    record17.set("status", "approved");
    record17.set("is_featured", false);
  try {
    app.save(record17);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record18 = new Record(collection);
    record18.set("name", "\u05de\u05e1\u05e2\u05d3\u05d4 \u05d9\u05e9\u05e8\u05d0\u05dc\u05d9\u05ea \u05d1\u05d9\u05d7\u05d9\u05d3\u05d4");
    record18.set("category", "\u05de\u05e1\u05e2\u05d3\u05d5\u05ea");
    record18.set("city", "\u05d8\u05d1\u05e8\u05d9\u05d4");
    record18.set("address", "\u05d4\u05d2\u05d3\u05d5\u05dc 70");
    record18.set("phone", "04-7890123");
    record18.set("whatsapp", "0509012345");
    record18.set("description", "\u05de\u05e1\u05e2\u05d3\u05d4 \u05d9\u05e9\u05e8\u05d0\u05dc\u05d9\u05ea \u05d1\u05d9\u05d7\u05d9\u05d3\u05d4 \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record18.set("opening_hours", "12:00-22:00");
    record18.set("rating", 4.2);
    record18.set("reviews_count", 26);
    record18.set("status", "approved");
    record18.set("is_featured", true);
  try {
    app.save(record18);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record19 = new Record(collection);
    record19.set("name", "\u05e7\u05e4\u05d4 \u05d4\u05d1\u05d5\u05e7\u05e8");
    record19.set("category", "\u05d1\u05ea\u05d9 \u05e7\u05e4\u05d4");
    record19.set("city", "\u05e6\u05e4\u05ea");
    record19.set("address", "\u05d4\u05d9\u05e8\u05d3\u05df 22");
    record19.set("phone", "04-8901234");
    record19.set("whatsapp", "0500123456");
    record19.set("description", "\u05e7\u05e4\u05d4 \u05d4\u05d1\u05d5\u05e7\u05e8 \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record19.set("opening_hours", "07:00-19:00");
    record19.set("rating", 4.3);
    record19.set("reviews_count", 27);
    record19.set("status", "approved");
    record19.set("is_featured", false);
  try {
    app.save(record19);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record20 = new Record(collection);
    record20.set("name", "\u05d7\u05e0\u05d5\u05ea \u05d7\u05d9\u05d5\u05ea \u05d4\u05d2\u05d3\u05d5\u05dc");
    record20.set("category", "\u05d7\u05e0\u05d5\u05d9\u05d5\u05ea \u05d7\u05d9\u05d5\u05ea");
    record20.set("city", "\u05d2\u05d1\u05e2\u05ea\u05d9\u05d9\u05dd");
    record20.set("address", "\u05d4\u05d3\u05e8\u05d5\u05dd 18");
    record20.set("phone", "03-8012345");
    record20.set("whatsapp", "0501234567");
    record20.set("description", "\u05d7\u05e0\u05d5\u05ea \u05d7\u05d9\u05d5\u05ea \u05d4\u05d2\u05d3\u05d5\u05dc \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record20.set("opening_hours", "09:00-18:00");
    record20.set("rating", 4.6);
    record20.set("reviews_count", 39);
    record20.set("status", "approved");
    record20.set("is_featured", true);
  try {
    app.save(record20);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record21 = new Record(collection);
    record21.set("name", "\u05d5\u05d8\u05e8\u05d9\u05e0\u05e8 \u05d3\u05e8 \u05d3\u05d1\u05d5\u05e8\u05d4");
    record21.set("category", "\u05d5\u05d8\u05e8\u05d9\u05e0\u05e8\u05d9\u05dd");
    record21.set("city", "\u05db\u05e4\u05e8 \u05e1\u05d1\u05d0");
    record21.set("address", "\u05d4\u05d9\u05e8\u05d3\u05df 40");
    record21.set("phone", "09-7234567");
    record21.set("whatsapp", "0502345678");
    record21.set("description", "\u05d5\u05d8\u05e8\u05d9\u05e0\u05e8 \u05d3\u05e8 \u05d3\u05d1\u05d5\u05e8\u05d4 \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record21.set("opening_hours", "08:00-17:00");
    record21.set("rating", 4.4);
    record21.set("reviews_count", 30);
    record21.set("status", "approved");
    record21.set("is_featured", false);
  try {
    app.save(record21);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record22 = new Record(collection);
    record22.set("name", "\u05de\u05e1\u05e4\u05e8\u05d4 \u05db\u05dc\u05d1\u05d9\u05dd \u05d4\u05d2\u05d3\u05d5\u05dc");
    record22.set("category", "\u05de\u05e1\u05e4\u05e8\u05d5\u05ea \u05db\u05dc\u05d1\u05d9\u05dd");
    record22.set("city", "\u05d4\u05e8\u05e6\u05dc\u05d9\u05d4");
    record22.set("address", "\u05d4\u05d2\u05d3\u05d5\u05dc 65");
    record22.set("phone", "09-8345678");
    record22.set("whatsapp", "0503456789");
    record22.set("description", "\u05de\u05e1\u05e4\u05e8\u05d4 \u05db\u05dc\u05d1\u05d9\u05dd \u05d4\u05d2\u05d3\u05d5\u05dc \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record22.set("opening_hours", "10:00-19:00");
    record22.set("rating", 4.5);
    record22.set("reviews_count", 34);
    record22.set("status", "approved");
    record22.set("is_featured", true);
  try {
    app.save(record22);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record23 = new Record(collection);
    record23.set("name", "\u05de\u05d5\u05e1\u05da \u05d4\u05d2\u05d3\u05d5\u05dc");
    record23.set("category", "\u05de\u05d5\u05e1\u05db\u05d9\u05dd");
    record23.set("city", "\u05e8\u05e2\u05e0\u05e0\u05d4");
    record23.set("address", "\u05d4\u05d9\u05e8\u05d3\u05df 30");
    record23.set("phone", "09-7456789");
    record23.set("whatsapp", "0504567890");
    record23.set("description", "\u05de\u05d5\u05e1\u05da \u05d4\u05d2\u05d3\u05d5\u05dc \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record23.set("opening_hours", "08:00-18:00");
    record23.set("rating", 4.2);
    record23.set("reviews_count", 23);
    record23.set("status", "approved");
    record23.set("is_featured", false);
  try {
    app.save(record23);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record24 = new Record(collection);
    record24.set("name", "\u05d7\u05e9\u05de\u05dc\u05d0\u05d9 \u05d4\u05d2\u05d3\u05d5\u05dc");
    record24.set("category", "\u05d7\u05e9\u05de\u05dc\u05d0\u05d9\u05dd");
    record24.set("city", "\u05d9\u05e8\u05d5\u05e9\u05dc\u05d9\u05dd");
    record24.set("address", "\u05d4\u05d3\u05e8\u05d5\u05dd 45");
    record24.set("phone", "02-7567890");
    record24.set("whatsapp", "0505678901");
    record24.set("description", "\u05d7\u05e9\u05de\u05dc\u05d0\u05d9 \u05d4\u05d2\u05d3\u05d5\u05dc \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record24.set("opening_hours", "07:00-19:00");
    record24.set("rating", 4.7);
    record24.set("reviews_count", 44);
    record24.set("status", "approved");
    record24.set("is_featured", true);
  try {
    app.save(record24);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record25 = new Record(collection);
    record25.set("name", "\u05d0\u05d9\u05e0\u05e1\u05d8\u05dc\u05d8\u05d5\u05e8 \u05d4\u05d2\u05d3\u05d5\u05dc");
    record25.set("category", "\u05d0\u05d9\u05e0\u05e1\u05d8\u05dc\u05d8\u05d5\u05e8\u05d9\u05dd");
    record25.set("city", "\u05d7\u05d9\u05e4\u05d4");
    record25.set("address", "\u05d4\u05d9\u05e8\u05d3\u05df 55");
    record25.set("phone", "04-8567890");
    record25.set("whatsapp", "0506789012");
    record25.set("description", "\u05d0\u05d9\u05e0\u05e1\u05d8\u05dc\u05d8\u05d5\u05e8 \u05d4\u05d2\u05d3\u05d5\u05dc \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record25.set("opening_hours", "08:00-17:00");
    record25.set("rating", 4.3);
    record25.set("reviews_count", 26);
    record25.set("status", "approved");
    record25.set("is_featured", false);
  try {
    app.save(record25);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record26 = new Record(collection);
    record26.set("name", "\u05de\u05e0\u05e2\u05d5\u05dc\u05df \u05d4\u05d2\u05d3\u05d5\u05dc");
    record26.set("category", "\u05de\u05e0\u05e2\u05d5\u05dc\u05e0\u05d9\u05dd");
    record26.set("city", "\u05d0\u05e9\u05d3\u05d5\u05d3");
    record26.set("address", "\u05d4\u05d3\u05e8\u05d5\u05dd 35");
    record26.set("phone", "08-8678901");
    record26.set("whatsapp", "0507890123");
    record26.set("description", "\u05de\u05e0\u05e2\u05d5\u05dc\u05df \u05d4\u05d2\u05d3\u05d5\u05dc \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record26.set("opening_hours", "08:00-18:00");
    record26.set("rating", 4.6);
    record26.set("reviews_count", 40);
    record26.set("status", "approved");
    record26.set("is_featured", true);
  try {
    app.save(record26);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record27 = new Record(collection);
    record27.set("name", "\u05e9\u05d9\u05e8\u05d5\u05ea \u05e0\u05d9\u05e7\u05d9\u05d5\u05df \u05d4\u05d2\u05d3\u05d5\u05dc");
    record27.set("category", "\u05e0\u05d9\u05e7\u05d9\u05d5\u05df");
    record27.set("city", "\u05e0\u05ea\u05e0\u05d9\u05d4");
    record27.set("address", "\u05d4\u05d9\u05e8\u05d3\u05df 20");
    record27.set("phone", "09-8789012");
    record27.set("whatsapp", "0508901234");
    record27.set("description", "\u05e9\u05d9\u05e8\u05d5\u05ea \u05e0\u05d9\u05e7\u05d9\u05d5\u05df \u05d4\u05d2\u05d3\u05d5\u05dc \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record27.set("opening_hours", "08:00-18:00");
    record27.set("rating", 4.4);
    record27.set("reviews_count", 28);
    record27.set("status", "approved");
    record27.set("is_featured", false);
  try {
    app.save(record27);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record28 = new Record(collection);
    record28.set("name", "\u05e7\u05dc\u05d9\u05e0\u05d9\u05e7\u05d4 \u05e9\u05d9\u05e0\u05d9\u05d9\u05dd \u05d4\u05d2\u05d3\u05d5\u05dc");
    record28.set("category", "\u05e8\u05d5\u05e4\u05d0\u05d9 \u05e9\u05d9\u05e0\u05d9\u05d9\u05dd");
    record28.set("city", "\u05d1\u05d0\u05e8 \u05e9\u05d1\u05e2");
    record28.set("address", "\u05d4\u05d2\u05d3\u05d5\u05dc 90");
    record28.set("phone", "08-6789012");
    record28.set("whatsapp", "0509012345");
    record28.set("description", "\u05e7\u05dc\u05d9\u05e0\u05d9\u05e7\u05d4 \u05e9\u05d9\u05e0\u05d9\u05d9\u05dd \u05d4\u05d2\u05d3\u05d5\u05dc \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record28.set("opening_hours", "09:00-17:00");
    record28.set("rating", 4.5);
    record28.set("reviews_count", 36);
    record28.set("status", "approved");
    record28.set("is_featured", true);
  try {
    app.save(record28);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record29 = new Record(collection);
    record29.set("name", "\u05de\u05e9\u05e8\u05d3 \u05e2\u05d5\u05e8\u05db\u05d9 \u05d3\u05d9\u05df \u05d4\u05d2\u05d3\u05d5\u05dc");
    record29.set("category", "\u05e2\u05d5\u05e8\u05db\u05d9 \u05d3\u05d9\u05df");
    record29.set("city", "\u05de\u05d5\u05d3\u05d9\u05e2\u05d9\u05df");
    record29.set("address", "\u05d4\u05d9\u05e8\u05d3\u05df 60");
    record29.set("phone", "08-7890123");
    record29.set("whatsapp", "0500123456");
    record29.set("description", "\u05de\u05e9\u05e8\u05d3 \u05e2\u05d5\u05e8\u05db\u05d9 \u05d3\u05d9\u05df \u05d4\u05d2\u05d3\u05d5\u05dc \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record29.set("opening_hours", "10:00-18:00");
    record29.set("rating", 4.3);
    record29.set("reviews_count", 25);
    record29.set("status", "approved");
    record29.set("is_featured", false);
  try {
    app.save(record29);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record30 = new Record(collection);
    record30.set("name", "\u05e1\u05dc\u05d5\u05df \u05e7\u05d5\u05e1\u05de\u05d8\u05d9\u05e7\u05d4 \u05d4\u05d2\u05d3\u05d5\u05dc");
    record30.set("category", "\u05e7\u05d5\u05e1\u05de\u05d8\u05d9\u05e7\u05d4");
    record30.set("city", "\u05dc\u05d5\u05d3");
    record30.set("address", "\u05d4\u05d3\u05e8\u05d5\u05dd 25");
    record30.set("phone", "08-8901234");
    record30.set("whatsapp", "0501234567");
    record30.set("description", "\u05e1\u05dc\u05d5\u05df \u05e7\u05d5\u05e1\u05de\u05d8\u05d9\u05e7\u05d4 \u05d4\u05d2\u05d3\u05d5\u05dc \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record30.set("opening_hours", "09:00-19:00");
    record30.set("rating", 4.7);
    record30.set("reviews_count", 46);
    record30.set("status", "approved");
    record30.set("is_featured", true);
  try {
    app.save(record30);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record31 = new Record(collection);
    record31.set("name", "\u05d7\u05d3\u05e8 \u05db\u05d5\u05e9\u05e8 \u05d4\u05d2\u05d3\u05d5\u05dc");
    record31.set("category", "\u05d7\u05d3\u05e8\u05d9 \u05db\u05d5\u05e9\u05e8");
    record31.set("city", "\u05e8\u05de\u05dc\u05d4");
    record31.set("address", "\u05d4\u05d9\u05e8\u05d3\u05df 45");
    record31.set("phone", "08-9012345");
    record31.set("whatsapp", "0502345678");
    record31.set("description", "\u05d7\u05d3\u05e8 \u05db\u05d5\u05e9\u05e8 \u05d4\u05d2\u05d3\u05d5\u05dc \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record31.set("opening_hours", "06:00-22:00");
    record31.set("rating", 4.4);
    record31.set("reviews_count", 32);
    record31.set("status", "approved");
    record31.set("is_featured", false);
  try {
    app.save(record31);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record32 = new Record(collection);
    record32.set("name", "\u05de\u05e9\u05dc\u05d5\u05d7\u05d9\u05dd \u05de\u05d4\u05d9\u05e8 \u05d4\u05d2\u05d3\u05d5\u05dc");
    record32.set("category", "\u05de\u05e9\u05dc\u05d5\u05d7\u05d9\u05dd");
    record32.set("city", "\u05e8\u05d0\u05e9\u05d5\u05df \u05dc\u05e6\u05d9\u05d5\u05df");
    record32.set("address", "\u05d4\u05d2\u05d3\u05d5\u05dc 80");
    record32.set("phone", "09-7567890");
    record32.set("whatsapp", "0503456789");
    record32.set("description", "\u05de\u05e9\u05dc\u05d5\u05d7\u05d9\u05dd \u05de\u05d4\u05d9\u05e8 \u05d4\u05d2\u05d3\u05d5\u05dc \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record32.set("opening_hours", "08:00-20:00");
    record32.set("rating", 4.6);
    record32.set("reviews_count", 43);
    record32.set("status", "approved");
    record32.set("is_featured", true);
  try {
    app.save(record32);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record33 = new Record(collection);
    record33.set("name", "\u05de\u05d5\u05e8\u05d4 \u05e4\u05e8\u05d8\u05d9\u05ea \u05d4\u05d2\u05d3\u05d5\u05dc");
    record33.set("category", "\u05de\u05d5\u05e8\u05d9\u05dd \u05e4\u05e8\u05d8\u05d9\u05d9\u05dd");
    record33.set("city", "\u05e7\u05e8\u05d9\u05d9\u05ea \u05e9\u05de\u05d5\u05e0\u05d4");
    record33.set("address", "\u05d4\u05d9\u05e8\u05d3\u05df 12");
    record33.set("phone", "04-6890123");
    record33.set("whatsapp", "0504567890");
    record33.set("description", "\u05de\u05d5\u05e8\u05d4 \u05e4\u05e8\u05d8\u05d9\u05ea \u05d4\u05d2\u05d3\u05d5\u05dc \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record33.set("opening_hours", "15:00-20:00");
    record33.set("rating", 4.2);
    record33.set("reviews_count", 21);
    record33.set("status", "approved");
    record33.set("is_featured", false);
  try {
    app.save(record33);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record34 = new Record(collection);
    record34.set("name", "\u05d8\u05db\u05e0\u05d0\u05d9 \u05de\u05d6\u05d2\u05e0\u05d9\u05dd \u05d4\u05d2\u05d3\u05d5\u05dc");
    record34.set("category", "\u05d8\u05db\u05e0\u05d0\u05d9 \u05de\u05d6\u05d2\u05e0\u05d9\u05dd");
    record34.set("city", "\u05e6\u05e4\u05ea");
    record34.set("address", "\u05d4\u05d3\u05e8\u05d5\u05dd 70");
    record34.set("phone", "04-7901234");
    record34.set("whatsapp", "0505678901");
    record34.set("description", "\u05d8\u05db\u05e0\u05d0\u05d9 \u05de\u05d6\u05d2\u05e0\u05d9\u05dd \u05d4\u05d2\u05d3\u05d5\u05dc \u05e2\u05dd \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d8\u05d9\u05e4\u05d5\u05dc");
    record34.set("opening_hours", "08:00-18:00");
    record34.set("rating", 4.5);
    record34.set("reviews_count", 37);
    record34.set("status", "approved");
    record34.set("is_featured", true);
  try {
    app.save(record34);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }
}, (app) => {
  // Rollback: record IDs not known, manual cleanup needed
})