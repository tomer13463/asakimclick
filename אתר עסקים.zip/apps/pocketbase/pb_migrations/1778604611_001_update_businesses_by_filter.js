/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  let records;
  try {
    records = app.findRecordsByFilter("businesses", "name='מארלי'");
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("No records found, skipping");
      return;
    }
    throw e;
  }
  
  for (const record of records) {
    record.set("status", "approved");
    record.set("primary_category", "\u05d7\u05e0\u05d5\u05d9\u05d5\u05ea");
    record.set("description", "\u05d7\u05e0\u05d5\u05ea \u05d7\u05d9\u05d5\u05ea \u05de\u05d7\u05de\u05d3 - \u05de\u05d5\u05e7\u05d3\u05e9\u05ea \u05dc\u05db\u05dc\u05d1\u05d9\u05dd \u05d5\u05d7\u05ea\u05d5\u05dc\u05d9\u05dd. \u05e6\u05d9\u05d5\u05d3 \u05dc\u05d7\u05d9\u05d5\u05ea, \u05de\u05d6\u05d5\u05df \u05dc\u05d7\u05d9\u05d5\u05ea, \u05d0\u05d1\u05d9\u05d6\u05e8\u05d9\u05dd \u05d5\u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d7\u05d9\u05d5\u05ea \u05de\u05d7\u05de\u05d3.");
    record.set("is_approved", true);
    try {
      app.save(record);
    } catch (e) {
      if (e.message.includes("Value must be unique")) {
        console.log("Record with unique value already exists, skipping");
      } else {
        throw e;
      }
    }
  }
}, (app) => {
  // Rollback: original values not stored, manual restore needed
})