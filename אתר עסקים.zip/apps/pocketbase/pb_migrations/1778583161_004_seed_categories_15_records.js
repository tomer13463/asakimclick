/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("categories");

  const record0 = new Record(collection);
    record0.set("name", "\u05d0\u05d5\u05db\u05dc \u05d5\u05e9\u05ea\u05d9\u05d9\u05d4");
    record0.set("name_en", "Food & Beverage");
    record0.set("icon", "\ud83c\udf7d\ufe0f");
    record0.set("description", "\u05de\u05e1\u05e2\u05d3\u05d5\u05ea, \u05e7\u05e4\u05d4, \u05d1\u05e7\u05e8\u05d9\u05d9\u05d4 \u05d5\u05db\u05dc \u05de\u05d4 \u05e9\u05e7\u05e9\u05d5\u05e8 \u05dc\u05d0\u05d5\u05db\u05dc \u05d5\u05e9\u05ea\u05d9\u05d9\u05d4");
  try {
    app.save(record0);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record1 = new Record(collection);
    record1.set("name", "\u05d1\u05e8\u05d9\u05d0\u05d5\u05ea \u05d5\u05d9\u05d5\u05e4\u05d9");
    record1.set("name_en", "Health & Beauty");
    record1.set("icon", "\ud83d\udc86");
    record1.set("description", "\u05e1\u05e4\u05d0, \u05db\u05d5\u05e9\u05e8, \u05e7\u05d5\u05e1\u05de\u05d8\u05d9\u05e7\u05d4, \u05e9\u05d9\u05e0\u05d9\u05d9\u05dd \u05d5\u05d8\u05d9\u05e4\u05d5\u05dc\u05d9 \u05d9\u05d5\u05e4\u05d9");
  try {
    app.save(record1);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record2 = new Record(collection);
    record2.set("name", "\u05e7\u05e0\u05d9\u05d5\u05ea");
    record2.set("name_en", "Shopping");
    record2.set("icon", "\ud83d\udecd\ufe0f");
    record2.set("description", "\u05d1\u05d9\u05d2\u05d5\u05d3, \u05e0\u05e2\u05dc\u05d9\u05d9\u05dd, \u05d0\u05dc\u05e7\u05d8\u05e8\u05d5\u05e0\u05d9\u05e7\u05d4, \u05e8\u05d9\u05d4\u05d5\u05d8 \u05d5\u05e6\u05e2\u05e6\u05d5\u05e2\u05d9\u05dd");
  try {
    app.save(record2);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record3 = new Record(collection);
    record3.set("name", "\u05e9\u05d9\u05e8\u05d5\u05ea\u05d9\u05dd");
    record3.set("name_en", "Services");
    record3.set("icon", "\ud83d\udd27");
    record3.set("description", "\u05ea\u05d9\u05e7\u05d5\u05df, \u05e0\u05d9\u05e7\u05d9\u05d5\u05df, \u05d8\u05db\u05e0\u05d0\u05d9\u05dd \u05d5\u05d7\u05e9\u05de\u05dc\u05d0\u05d9\u05dd");
  try {
    app.save(record3);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record4 = new Record(collection);
    record4.set("name", "\u05d1\u05d9\u05d3\u05d5\u05e8");
    record4.set("name_en", "Entertainment");
    record4.set("icon", "\ud83c\udfac");
    record4.set("description", "\u05e7\u05d5\u05dc\u05e0\u05d5\u05e2, \u05d1\u05e8 \u05d1\u05d9\u05dc\u05d9\u05d0\u05e8\u05d3, \u05e7\u05e8\u05d9\u05d5\u05e7\u05d9 \u05d5\u05de\u05e9\u05d7\u05e7\u05d9\u05dd");
  try {
    app.save(record4);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record5 = new Record(collection);
    record5.set("name", "\u05d7\u05d9\u05e0\u05d5\u05da");
    record5.set("name_en", "Education");
    record5.set("icon", "\ud83d\udcda");
    record5.set("description", "\u05e7\u05d5\u05e8\u05e1\u05d9\u05dd, \u05e9\u05d9\u05e2\u05d5\u05e8\u05d9\u05dd \u05e4\u05e8\u05d8\u05d9\u05d9\u05dd, \u05e1\u05e4\u05e8\u05d9\u05d9\u05d4 \u05d5\u05de\u05db\u05dc\u05dc\u05d4");
  try {
    app.save(record5);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record6 = new Record(collection);
    record6.set("name", "\u05ea\u05d9\u05d9\u05e8\u05d5\u05ea \u05d5\u05e0\u05e1\u05d9\u05e2\u05d5\u05ea");
    record6.set("name_en", "Tourism & Travel");
    record6.set("icon", "\u2708\ufe0f");
    record6.set("description", "\u05de\u05dc\u05d5\u05df, \u05d3\u05d9\u05e8\u05d4, \u05d8\u05d9\u05d5\u05dc \u05d5\u05ea\u05d7\u05d1\u05d5\u05e8\u05d4");
  try {
    app.save(record6);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record7 = new Record(collection);
    record7.set("name", "\u05e8\u05db\u05d1");
    record7.set("name_en", "Automotive");
    record7.set("icon", "\ud83d\ude97");
    record7.set("description", "\u05ea\u05d9\u05e7\u05d5\u05df, \u05e9\u05d8\u05d9\u05e4\u05d4, \u05d3\u05dc\u05e7 \u05d5\u05d1\u05d9\u05d8\u05d5\u05d7");
  try {
    app.save(record7);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record8 = new Record(collection);
    record8.set("name", "\u05d1\u05e2\u05dc\u05d9 \u05d7\u05d9\u05d9\u05dd");
    record8.set("name_en", "Pets");
    record8.set("icon", "\ud83d\udc3e");
    record8.set("description", "\u05d5\u05d8\u05e8\u05d9\u05e0\u05e8, \u05d7\u05e0\u05d5\u05ea \u05d7\u05d9\u05d5\u05ea, \u05d2\u05e8\u05d5\u05de\u05d9\u05e0\u05d2 \u05d5\u05de\u05dc\u05d5\u05e0\u05d4");
  try {
    app.save(record8);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record9 = new Record(collection);
    record9.set("name", "\u05e1\u05e4\u05d5\u05e8\u05d8");
    record9.set("name_en", "Sports");
    record9.set("icon", "\u26bd");
    record9.set("description", "\u05de\u05db\u05d5\u05df \u05db\u05d5\u05e9\u05e8, \u05d1\u05e8\u05d9\u05db\u05d4, \u05de\u05d2\u05e8\u05e9 \u05d5\u05d0\u05d5\u05e4\u05e0\u05d9\u05d9\u05dd");
  try {
    app.save(record9);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record10 = new Record(collection);
    record10.set("name", "\u05ea\u05e8\u05d1\u05d5\u05ea");
    record10.set("name_en", "Culture");
    record10.set("icon", "\ud83c\udfad");
    record10.set("description", "\u05ea\u05d9\u05d0\u05d8\u05e8\u05d5\u05df, \u05de\u05d5\u05d6\u05d9\u05d0\u05d5\u05dd, \u05d2\u05dc\u05e8\u05d9\u05d4 \u05d5\u05e1\u05e4\u05e8\u05d9\u05d9\u05d4");
  try {
    app.save(record10);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record11 = new Record(collection);
    record11.set("name", "\u05e2\u05e1\u05e7\u05d9\u05dd");
    record11.set("name_en", "Business");
    record11.set("icon", "\ud83d\udcbc");
    record11.set("description", "\u05de\u05e9\u05e8\u05d3\u05d9\u05dd, \u05d4\u05d3\u05e4\u05e1\u05d4, \u05d7\u05e9\u05d1\u05d5\u05e0\u05d5\u05ea \u05d5\u05e9\u05d9\u05e8\u05d5\u05ea\u05d9\u05dd \u05de\u05e9\u05e4\u05d8\u05d9\u05d9\u05dd");
  try {
    app.save(record11);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record12 = new Record(collection);
    record12.set("name", "\u05e0\u05d3\u05dc\u05df");
    record12.set("name_en", "Real Estate");
    record12.set("icon", "\ud83c\udfe0");
    record12.set("description", "\u05e1\u05d5\u05db\u05df \u05e0\u05d3\u05dc\u05df, \u05d1\u05e0\u05d9\u05d9\u05d4 \u05d5\u05d3\u05d9\u05e8\u05d5\u05ea \u05dc\u05d4\u05e9\u05db\u05e8\u05d4");
  try {
    app.save(record12);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record13 = new Record(collection);
    record13.set("name", "\u05d7\u05e7\u05dc\u05d0\u05d5\u05ea");
    record13.set("name_en", "Agriculture");
    record13.set("icon", "\ud83c\udf3e");
    record13.set("description", "\u05d7\u05e7\u05dc\u05d0\u05d9, \u05d7\u05e0\u05d5\u05ea \u05d7\u05e7\u05dc\u05d0\u05d9\u05ea \u05d5\u05d2\u05df");
  try {
    app.save(record13);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record14 = new Record(collection);
    record14.set("name", "\u05d0\u05d7\u05e8");
    record14.set("name_en", "Other");
    record14.set("icon", "\ud83d\udccc");
    record14.set("description", "\u05e7\u05d8\u05d2\u05d5\u05e8\u05d9\u05d5\u05ea \u05e9\u05d5\u05e0\u05d5\u05ea");
  try {
    app.save(record14);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }
}, (app) => {
  // Rollback: record IDs not known, manual cleanup needed
})