/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("subcategories");

  const record0 = new Record(collection);
    record0.set("name", "\u05de\u05e1\u05e2\u05d3\u05d4");
    const record0_category_idLookup = app.findFirstRecordByFilter("categories", "name='אוכל ושתייה'");
    if (!record0_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='אוכל ושתייה'\""); }
    record0.set("category_id", record0_category_idLookup.id);
  try {
    app.save(record0);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record1 = new Record(collection);
    record1.set("name", "\u05e7\u05e4\u05d4");
    const record1_category_idLookup = app.findFirstRecordByFilter("categories", "name='אוכל ושתייה'");
    if (!record1_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='אוכל ושתייה'\""); }
    record1.set("category_id", record1_category_idLookup.id);
  try {
    app.save(record1);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record2 = new Record(collection);
    record2.set("name", "\u05d1\u05e7\u05e8\u05d9\u05d9\u05d4");
    const record2_category_idLookup = app.findFirstRecordByFilter("categories", "name='אוכל ושתייה'");
    if (!record2_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='אוכל ושתייה'\""); }
    record2.set("category_id", record2_category_idLookup.id);
  try {
    app.save(record2);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record3 = new Record(collection);
    record3.set("name", "\u05e4\u05d9\u05e6\u05e8\u05d9\u05d4");
    const record3_category_idLookup = app.findFirstRecordByFilter("categories", "name='אוכל ושתייה'");
    if (!record3_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='אוכל ושתייה'\""); }
    record3.set("category_id", record3_category_idLookup.id);
  try {
    app.save(record3);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record4 = new Record(collection);
    record4.set("name", "\u05d1\u05e8");
    const record4_category_idLookup = app.findFirstRecordByFilter("categories", "name='אוכל ושתייה'");
    if (!record4_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='אוכל ושתייה'\""); }
    record4.set("category_id", record4_category_idLookup.id);
  try {
    app.save(record4);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record5 = new Record(collection);
    record5.set("name", "\u05e1\u05e4\u05d0");
    const record5_category_idLookup = app.findFirstRecordByFilter("categories", "name='בריאות ויופי'");
    if (!record5_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='בריאות ויופי'\""); }
    record5.set("category_id", record5_category_idLookup.id);
  try {
    app.save(record5);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record6 = new Record(collection);
    record6.set("name", "\u05db\u05d5\u05e9\u05e8");
    const record6_category_idLookup = app.findFirstRecordByFilter("categories", "name='בריאות ויופי'");
    if (!record6_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='בריאות ויופי'\""); }
    record6.set("category_id", record6_category_idLookup.id);
  try {
    app.save(record6);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record7 = new Record(collection);
    record7.set("name", "\u05e7\u05d5\u05e1\u05de\u05d8\u05d9\u05e7\u05d4");
    const record7_category_idLookup = app.findFirstRecordByFilter("categories", "name='בריאות ויופי'");
    if (!record7_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='בריאות ויופי'\""); }
    record7.set("category_id", record7_category_idLookup.id);
  try {
    app.save(record7);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record8 = new Record(collection);
    record8.set("name", "\u05e9\u05d9\u05e0\u05d9\u05d9\u05dd");
    const record8_category_idLookup = app.findFirstRecordByFilter("categories", "name='בריאות ויופי'");
    if (!record8_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='בריאות ויופי'\""); }
    record8.set("category_id", record8_category_idLookup.id);
  try {
    app.save(record8);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record9 = new Record(collection);
    record9.set("name", "\u05d1\u05d9\u05d2\u05d5\u05d3");
    const record9_category_idLookup = app.findFirstRecordByFilter("categories", "name='קניות'");
    if (!record9_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='קניות'\""); }
    record9.set("category_id", record9_category_idLookup.id);
  try {
    app.save(record9);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record10 = new Record(collection);
    record10.set("name", "\u05e0\u05e2\u05dc\u05d9\u05d9\u05dd");
    const record10_category_idLookup = app.findFirstRecordByFilter("categories", "name='קניות'");
    if (!record10_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='קניות'\""); }
    record10.set("category_id", record10_category_idLookup.id);
  try {
    app.save(record10);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record11 = new Record(collection);
    record11.set("name", "\u05d0\u05dc\u05e7\u05d8\u05e8\u05d5\u05e0\u05d9\u05e7\u05d4");
    const record11_category_idLookup = app.findFirstRecordByFilter("categories", "name='קניות'");
    if (!record11_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='קניות'\""); }
    record11.set("category_id", record11_category_idLookup.id);
  try {
    app.save(record11);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record12 = new Record(collection);
    record12.set("name", "\u05e8\u05d9\u05d4\u05d5\u05d8");
    const record12_category_idLookup = app.findFirstRecordByFilter("categories", "name='קניות'");
    if (!record12_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='קניות'\""); }
    record12.set("category_id", record12_category_idLookup.id);
  try {
    app.save(record12);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record13 = new Record(collection);
    record13.set("name", "\u05d7\u05e9\u05de\u05dc\u05d0\u05d9");
    const record13_category_idLookup = app.findFirstRecordByFilter("categories", "name='שירותים'");
    if (!record13_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='שירותים'\""); }
    record13.set("category_id", record13_category_idLookup.id);
  try {
    app.save(record13);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record14 = new Record(collection);
    record14.set("name", "\u05d0\u05d5\u05e4\u05e0\u05d9\u05d9\u05dd");
    const record14_category_idLookup = app.findFirstRecordByFilter("categories", "name='שירותים'");
    if (!record14_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='שירותים'\""); }
    record14.set("category_id", record14_category_idLookup.id);
  try {
    app.save(record14);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record15 = new Record(collection);
    record15.set("name", "\u05e0\u05d9\u05e7\u05d9\u05d5\u05df");
    const record15_category_idLookup = app.findFirstRecordByFilter("categories", "name='שירותים'");
    if (!record15_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='שירותים'\""); }
    record15.set("category_id", record15_category_idLookup.id);
  try {
    app.save(record15);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record16 = new Record(collection);
    record16.set("name", "\u05d8\u05db\u05e0\u05d0\u05d9");
    const record16_category_idLookup = app.findFirstRecordByFilter("categories", "name='שירותים'");
    if (!record16_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='שירותים'\""); }
    record16.set("category_id", record16_category_idLookup.id);
  try {
    app.save(record16);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record17 = new Record(collection);
    record17.set("name", "\u05d1\u05e0\u05d9\u05d9\u05d4");
    const record17_category_idLookup = app.findFirstRecordByFilter("categories", "name='שירותים'");
    if (!record17_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='שירותים'\""); }
    record17.set("category_id", record17_category_idLookup.id);
  try {
    app.save(record17);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record18 = new Record(collection);
    record18.set("name", "\u05e7\u05d5\u05dc\u05e0\u05d5\u05e2");
    const record18_category_idLookup = app.findFirstRecordByFilter("categories", "name='בידור'");
    if (!record18_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='בידור'\""); }
    record18.set("category_id", record18_category_idLookup.id);
  try {
    app.save(record18);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record19 = new Record(collection);
    record19.set("name", "\u05d1\u05e8 \u05d1\u05d9\u05dc\u05d9\u05d0\u05e8\u05d3");
    const record19_category_idLookup = app.findFirstRecordByFilter("categories", "name='בידור'");
    if (!record19_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='בידור'\""); }
    record19.set("category_id", record19_category_idLookup.id);
  try {
    app.save(record19);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record20 = new Record(collection);
    record20.set("name", "\u05e7\u05e8\u05d9\u05d5\u05e7\u05d9");
    const record20_category_idLookup = app.findFirstRecordByFilter("categories", "name='בידור'");
    if (!record20_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='בידור'\""); }
    record20.set("category_id", record20_category_idLookup.id);
  try {
    app.save(record20);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record21 = new Record(collection);
    record21.set("name", "\u05e7\u05d5\u05e8\u05e1\u05d9\u05dd");
    const record21_category_idLookup = app.findFirstRecordByFilter("categories", "name='חינוך'");
    if (!record21_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='חינוך'\""); }
    record21.set("category_id", record21_category_idLookup.id);
  try {
    app.save(record21);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record22 = new Record(collection);
    record22.set("name", "\u05e9\u05d9\u05e2\u05d5\u05e8\u05d9\u05dd \u05e4\u05e8\u05d8\u05d9\u05d9\u05dd");
    const record22_category_idLookup = app.findFirstRecordByFilter("categories", "name='חינוך'");
    if (!record22_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='חינוך'\""); }
    record22.set("category_id", record22_category_idLookup.id);
  try {
    app.save(record22);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record23 = new Record(collection);
    record23.set("name", "\u05ea\u05d9\u05e7\u05d5\u05df");
    const record23_category_idLookup = app.findFirstRecordByFilter("categories", "name='רכב'");
    if (!record23_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='רכב'\""); }
    record23.set("category_id", record23_category_idLookup.id);
  try {
    app.save(record23);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record24 = new Record(collection);
    record24.set("name", "\u05e9\u05d8\u05d9\u05e4\u05d4");
    const record24_category_idLookup = app.findFirstRecordByFilter("categories", "name='רכב'");
    if (!record24_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='רכב'\""); }
    record24.set("category_id", record24_category_idLookup.id);
  try {
    app.save(record24);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record25 = new Record(collection);
    record25.set("name", "\u05d3\u05dc\u05e7");
    const record25_category_idLookup = app.findFirstRecordByFilter("categories", "name='רכב'");
    if (!record25_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='רכב'\""); }
    record25.set("category_id", record25_category_idLookup.id);
  try {
    app.save(record25);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record26 = new Record(collection);
    record26.set("name", "\u05d5\u05d8\u05e8\u05d9\u05e0\u05e8");
    const record26_category_idLookup = app.findFirstRecordByFilter("categories", "name='בעלי חיים'");
    if (!record26_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='בעלי חיים'\""); }
    record26.set("category_id", record26_category_idLookup.id);
  try {
    app.save(record26);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record27 = new Record(collection);
    record27.set("name", "\u05d7\u05e0\u05d5\u05ea \u05d7\u05d9\u05d5\u05ea");
    const record27_category_idLookup = app.findFirstRecordByFilter("categories", "name='בעלי חיים'");
    if (!record27_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='בעלי חיים'\""); }
    record27.set("category_id", record27_category_idLookup.id);
  try {
    app.save(record27);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record28 = new Record(collection);
    record28.set("name", "\u05d2\u05e8\u05d5\u05de\u05d9\u05e0\u05d2");
    const record28_category_idLookup = app.findFirstRecordByFilter("categories", "name='בעלי חיים'");
    if (!record28_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='בעלי חיים'\""); }
    record28.set("category_id", record28_category_idLookup.id);
  try {
    app.save(record28);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record29 = new Record(collection);
    record29.set("name", "\u05de\u05db\u05d5\u05df \u05db\u05d5\u05e9\u05e8");
    const record29_category_idLookup = app.findFirstRecordByFilter("categories", "name='ספורט'");
    if (!record29_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='ספורט'\""); }
    record29.set("category_id", record29_category_idLookup.id);
  try {
    app.save(record29);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record30 = new Record(collection);
    record30.set("name", "\u05d1\u05e8\u05d9\u05db\u05d4");
    const record30_category_idLookup = app.findFirstRecordByFilter("categories", "name='ספורט'");
    if (!record30_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='ספורט'\""); }
    record30.set("category_id", record30_category_idLookup.id);
  try {
    app.save(record30);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record31 = new Record(collection);
    record31.set("name", "\u05de\u05d2\u05e8\u05e9");
    const record31_category_idLookup = app.findFirstRecordByFilter("categories", "name='ספורט'");
    if (!record31_category_idLookup) { throw new Error("Lookup failed for category_id: no record in 'categories' matching \"name='ספורט'\""); }
    record31.set("category_id", record31_category_idLookup.id);
  try {
    app.save(record31);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }
}, (app) => {
  // Rollback: record IDs not known, manual cleanup needed
})