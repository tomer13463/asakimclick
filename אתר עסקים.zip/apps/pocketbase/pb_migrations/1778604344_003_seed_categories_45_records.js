/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("categories");

  const record0 = new Record(collection);
    record0.set("name", "\u05de\u05d6\u05d5\u05df \u05d5\u05e6\u05d9\u05d5\u05d3 \u05dc\u05d1\u05e2\u05dc\u05d9 \u05d7\u05d9\u05d9\u05dd");
    record0.set("name_en", "Pet Food & Supplies");
  try {
    app.save(record0);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record1 = new Record(collection);
    record1.set("name", "\u05d0\u05d5\u05de\u05e0\u05d4 \u05dc\u05d1\u05e2\u05dc\u05d9 \u05d7\u05d9\u05d9\u05dd");
    record1.set("name_en", "Pet Care & Grooming");
  try {
    app.save(record1);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record2 = new Record(collection);
    record2.set("name", "\u05d8\u05d9\u05e4\u05d5\u05dc\u05d9 \u05d9\u05d5\u05e4\u05d9");
    record2.set("name_en", "Beauty Treatments");
  try {
    app.save(record2);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record3 = new Record(collection);
    record3.set("name", "\u05d1\u05e8\u05d9\u05d0\u05d5\u05ea \u05d5\u05db\u05d5\u05e9\u05e8");
    record3.set("name_en", "Health & Fitness");
  try {
    app.save(record3);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record4 = new Record(collection);
    record4.set("name", "\u05d8\u05d9\u05e4\u05d5\u05dc\u05d9\u05dd \u05e8\u05e4\u05d5\u05d0\u05d9\u05d9\u05dd");
    record4.set("name_en", "Medical Treatments");
  try {
    app.save(record4);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record5 = new Record(collection);
    record5.set("name", "\u05e9\u05d9\u05e8\u05d5\u05ea\u05d9 \u05e0\u05d9\u05e7\u05d9\u05d5\u05df");
    record5.set("name_en", "Cleaning Services");
  try {
    app.save(record5);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record6 = new Record(collection);
    record6.set("name", "\u05ea\u05d9\u05e7\u05d5\u05e0\u05d9\u05dd \u05d5\u05d8\u05db\u05e0\u05d0\u05d5\u05ea");
    record6.set("name_en", "Repairs & Technical Services");
  try {
    app.save(record6);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record7 = new Record(collection);
    record7.set("name", "\u05e9\u05d9\u05e8\u05d5\u05ea\u05d9 \u05e2\u05d9\u05e6\u05d5\u05d1");
    record7.set("name_en", "Design Services");
  try {
    app.save(record7);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record8 = new Record(collection);
    record8.set("name", "\u05e9\u05d9\u05e8\u05d5\u05ea\u05d9 \u05d1\u05e0\u05d9\u05d9\u05d4 \u05d5\u05d2\u05de\u05e8");
    record8.set("name_en", "Construction & Finishing");
  try {
    app.save(record8);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record9 = new Record(collection);
    record9.set("name", "\u05e9\u05d9\u05e8\u05d5\u05ea\u05d9 \u05d2\u05d9\u05e0\u05d5\u05df \u05d5\u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d7\u05e6\u05e8");
    record9.set("name_en", "Gardening & Landscaping");
  try {
    app.save(record9);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record10 = new Record(collection);
    record10.set("name", "\u05e9\u05d9\u05e8\u05d5\u05ea\u05d9 \u05d4\u05d5\u05d1\u05dc\u05d4 \u05d5\u05d3\u05dc\u05e7\u05d5");
    record10.set("name_en", "Moving & Delivery");
  try {
    app.save(record10);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record11 = new Record(collection);
    record11.set("name", "\u05e9\u05d9\u05e8\u05d5\u05ea\u05d9 \u05db\u05d1\u05d9\u05e1\u05d4 \u05d5\u05d2\u05d9\u05d4\u05d5\u05e5");
    record11.set("name_en", "Laundry & Ironing");
  try {
    app.save(record11);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record12 = new Record(collection);
    record12.set("name", "\u05e9\u05d9\u05e8\u05d5\u05ea\u05d9 \u05d8\u05d9\u05e4\u05d5\u05dc \u05d1\u05d1\u05d9\u05ea");
    record12.set("name_en", "Home Care Services");
  try {
    app.save(record12);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record13 = new Record(collection);
    record13.set("name", "\u05e9\u05d9\u05e8\u05d5\u05ea\u05d9 \u05d7\u05e9\u05d1\u05d5\u05e0\u05d5\u05ea \u05d5\u05e0\u05d9\u05d4\u05d5\u05dc");
    record13.set("name_en", "Accounting & Management");
  try {
    app.save(record13);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record14 = new Record(collection);
    record14.set("name", "\u05e9\u05d9\u05e8\u05d5\u05ea\u05d9 \u05d9\u05d9\u05e2\u05d5\u05e5 \u05e2\u05e1\u05e7\u05d9");
    record14.set("name_en", "Business Consulting");
  try {
    app.save(record14);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record15 = new Record(collection);
    record15.set("name", "\u05e9\u05d9\u05e8\u05d5\u05ea\u05d9 \u05de\u05e9\u05e4\u05d8\u05d9\u05d9\u05dd");
    record15.set("name_en", "Legal Services");
  try {
    app.save(record15);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record16 = new Record(collection);
    record16.set("name", "\u05e9\u05d9\u05e8\u05d5\u05ea\u05d9 \u05d1\u05d9\u05d8\u05d5\u05d7");
    record16.set("name_en", "Insurance Services");
  try {
    app.save(record16);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record17 = new Record(collection);
    record17.set("name", "\u05e9\u05d9\u05e8\u05d5\u05ea\u05d9 \u05de\u05e9\u05db\u05e0\u05ea\u05d0");
    record17.set("name_en", "Mortgage Services");
  try {
    app.save(record17);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record18 = new Record(collection);
    record18.set("name", "\u05e9\u05d9\u05e8\u05d5\u05ea\u05d9 \u05ea\u05e8\u05d2\u05d5\u05dd");
    record18.set("name_en", "Translation Services");
  try {
    app.save(record18);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record19 = new Record(collection);
    record19.set("name", "\u05e9\u05d9\u05e8\u05d5\u05ea\u05d9 \u05d4\u05d3\u05e8\u05db\u05d4 \u05d5\u05d7\u05d9\u05e0\u05d5\u05da");
    record19.set("name_en", "Training & Education");
  try {
    app.save(record19);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record20 = new Record(collection);
    record20.set("name", "\u05e9\u05d9\u05e8\u05d5\u05ea\u05d9 \u05e6\u05d9\u05dc\u05d5\u05dd \u05d5\u05d5\u05d5\u05d9\u05d3\u05d0\u05d5");
    record20.set("name_en", "Photography & Video");
  try {
    app.save(record20);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record21 = new Record(collection);
    record21.set("name", "\u05e9\u05d9\u05e8\u05d5\u05ea\u05d9 \u05e2\u05d9\u05e6\u05d5\u05d1 \u05d2\u05e8\u05e4\u05d9");
    record21.set("name_en", "Graphic Design");
  try {
    app.save(record21);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record22 = new Record(collection);
    record22.set("name", "\u05e9\u05d9\u05e8\u05d5\u05ea\u05d9 \u05d1\u05e0\u05d9\u05d9\u05d4 \u05d0\u05ea\u05e8\u05d9\u05dd");
    record22.set("name_en", "Web Development");
  try {
    app.save(record22);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record23 = new Record(collection);
    record23.set("name", "\u05d1\u05d9\u05d2\u05d5\u05d3 \u05d5\u05e0\u05e2\u05dc\u05d9\u05d9\u05dd");
    record23.set("name_en", "Clothing & Footwear");
  try {
    app.save(record23);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record24 = new Record(collection);
    record24.set("name", "\u05ea\u05db\u05e9\u05d9\u05d8\u05d9\u05dd \u05d5\u05d0\u05d1\u05d9\u05d6\u05e8\u05d9\u05dd");
    record24.set("name_en", "Jewelry & Accessories");
  try {
    app.save(record24);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record25 = new Record(collection);
    record25.set("name", "\u05e1\u05e4\u05e8\u05d9\u05dd \u05d5\u05e1\u05e4\u05e8\u05d5\u05ea");
    record25.set("name_en", "Books & Literature");
  try {
    app.save(record25);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record26 = new Record(collection);
    record26.set("name", "\u05e6\u05e2\u05e6\u05d5\u05e2\u05d9\u05dd \u05d5\u05d2\u05d9\u05d9\u05de\u05d9\u05e0\u05d2");
    record26.set("name_en", "Toys & Gaming");
  try {
    app.save(record26);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record27 = new Record(collection);
    record27.set("name", "\u05d0\u05dc\u05e7\u05d8\u05e8\u05d5\u05e0\u05d9\u05e7\u05d4 \u05d5\u05d8\u05db\u05e0\u05d5\u05dc\u05d5\u05d2\u05d9\u05d4");
    record27.set("name_en", "Electronics & Technology");
  try {
    app.save(record27);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record28 = new Record(collection);
    record28.set("name", "\u05e8\u05d9\u05d4\u05d5\u05d8 \u05d5\u05db\u05dc\u05d9\u05dd");
    record28.set("name_en", "Furniture & Kitchenware");
  try {
    app.save(record28);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record29 = new Record(collection);
    record29.set("name", "\u05e1\u05e4\u05d5\u05e8\u05d8 \u05d5\u05e6\u05d9\u05d5\u05d3 \u05e1\u05e4\u05d5\u05e8\u05d8");
    record29.set("name_en", "Sports & Equipment");
  try {
    app.save(record29);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record30 = new Record(collection);
    record30.set("name", "\u05de\u05d5\u05d6\u05d9\u05e7\u05d4 \u05d5\u05db\u05dc\u05d9\u05dd \u05de\u05d5\u05d6\u05d9\u05e7\u05dc\u05d9\u05d9\u05dd");
    record30.set("name_en", "Music & Instruments");
  try {
    app.save(record30);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record31 = new Record(collection);
    record31.set("name", "\u05de\u05e9\u05e7\u05e4\u05d9\u05d9\u05dd \u05d5\u05d0\u05d5\u05e4\u05d8\u05d9\u05e7\u05d4");
    record31.set("name_en", "Eyewear & Optics");
  try {
    app.save(record31);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record32 = new Record(collection);
    record32.set("name", "\u05e9\u05e2\u05d5\u05e0\u05d9\u05dd \u05d5\u05e6\u05d9\u05d5\u05d3 \u05d6\u05de\u05df");
    record32.set("name_en", "Watches & Timepieces");
  try {
    app.save(record32);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record33 = new Record(collection);
    record33.set("name", "\u05d1\u05e9\u05de\u05d9\u05dd \u05d5\u05e7\u05d5\u05e1\u05de\u05d8\u05d9\u05e7\u05d4");
    record33.set("name_en", "Perfumes & Cosmetics");
  try {
    app.save(record33);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record34 = new Record(collection);
    record34.set("name", "\u05ea\u05e8\u05d5\u05e4\u05d5\u05ea \u05d5\u05d1\u05d9\u05d8\u05d7\u05d5\u05df \u05d1\u05e8\u05d9\u05d0\u05d5\u05ea");
    record34.set("name_en", "Pharmacy & Health");
  try {
    app.save(record34);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record35 = new Record(collection);
    record35.set("name", "\u05de\u05d6\u05d5\u05df \u05d1\u05e8\u05d9\u05d0 \u05d5\u05e1\u05d5\u05e4\u05dc\u05de\u05e0\u05d8\u05d9\u05dd");
    record35.set("name_en", "Healthy Food & Supplements");
  try {
    app.save(record35);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record36 = new Record(collection);
    record36.set("name", "\u05e7\u05e4\u05d4 \u05d5\u05ea\u05d4");
    record36.set("name_en", "Coffee & Tea");
  try {
    app.save(record36);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record37 = new Record(collection);
    record37.set("name", "\u05d9\u05d9\u05df \u05d5\u05d7\u05de\u05e8\u05d9\u05dd \u05d0\u05dc\u05db\u05d5\u05d4\u05d5\u05dc\u05d9\u05d9\u05dd");
    record37.set("name_en", "Wine & Alcoholic Beverages");
  try {
    app.save(record37);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record38 = new Record(collection);
    record38.set("name", "\u05e1\u05d9\u05d2\u05e8\u05d9\u05dd \u05d5\u05d8\u05d1\u05e7");
    record38.set("name_en", "Cigars & Tobacco");
  try {
    app.save(record38);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record39 = new Record(collection);
    record39.set("name", "\u05de\u05ea\u05e0\u05d5\u05ea \u05d5\u05e4\u05e8\u05d7\u05d9\u05dd");
    record39.set("name_en", "Gifts & Flowers");
  try {
    app.save(record39);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record40 = new Record(collection);
    record40.set("name", "\u05e6\u05de\u05d7\u05d9\u05dd \u05d5\u05d2\u05d9\u05e0\u05d4");
    record40.set("name_en", "Plants & Gardening");
  try {
    app.save(record40);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record41 = new Record(collection);
    record41.set("name", "\u05de\u05e1\u05e2\u05d3\u05d4 \u05d5\u05e7\u05e4\u05d4");
    record41.set("name_en", "Restaurant & Cafe");
  try {
    app.save(record41);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record42 = new Record(collection);
    record42.set("name", "\u05d1\u05e8 \u05d5\u05e7\u05d5\u05e7\u05d8\u05d9\u05d9\u05dc\u05d9\u05dd");
    record42.set("name_en", "Bar & Cocktails");
  try {
    app.save(record42);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record43 = new Record(collection);
    record43.set("name", "\u05d0\u05d9\u05e8\u05d5\u05d7 \u05d5\u05de\u05dc\u05d5\u05df");
    record43.set("name_en", "Hospitality & Hotel");
  try {
    app.save(record43);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }

  const record44 = new Record(collection);
    record44.set("name", "\u05de\u05e6\u05dc\u05de\u05d5\u05ea \u05d5\u05e6\u05d9\u05d5\u05d3 \u05e6\u05d9\u05dc\u05d5\u05dd");
    record44.set("name_en", "Cameras & Photography Equipment");
  try {
    app.save(record44);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
    } else {
      throw e;
    }
  }
}, (app) => {
  // Rollback: record IDs not known, manual cleanup needed
})