/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("businesses");
  const field = collection.fields.getByName("category");
  field.name = "primary_category";
  return app.save(collection);
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("businesses");
    const field = collection.fields.getByName("primary_category");
    if (!field) { console.log("Field not found, skipping revert"); return; }
    field.name = "category";
    return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection or field not found, skipping revert");
      return;
    }
    throw e;
  }
})